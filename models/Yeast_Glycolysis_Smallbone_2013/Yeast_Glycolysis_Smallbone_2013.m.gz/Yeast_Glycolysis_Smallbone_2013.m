(* Created by Wolfram Mathematica 9.0 : www.wolfram.com *)
MASSmodel[{"ID" -> "MODEL1303260018", "Stoichiometry" -> 
   SparseArray[Automatic, {29, 33}, 0, {1, {{0, 6, 7, 17, 18, 22, 25, 27, 29, 
      31, 33, 35, 41, 46, 50, 51, 52, 60, 63, 65, 69, 75, 77, 78, 88, 96, 97, 
      99, 101, 103}, {{1}, {2}, {14}, {15}, {16}, {30}, {30}, {3}, {4}, {11}, 
      {12}, {13}, {17}, {19}, {21}, {22}, {32}, {3}, {19}, {23}, {24}, {25}, 
      {7}, {8}, {26}, {1}, {2}, {7}, {17}, {17}, {18}, {20}, {29}, {8}, {10}, 
      {11}, {12}, {13}, {18}, {20}, {28}, {7}, {23}, {24}, {25}, {26}, {11}, 
      {12}, {13}, {33}, {33}, {10}, {1}, {2}, {8}, {23}, {24}, {25}, {30}, 
      {31}, {5}, {6}, {9}, {9}, {19}, {5}, {6}, {21}, {22}, {14}, {15}, {16}, 
      {21}, {22}, {31}, {27}, {28}, {27}, {3}, {4}, {11}, {12}, {13}, {17}, 
      {19}, {21}, {22}, {32}, {1}, {2}, {8}, {23}, {24}, {25}, {30}, {31}, 
      {31}, {28}, {29}, {28}, {32}, {29}, {32}}}, {-1, -1, 1, 1, 1, -1, 1, 
      -2, 1, 1, 1, 1, 1, -1, -1, -1, 1, 1, -1, 1, 1, 1, 1, -1, -1, 1, 1, -1, 
      1, -1, 1, 1, -1, 1, -1, 1, 1, 1, -1, -1, -1, 1, -1, -1, -1, 1, -1, -1, 
      -1, 1, -1, 1, 1, 1, 1, -1, -1, -1, -1, -3, -1, -1, 1, -1, 1, 1, 1, -1, 
      -1, -1, -1, -1, 1, 1, -1, -1, 1, 1, 1, -1, -1, -1, -1, -1, 1, 1, 1, -1, 
      -1, -1, -1, 1, 1, 1, 1, 3, 0.75, -1, 1, 1, -1, -1, 1}}], 
  "Species" -> {species["AcAld", "cell"], species["ACE", "cell"], 
    species["ADP", "cell"], species["AMP", "cell"], species["BPG", "cell"], 
    species["DHAP", "cell"], species["EtOH", "cell"], 
    species["F16bP", "cell"], species["F6P", "cell"], species["G1P", "cell"], 
    species["G3P", "cell"], species["G6P", "cell"], species["GAP", "cell"], 
    species["GLC", "cell"], species["GLCx", "extracellular"], 
    species["GLY", "cell"], species["NAD", "cell"], species["P2G", "cell"], 
    species["P3G", "cell"], species["PEP", "cell"], species["PYR", "cell"], 
    species["T6P", "cell"], species["TRH", "cell"], species["ATP", "cell"], 
    species["NADH", "cell"], species["SUC", "cell"], species["UDG", "cell"], 
    species["UDP", "cell"], species["UTP", "cell"]}, 
  "Fluxes" -> {v["ADH_ADH1"], v["ADH_ADH5"], v["AK"], v["ATPase"], 
    v["ENO_ENO1"], v["ENO_ENO2"], v["FBA"], v["GPD"], v["GPM"], v["GPP"], 
    v["HXK_GLK1"], v["HXK_HXK1"], v["HXK_HXK2"], v["PDC_PDC1"], 
    v["PDC_PDC5"], v["PDC_PDC6"], v["PFK"], v["PGI"], v["PGK"], v["PGM"], 
    v["PYK_CDC19"], v["PYK_PYK2"], v["TDH_TDH1"], v["TDH_TDH2"], 
    v["TDH_TDH3"], v["TPI"], v["TPP"], v["TPS"], v["UGP"], 
    v["acetate_branch"], v["succinate_branch"], v["udp_to_utp"], v["HXT"]}, 
  "Constraints" -> {v["ATPase"] -> {0, Infinity}, v["GPP"] -> {0, Infinity}, 
    v["PDC_PDC1"] -> {0, Infinity}, v["PDC_PDC5"] -> {0, Infinity}, 
    v["PDC_PDC6"] -> {0, Infinity}, v["PFK"] -> {0, Infinity}, 
    v["TPP"] -> {0, Infinity}, v["TPS"] -> {0, Infinity}, 
    v["UGP"] -> {0, Infinity}, v["acetate_branch"] -> {0, Infinity}, 
    v["succinate_branch"] -> {0, Infinity}, v["udp_to_utp"] -> 
     {0, Infinity}}, "InitialConditions" -> 
   {species["ADP", "cell"] -> Unit[1.29, "mmol"/"Liter"], 
    species["ATP", "cell"] -> Unit[4.29, "mmol"/"Liter"], 
    species["AcAld", "cell"] -> Unit[0.178140579850657, "mmol"/"Liter"], 
    species["BPG", "cell"] -> Unit[0.000736873499865602, "mmol"/"Liter"], 
    species["NAD", "cell"] -> Unit[1.50329030201531, "mmol"/"Liter"], 
    species["P2G", "cell"] -> Unit[0.0677379081099344, "mmol"/"Liter"], 
    species["P3G", "cell"] -> Unit[0.469825011134444, "mmol"/"Liter"], 
    species["T6P", "cell"] -> Unit[0.02, "mmol"/"Liter"], 
    species["UDP", "cell"] -> Unit[0.2815, "mmol"/"Liter"], 
    species["UTP", "cell"] -> Unit[0.6491, "mmol"/"Liter"], 
    species["AMP", "cell"] -> 
     0.5*(6.02 + Abs[6.02 + Unit[-5.58, "mmol"/"Liter"]] + 
       Unit[-5.58, "mmol"/"Liter"]), species["NADH", "cell"] -> 
     0.5*(1.59 + Abs[1.59 + Unit[-1.50329030201531, "mmol"/"Liter"]] + 
       Unit[-1.50329030201531, "mmol"/"Liter"]), species["UDG", "cell"] -> 
     0.5*(1.39784619487425 + Abs[1.39784619487425 + Unit[-0.9306, 
          "mmol"/"Liter"]] + Unit[-0.9306, "mmol"/"Liter"]), 
    parameter["energy_charge"] -> Unit[0.8197674418604652, "mmol"/"Liter"], 
    parameter["fit_conc"] -> 0.3333333333333333*
      Sqrt[3.5745259767827097*^-31 + (1. + Unit[-0.9999997400590439, 
           "mmol"/"Liter"])^2], parameter["sum_PXG"] -> 
     Unit[0.5375629192443784, "mmol"/"Liter"], species["DHAP", "cell"] -> 
     1.1613768527466979, species["F16bP", "cell"] -> 4.58321859006931, 
    species["F6P", "cell"] -> 0.23544122189122135, 
    species["G6P", "cell"] -> 0.7724832036452156, species["GAP", "cell"] -> 
     0.31589102877050346, species["GLC", "cell"] -> 6.280001793382418, 
    species["G3P", "cell"] -> 0.2740029291912841, species["G1P", "cell"] -> 
     0.5392485063449205, species["PEP", "cell"] -> 0.610005413358042, 
    species["PYR", "cell"] -> 2.1084714071741937}, 
  "Parameters" -> {parameter["Keq_ADH"] -> 14492.7536231884, 
    parameter["Keq_ENO"] -> 6.7, parameter["Keq_HXK"] -> 2000., 
    parameter["Keq_PYK"] -> 6500., parameter["Keq_TDH"] -> 
     0.00533412710224736, parameter["NA"] -> 6.02214*^20, 
    parameter["sum_AXP"] -> 6.02, parameter["sum_NAD"] -> 1.59, 
    parameter["sum_UXP"] -> 1.39784619487425, parameter["volume"] -> 5.*^-15, 
    parameter["Volume", "cell"] -> Unit[1., "Liter"], 
    parameter["Volume", "extracellular"] -> Unit[1., "Liter"], 
    species["F26bP", "cell"] -> Unit[0.003, "mmol"/"Liter"], 
    species["GLCx", "extracellular"] -> Unit[74., "mmol"/"Liter"], 
    species["GLY", "cell"] -> Unit[0.15, "mmol"/"Liter"], 
    species["SUC", "cell"] -> Unit[0., "mmol"/"Liter"], 
    species["TDH2", "cell"] -> Unit[0., "mmol"/"Liter"], 
    parameter["kcat", "ADH_ADH1"] -> 176., parameter["Ketoh", "ADH_ADH1"] -> 
     17., parameter["Kinad", "ADH_ADH1"] -> 0.92, 
    parameter["Knad", "ADH_ADH1"] -> 0.17, parameter["Knadh", "ADH_ADH1"] -> 
     0.11, parameter["Kinadh", "ADH_ADH1"] -> 0.031, 
    parameter["Kacald", "ADH_ADH1"] -> 0.4622, 
    parameter["Kiacald", "ADH_ADH1"] -> 1.1, 
    parameter["Kietoh", "ADH_ADH1"] -> 90., parameter["kcat", "ADH_ADH5"] -> 
     0., parameter["Ketoh", "ADH_ADH5"] -> 17., 
    parameter["Kinad", "ADH_ADH5"] -> 0.92, parameter["Knad", "ADH_ADH5"] -> 
     0.17, parameter["Knadh", "ADH_ADH5"] -> 0.11, 
    parameter["Kinadh", "ADH_ADH5"] -> 0.031, 
    parameter["Kacald", "ADH_ADH5"] -> 1.11, 
    parameter["Kiacald", "ADH_ADH5"] -> 1.1, 
    parameter["Kietoh", "ADH_ADH5"] -> 90., parameter["k", "AK"] -> 0.75, 
    parameter["Keq", "AK"] -> 0.45, parameter["Vmax", "ATPase"] -> 6.16, 
    parameter["Katp", "ATPase"] -> 3., parameter["kcat", "ENO_ENO1"] -> 7.6, 
    parameter["Kp2g", "ENO_ENO1"] -> 0.043, parameter["Kpep", "ENO_ENO1"] -> 
     0.5, parameter["kcat", "ENO_ENO2"] -> 19.87, 
    parameter["Kp2g", "ENO_ENO2"] -> 0.104, parameter["Kpep", "ENO_ENO2"] -> 
     0.5, parameter["kcat", "FBA"] -> 4.139, parameter["Kf16bp", "FBA"] -> 
     0.4507, parameter["Keq", "FBA"] -> 0.069, parameter["Kdhap", "FBA"] -> 
     2., parameter["Kgap", "FBA"] -> 2.4, parameter["Kigap", "FBA"] -> 10., 
    parameter["Vmax", "GPD"] -> 0.783333333333333, 
    parameter["Knadh", "GPD"] -> 0.023, parameter["Kdhap", "GPD"] -> 0.54, 
    parameter["Keq", "GPD"] -> 10000., parameter["Kfbp", "GPD"] -> 4.8, 
    parameter["Katp", "GPD"] -> 0.73, parameter["Kadp", "GPD"] -> 2., 
    parameter["Knad", "GPD"] -> 0.93, parameter["Kg3p", "GPD"] -> 1.2, 
    parameter["kcat", "GPM"] -> 400., parameter["Kp3g", "GPM"] -> 1.2, 
    parameter["Keq", "GPM"] -> 0.19, parameter["Kp2g", "GPM"] -> 1.41, 
    parameter["Vmax", "GPP"] -> 0.883333333333333, 
    parameter["Kg3p", "GPP"] -> 3.5, parameter["kcat", "HXK_GLK1"] -> 0.0721, 
    parameter["Kglc", "HXK_GLK1"] -> 0.0106, parameter["Katp", "HXK_GLK1"] -> 
     0.865, parameter["Kg6p", "HXK_GLK1"] -> 30., 
    parameter["Kadp", "HXK_GLK1"] -> 0.23, parameter["kcat", "HXK_HXK1"] -> 
     10.2, parameter["Kglc", "HXK_HXK1"] -> 0.15, 
    parameter["Katp", "HXK_HXK1"] -> 0.293, parameter["Kg6p", "HXK_HXK1"] -> 
     30., parameter["Kadp", "HXK_HXK1"] -> 0.23, 
    parameter["Kit6p", "HXK_HXK1"] -> 0.2, parameter["kcat", "HXK_HXK2"] -> 
     63.1, parameter["Kglc", "HXK_HXK2"] -> 0.2, 
    parameter["Katp", "HXK_HXK2"] -> 0.195, parameter["Kg6p", "HXK_HXK2"] -> 
     30., parameter["Kadp", "HXK_HXK2"] -> 0.23, 
    parameter["Kit6p", "HXK_HXK2"] -> 0.04, parameter["kcat", "PDC_PDC1"] -> 
     12.14, parameter["Kpyr", "PDC_PDC1"] -> 8.5, 
    parameter["kcat", "PDC_PDC5"] -> 10.32, parameter["Kpyr", "PDC_PDC5"] -> 
     7.08, parameter["kcat", "PDC_PDC6"] -> 9.21, 
    parameter["Kpyr", "PDC_PDC6"] -> 2.92, parameter["kcat", "PFK"] -> 209.6, 
    parameter["gR", "PFK"] -> 5.12, parameter["Kf6p", "PFK"] -> 0.1, 
    parameter["Katp", "PFK"] -> 0.71, parameter["L0", "PFK"] -> 0.66, 
    parameter["Ciatp", "PFK"] -> 100., parameter["Kiatp", "PFK"] -> 0.65, 
    parameter["Camp", "PFK"] -> 0.0845, parameter["Kamp", "PFK"] -> 0.0995, 
    parameter["Cf26", "PFK"] -> 0.0174, parameter["Kf26", "PFK"] -> 0.000682, 
    parameter["Cf16", "PFK"] -> 0.397, parameter["Kf16", "PFK"] -> 0.111, 
    parameter["Catp", "PFK"] -> 3., parameter["Kadp", "PFK"] -> 1., 
    parameter["Keq", "PFK"] -> 800., parameter["kcat", "PGI"] -> 487.36, 
    parameter["Kg6p", "PGI"] -> 1.0257, parameter["Keq", "PGI"] -> 0.29, 
    parameter["Kf6p", "PGI"] -> 0.307, parameter["kcat", "PGK"] -> 58.6, 
    parameter["Keq", "PGK"] -> 3200., parameter["Kp3g", "PGK"] -> 4.58, 
    parameter["Katp", "PGK"] -> 1.99, parameter["Kbpg", "PGK"] -> 0.003, 
    parameter["Kadp", "PGK"] -> 0.2, parameter["nHadp", "PGK"] -> 2., 
    parameter["Vmax", "PGM"] -> 0.12762, parameter["Kg6p", "PGM"] -> 0.05, 
    parameter["Kg1p", "PGM"] -> 0.023, parameter["Keq", "PGM"] -> 0.1667, 
    parameter["kcat", "PYK_CDC19"] -> 20.146, 
    parameter["Kpep", "PYK_CDC19"] -> 0.281, 
    parameter["Kadp", "PYK_CDC19"] -> 0.243, 
    parameter["Kpyr", "PYK_CDC19"] -> 21., parameter["Katp", "PYK_CDC19"] -> 
     1.5, parameter["Kiatp", "PYK_CDC19"] -> 9.3, 
    parameter["Kf16p", "PYK_CDC19"] -> 0.2, parameter["L0", "PYK_CDC19"] -> 
     100., parameter["kcat", "PYK_PYK2"] -> 0., 
    parameter["Kpep", "PYK_PYK2"] -> 0.19, parameter["Kadp", "PYK_PYK2"] -> 
     0.3, parameter["Kpyr", "PYK_PYK2"] -> 21., 
    parameter["Katp", "PYK_PYK2"] -> 1.5, parameter["Kiatp", "PYK_PYK2"] -> 
     9.3, parameter["Kf16p", "PYK_PYK2"] -> 0.2, 
    parameter["L0", "PYK_PYK2"] -> 100., parameter["kcat", "TDH_TDH1"] -> 
     19.12, parameter["Kgap", "TDH_TDH1"] -> 0.495, 
    parameter["Knad", "TDH_TDH1"] -> 0.09, parameter["Kbpg", "TDH_TDH1"] -> 
     0.0098, parameter["Knadh", "TDH_TDH1"] -> 0.06, 
    parameter["kcat", "TDH_TDH2"] -> 8.633, parameter["Kgap", "TDH_TDH2"] -> 
     0.77, parameter["Knad", "TDH_TDH2"] -> 0.09, 
    parameter["Kbpg", "TDH_TDH2"] -> 0.0098, 
    parameter["Knadh", "TDH_TDH2"] -> 0.06, parameter["kcat", "TDH_TDH3"] -> 
     18.162, parameter["Kgap", "TDH_TDH3"] -> 0.423, 
    parameter["Knad", "TDH_TDH3"] -> 0.09, parameter["Kbpg", "TDH_TDH3"] -> 
     0.909, parameter["Knadh", "TDH_TDH3"] -> 0.06, 
    parameter["kcat", "TPI"] -> 564.38, parameter["Kdhap", "TPI"] -> 6.454, 
    parameter["Kgap", "TPI"] -> 5.25, parameter["Kigap", "TPI"] -> 35.1, 
    parameter["Keq", "TPI"] -> 0.045, parameter["Vmax", "TPP"] -> 
     2.33999999999999, parameter["Kt6p", "TPP"] -> 0.5, 
    parameter["Vmax", "TPS"] -> 0.49356, parameter["Kg6p", "TPS"] -> 3.8, 
    parameter["Kudg", "TPS"] -> 0.886, parameter["Vmax", "UGP"] -> 13.2552, 
    parameter["Kutp", "UGP"] -> 0.11, parameter["Kiutp", "UGP"] -> 0.11, 
    parameter["Kg1p", "UGP"] -> 0.32, parameter["Kiudg", "UGP"] -> 0.0035, 
    parameter["k", "acetate_branch"] -> 0.00554339592436782, 
    parameter["k", "succinate_branch"] -> 0., parameter["k", "udp_to_utp"] -> 
     0.0745258294103764, parameter["Vmax", "HXT"] -> 3.35, 
    parameter["Kglc", "HXT"] -> 0.9, parameter["Ki", "HXT"] -> 0.91, 
    species["ADH1", "cell"] -> 0.16390851092800895, 
    species["ADH5", "cell"] -> 0.004249984224876871, 
    species["ACE", "cell"] -> 223.0002533982936, species["CDC19", "cell"] -> 
     2.0483901071712047, species["EtOH", "cell"] -> 221.89031141753594, 
    species["ENO1", "cell"] -> 0.6863719541558316, 
    species["ENO2", "cell"] -> 1.9744462931781723, 
    species["FBA1", "cell"] -> 1.338394657048823, species["GPM1", "cell"] -> 
     0.7300002988970697, species["GLK1", "cell"] -> 0.04508696244192263, 
    species["GPD1", "cell"] -> 0.006835111770898716, 
    species["GPD2", "cell"] -> 0.0007934056664242278, 
    species["HXK1", "cell"] -> 0.016780745714978396, 
    species["HXK2", "cell"] -> 0.06133135397051546, 
    species["HOR2", "cell"] -> 0.005473469563975596, 
    species["PDC1", "cell"] -> 1.0678107782283373, 
    species["PDC5", "cell"] -> 0.01235474432676756, 
    species["PDC6", "cell"] -> 0.006540864211061184, 
    species["PFK1", "cell"] -> 0.04678502990631237, 
    species["PFK2", "cell"] -> 0.03903662153320912, 
    species["PGI1", "cell"] -> 0.1382907072900995, 
    species["PGK1", "cell"] -> 0.2576569126589551, 
    species["PYK2", "cell"] -> 0.006069935272178991, 
    species["PGM1", "cell"] -> 0.0032622954630745875, 
    species["PGM2", "cell"] -> 0.0012586887717655185, 
    species["RHR2", "cell"] -> 0.05118047737183127, 
    species["TRH", "cell"] -> 0.015387885369652647, 
    species["TDH1", "cell"] -> 0.3508646428013962, 
    species["TDH3", "cell"] -> 4.204404746485468, species["TPI1", "cell"] -> 
     0.29435781964550806, species["TPS1", "cell"] -> 0.003392481742370652, 
    species["TPS2", "cell"] -> 0.0026598518134749436, 
    species["UGP1", "cell"] -> 0.006202114198607139}, "GPR" -> {}, 
  "BoundaryConditions" -> {species["AMP", "cell"], species["NADH", "cell"], 
    species["UDG", "cell"]}, "Constant" -> {species["ACE", "cell"], 
    species["EtOH", "cell"], species["F26bP", "cell"], 
    species["GLCx", "extracellular"], species["GLY", "cell"], 
    species["SUC", "cell"], species["TRH", "cell"], species["ADH1", "cell"], 
    species["ADH5", "cell"], species["CDC19", "cell"], 
    species["ENO1", "cell"], species["ENO2", "cell"], 
    species["FBA1", "cell"], species["GLK1", "cell"], 
    species["GPD1", "cell"], species["GPD2", "cell"], 
    species["GPM1", "cell"], species["HOR2", "cell"], 
    species["HXK1", "cell"], species["HXK2", "cell"], 
    species["PDC1", "cell"], species["PDC5", "cell"], 
    species["PDC6", "cell"], species["PFK1", "cell"], 
    species["PFK2", "cell"], species["PGI1", "cell"], 
    species["PGK1", "cell"], species["PGM1", "cell"], 
    species["PGM2", "cell"], species["PYK2", "cell"], 
    species["RHR2", "cell"], species["TDH1", "cell"], 
    species["TDH2", "cell"], species["TDH3", "cell"], 
    species["TPI1", "cell"], species["TPS1", "cell"], 
    species["TPS2", "cell"], species["UGP1", "cell"]}, 
  "ReversibleColumnIndices" -> {1, 2, 3, 5, 6, 7, 8, 9, 11, 12, 13, 18, 19, 
    20, 21, 22, 23, 24, 25, 26, 33}, "CustomRateLaws" -> 
   {v["ADH_ADH1"] -> (parameter["kcat", "ADH_ADH1"]*parameter["Volume", 
        "cell"]*species["ADH1", "cell"]*
       (-((species["EtOH", "cell"]*species["NAD", "cell"][t])/
          (parameter["Keq_ADH"]*parameter["Kacald", "ADH_ADH1"]*
           parameter["Kinadh", "ADH_ADH1"])) + 
        (species["AcAld", "cell"][t]*species["NADH", "cell"][t])/
         (parameter["Kacald", "ADH_ADH1"]*parameter["Kinadh", "ADH_ADH1"])))/
      (1 + (parameter["Knad", "ADH_ADH1"]*species["EtOH", "cell"])/
        (parameter["Ketoh", "ADH_ADH1"]*parameter["Kinad", "ADH_ADH1"]) + 
       (parameter["Knadh", "ADH_ADH1"]*species["AcAld", "cell"][t])/
        (parameter["Kacald", "ADH_ADH1"]*parameter["Kinadh", "ADH_ADH1"]) + 
       species["NAD", "cell"][t]/parameter["Kinad", "ADH_ADH1"] + 
       (species["EtOH", "cell"]*species["NAD", "cell"][t])/
        (parameter["Ketoh", "ADH_ADH1"]*parameter["Kinad", "ADH_ADH1"]) + 
       (parameter["Knadh", "ADH_ADH1"]*species["AcAld", "cell"][t]*
         species["NAD", "cell"][t])/(parameter["Kacald", "ADH_ADH1"]*
         parameter["Kinad", "ADH_ADH1"]*parameter["Kinadh", "ADH_ADH1"]) + 
       (species["EtOH", "cell"]*species["AcAld", "cell"][t]*
         species["NAD", "cell"][t])/(parameter["Ketoh", "ADH_ADH1"]*
         parameter["Kiacald", "ADH_ADH1"]*parameter["Kinad", "ADH_ADH1"]) + 
       species["NADH", "cell"][t]/parameter["Kinadh", "ADH_ADH1"] + 
       (parameter["Knad", "ADH_ADH1"]*species["EtOH", "cell"]*
         species["NADH", "cell"][t])/(parameter["Ketoh", "ADH_ADH1"]*
         parameter["Kinad", "ADH_ADH1"]*parameter["Kinadh", "ADH_ADH1"]) + 
       (species["AcAld", "cell"][t]*species["NADH", "cell"][t])/
        (parameter["Kacald", "ADH_ADH1"]*parameter["Kinadh", "ADH_ADH1"]) + 
       (species["EtOH", "cell"]*species["AcAld", "cell"][t]*
         species["NADH", "cell"][t])/(parameter["Kacald", "ADH_ADH1"]*
         parameter["Kietoh", "ADH_ADH1"]*parameter["Kinadh", "ADH_ADH1"])), 
    v["ADH_ADH5"] -> (parameter["kcat", "ADH_ADH5"]*parameter["Volume", 
        "cell"]*species["ADH5", "cell"]*
       (-((species["EtOH", "cell"]*species["NAD", "cell"][t])/
          (parameter["Keq_ADH"]*parameter["Kacald", "ADH_ADH5"]*
           parameter["Kinadh", "ADH_ADH5"])) + 
        (species["AcAld", "cell"][t]*species["NADH", "cell"][t])/
         (parameter["Kacald", "ADH_ADH5"]*parameter["Kinadh", "ADH_ADH5"])))/
      (1 + (parameter["Knad", "ADH_ADH5"]*species["EtOH", "cell"])/
        (parameter["Ketoh", "ADH_ADH5"]*parameter["Kinad", "ADH_ADH5"]) + 
       (parameter["Knadh", "ADH_ADH5"]*species["AcAld", "cell"][t])/
        (parameter["Kacald", "ADH_ADH5"]*parameter["Kinadh", "ADH_ADH5"]) + 
       species["NAD", "cell"][t]/parameter["Kinad", "ADH_ADH5"] + 
       (species["EtOH", "cell"]*species["NAD", "cell"][t])/
        (parameter["Ketoh", "ADH_ADH5"]*parameter["Kinad", "ADH_ADH5"]) + 
       (parameter["Knadh", "ADH_ADH5"]*species["AcAld", "cell"][t]*
         species["NAD", "cell"][t])/(parameter["Kacald", "ADH_ADH5"]*
         parameter["Kinad", "ADH_ADH5"]*parameter["Kinadh", "ADH_ADH5"]) + 
       (species["EtOH", "cell"]*species["AcAld", "cell"][t]*
         species["NAD", "cell"][t])/(parameter["Ketoh", "ADH_ADH5"]*
         parameter["Kiacald", "ADH_ADH5"]*parameter["Kinad", "ADH_ADH5"]) + 
       species["NADH", "cell"][t]/parameter["Kinadh", "ADH_ADH5"] + 
       (parameter["Knad", "ADH_ADH5"]*species["EtOH", "cell"]*
         species["NADH", "cell"][t])/(parameter["Ketoh", "ADH_ADH5"]*
         parameter["Kinad", "ADH_ADH5"]*parameter["Kinadh", "ADH_ADH5"]) + 
       (species["AcAld", "cell"][t]*species["NADH", "cell"][t])/
        (parameter["Kacald", "ADH_ADH5"]*parameter["Kinadh", "ADH_ADH5"]) + 
       (species["EtOH", "cell"]*species["AcAld", "cell"][t]*
         species["NADH", "cell"][t])/(parameter["Kacald", "ADH_ADH5"]*
         parameter["Kietoh", "ADH_ADH5"]*parameter["Kinadh", "ADH_ADH5"])), 
    v["AK"] -> parameter["k", "AK"]*parameter["Volume", "cell"]*
      (species["ADP", "cell"][t]^2 - (species["AMP", "cell"][t]*
         species["ATP", "cell"][t])/parameter["Keq", "AK"]), 
    v["ATPase"] -> (parameter["Vmax", "ATPase"]*parameter["Volume", "cell"]*
       species["ATP", "cell"][t])/(parameter["Katp", "ATPase"]*
       (1 + species["ATP", "cell"][t]/parameter["Katp", "ATPase"])), 
    v["ENO_ENO1"] -> (parameter["kcat", "ENO_ENO1"]*parameter["Volume", 
        "cell"]*species["ENO1", "cell"]*(species["P2G", "cell"][t]/
         parameter["Kp2g", "ENO_ENO1"] - species["PEP", "cell"][t]/
         (parameter["Keq_ENO"]*parameter["Kp2g", "ENO_ENO1"])))/
      (1 + species["P2G", "cell"][t]/parameter["Kp2g", "ENO_ENO1"] + 
       species["PEP", "cell"][t]/parameter["Kpep", "ENO_ENO1"]), 
    v["ENO_ENO2"] -> (parameter["kcat", "ENO_ENO2"]*parameter["Volume", 
        "cell"]*species["ENO2", "cell"]*(species["P2G", "cell"][t]/
         parameter["Kp2g", "ENO_ENO2"] - species["PEP", "cell"][t]/
         (parameter["Keq_ENO"]*parameter["Kp2g", "ENO_ENO2"])))/
      (1 + species["P2G", "cell"][t]/parameter["Kp2g", "ENO_ENO2"] + 
       species["PEP", "cell"][t]/parameter["Kpep", "ENO_ENO2"]), 
    v["FBA"] -> (parameter["kcat", "FBA"]*parameter["Volume", "cell"]*
       species["FBA1", "cell"]*(species["F16bP", "cell"][t]/
         parameter["Kf16bp", "FBA"] - (species["DHAP", "cell"][t]*
          species["GAP", "cell"][t])/(parameter["Keq", "FBA"]*
          parameter["Kf16bp", "FBA"])))/(1 + species["DHAP", "cell"][t]/
        parameter["Kdhap", "FBA"] + species["F16bP", "cell"][t]/
        parameter["Kf16bp", "FBA"] + species["GAP", "cell"][t]/
        parameter["Kgap", "FBA"] + (species["DHAP", "cell"][t]*
         species["GAP", "cell"][t])/(parameter["Kdhap", "FBA"]*
         parameter["Kgap", "FBA"]) + (species["F16bP", "cell"][t]*
         species["GAP", "cell"][t])/(parameter["Kf16bp", "FBA"]*
         parameter["Kigap", "FBA"])), v["GPD"] -> 
     (parameter["Vmax", "GPD"]*parameter["Volume", "cell"]*
       (-((species["G3P", "cell"][t]*species["NAD", "cell"][t])/
          parameter["Keq", "GPD"]) + species["DHAP", "cell"][t]*
         species["NADH", "cell"][t]))/(parameter["Kdhap", "GPD"]*
       parameter["Knadh", "GPD"]*(1 + species["ADP", "cell"][t]/
         parameter["Kadp", "GPD"] + species["ATP", "cell"][t]/
         parameter["Katp", "GPD"] + species["F16bP", "cell"][t]/
         parameter["Kfbp", "GPD"])*(1 + species["DHAP", "cell"][t]/
         parameter["Kdhap", "GPD"] + species["G3P", "cell"][t]/
         parameter["Kg3p", "GPD"])*(1 + species["NAD", "cell"][t]/
         parameter["Knad", "GPD"] + species["NADH", "cell"][t]/
         parameter["Knadh", "GPD"])), v["GPM"] -> 
     (parameter["kcat", "GPM"]*parameter["Volume", "cell"]*
       species["GPM1", "cell"]*(-(species["P2G", "cell"][t]/
          (parameter["Keq", "GPM"]*parameter["Kp3g", "GPM"])) + 
        species["P3G", "cell"][t]/parameter["Kp3g", "GPM"]))/
      (1 + species["P2G", "cell"][t]/parameter["Kp2g", "GPM"] + 
       species["P3G", "cell"][t]/parameter["Kp3g", "GPM"]), 
    v["GPP"] -> (parameter["Vmax", "GPP"]*parameter["Volume", "cell"]*
       species["G3P", "cell"][t])/(parameter["Kg3p", "GPP"]*
       (1 + species["G3P", "cell"][t]/parameter["Kg3p", "GPP"])), 
    v["HXK_GLK1"] -> (parameter["kcat", "HXK_GLK1"]*parameter["Volume", 
        "cell"]*species["GLK1", "cell"]*
       (-((species["ADP", "cell"][t]*species["G6P", "cell"][t])/
          (parameter["Keq_HXK"]*parameter["Katp", "HXK_GLK1"]*
           parameter["Kglc", "HXK_GLK1"])) + (species["ATP", "cell"][t]*
          species["GLC", "cell"][t])/(parameter["Katp", "HXK_GLK1"]*
          parameter["Kglc", "HXK_GLK1"])))/
      ((1 + species["ADP", "cell"][t]/parameter["Kadp", "HXK_GLK1"] + 
        species["ATP", "cell"][t]/parameter["Katp", "HXK_GLK1"])*
       (1 + species["G6P", "cell"][t]/parameter["Kg6p", "HXK_GLK1"] + 
        species["GLC", "cell"][t]/parameter["Kglc", "HXK_GLK1"])), 
    v["HXK_HXK1"] -> (parameter["kcat", "HXK_HXK1"]*parameter["Volume", 
        "cell"]*species["HXK1", "cell"]*
       (-((species["ADP", "cell"][t]*species["G6P", "cell"][t])/
          (parameter["Keq_HXK"]*parameter["Katp", "HXK_HXK1"]*
           parameter["Kglc", "HXK_HXK1"])) + (species["ATP", "cell"][t]*
          species["GLC", "cell"][t])/(parameter["Katp", "HXK_HXK1"]*
          parameter["Kglc", "HXK_HXK1"])))/
      ((1 + species["ADP", "cell"][t]/parameter["Kadp", "HXK_HXK1"] + 
        species["ATP", "cell"][t]/parameter["Katp", "HXK_HXK1"])*
       (1 + species["G6P", "cell"][t]/parameter["Kg6p", "HXK_HXK1"] + 
        species["GLC", "cell"][t]/parameter["Kglc", "HXK_HXK1"] + 
        species["T6P", "cell"][t]/parameter["Kit6p", "HXK_HXK1"])), 
    v["HXK_HXK2"] -> (parameter["kcat", "HXK_HXK2"]*parameter["Volume", 
        "cell"]*species["HXK2", "cell"]*
       (-((species["ADP", "cell"][t]*species["G6P", "cell"][t])/
          (parameter["Keq_HXK"]*parameter["Katp", "HXK_HXK2"]*
           parameter["Kglc", "HXK_HXK2"])) + (species["ATP", "cell"][t]*
          species["GLC", "cell"][t])/(parameter["Katp", "HXK_HXK2"]*
          parameter["Kglc", "HXK_HXK2"])))/
      ((1 + species["ADP", "cell"][t]/parameter["Kadp", "HXK_HXK2"] + 
        species["ATP", "cell"][t]/parameter["Katp", "HXK_HXK2"])*
       (1 + species["G6P", "cell"][t]/parameter["Kg6p", "HXK_HXK2"] + 
        species["GLC", "cell"][t]/parameter["Kglc", "HXK_HXK2"] + 
        species["T6P", "cell"][t]/parameter["Kit6p", "HXK_HXK2"])), 
    v["PDC_PDC1"] -> (parameter["kcat", "PDC_PDC1"]*parameter["Volume", 
        "cell"]*species["PDC1", "cell"]*species["PYR", "cell"][t])/
      (parameter["Kpyr", "PDC_PDC1"]*(1 + species["PYR", "cell"][t]/
         parameter["Kpyr", "PDC_PDC1"])), v["PDC_PDC5"] -> 
     (parameter["kcat", "PDC_PDC5"]*parameter["Volume", "cell"]*
       species["PDC5", "cell"]*species["PYR", "cell"][t])/
      (parameter["Kpyr", "PDC_PDC5"]*(1 + species["PYR", "cell"][t]/
         parameter["Kpyr", "PDC_PDC5"])), v["PDC_PDC6"] -> 
     (parameter["kcat", "PDC_PDC6"]*parameter["Volume", "cell"]*
       species["PDC6", "cell"]*species["PYR", "cell"][t])/
      (parameter["Kpyr", "PDC_PDC6"]*(1 + species["PYR", "cell"][t]/
         parameter["Kpyr", "PDC_PDC6"])), 
    v["PFK"] -> (parameter["gR", "PFK"]*parameter["kcat", "PFK"]*
       parameter["Volume", "cell"]*
       (-Abs[species["PFK1", "cell"] - species["PFK2", "cell"]] + 
        species["PFK1", "cell"] + species["PFK2", "cell"])*
       species["ATP", "cell"][t]*(1 - (species["ADP", "cell"][t]*
          species["F16bP", "cell"][t])/(parameter["Keq", "PFK"]*
          species["ATP", "cell"][t]*species["F6P", "cell"][t]))*
       species["F6P", "cell"][t]*(1 + species["ADP", "cell"][t]/
         parameter["Kadp", "PFK"] + species["ATP", "cell"][t]/
         parameter["Katp", "PFK"] + species["F16bP", "cell"][t]/
         parameter["Kf16", "PFK"] + (parameter["gR", "PFK"]*
          species["ADP", "cell"][t]*species["F16bP", "cell"][t])/
         (parameter["Kadp", "PFK"]*parameter["Kf16", "PFK"]) + 
        species["F6P", "cell"][t]/parameter["Kf6p", "PFK"] + 
        (parameter["gR", "PFK"]*species["ATP", "cell"][t]*
          species["F6P", "cell"][t])/(parameter["Katp", "PFK"]*
          parameter["Kf6p", "PFK"])))/(2*parameter["Katp", "PFK"]*
       parameter["Kf6p", "PFK"]*((parameter["L0", "PFK"]*
          (1 + (parameter["Camp", "PFK"]*species["AMP", "cell"][t])/
             parameter["Kamp", "PFK"])^2*
          (1 + (parameter["Catp", "PFK"]*species["ATP", "cell"][t])/
             parameter["Katp", "PFK"])^2*
          (1 + (parameter["Ciatp", "PFK"]*species["ATP", "cell"][t])/
             parameter["Kiatp", "PFK"])^2*
          (1 + (parameter["Cf26", "PFK"]*species["F26bP", "cell"])/
             parameter["Kf26", "PFK"] + (parameter["Cf16", "PFK"]*
              species["F16bP", "cell"][t])/parameter["Kf16", "PFK"])^2)/
         ((1 + species["AMP", "cell"][t]/parameter["Kamp", "PFK"])^2*
          (1 + species["ATP", "cell"][t]/parameter["Kiatp", "PFK"])^2*
          (1 + species["F26bP", "cell"]/parameter["Kf26", "PFK"] + 
            species["F16bP", "cell"][t]/parameter["Kf16", "PFK"])^2) + 
        (1 + species["ADP", "cell"][t]/parameter["Kadp", "PFK"] + 
          species["ATP", "cell"][t]/parameter["Katp", "PFK"] + 
          species["F16bP", "cell"][t]/parameter["Kf16", "PFK"] + 
          (parameter["gR", "PFK"]*species["ADP", "cell"][t]*
            species["F16bP", "cell"][t])/(parameter["Kadp", "PFK"]*
            parameter["Kf16", "PFK"]) + species["F6P", "cell"][t]/
           parameter["Kf6p", "PFK"] + (parameter["gR", "PFK"]*
            species["ATP", "cell"][t]*species["F6P", "cell"][t])/
           (parameter["Katp", "PFK"]*parameter["Kf6p", "PFK"]))^2)), 
    v["PGI"] -> (parameter["kcat", "PGI"]*parameter["Volume", "cell"]*
       species["PGI1", "cell"]*(-(species["F6P", "cell"][t]/
          (parameter["Keq", "PGI"]*parameter["Kg6p", "PGI"])) + 
        species["G6P", "cell"][t]/parameter["Kg6p", "PGI"]))/
      (1 + species["F6P", "cell"][t]/parameter["Kf6p", "PGI"] + 
       species["G6P", "cell"][t]/parameter["Kg6p", "PGI"]), 
    v["PGK"] -> (parameter["kcat", "PGK"]*parameter["Volume", "cell"]*
       species["PGK1", "cell"]*(species["ADP", "cell"][t]/
         parameter["Kadp", "PGK"])^(-1 + parameter["nHadp", "PGK"])*
       ((species["ADP", "cell"][t]*species["BPG", "cell"][t])/
         (parameter["Kadp", "PGK"]*parameter["Kbpg", "PGK"]) - 
        (species["ATP", "cell"][t]*species["P3G", "cell"][t])/
         (parameter["Kadp", "PGK"]*parameter["Kbpg", "PGK"]*
          parameter["Keq", "PGK"])))/
      ((1 + (species["ADP", "cell"][t]/parameter["Kadp", "PGK"])^
         parameter["nHadp", "PGK"] + species["ATP", "cell"][t]/
         parameter["Katp", "PGK"])*(1 + species["BPG", "cell"][t]/
         parameter["Kbpg", "PGK"] + species["P3G", "cell"][t]/
         parameter["Kp3g", "PGK"])), v["PGM"] -> 
     (parameter["Vmax", "PGM"]*parameter["Volume", "cell"]*
       (-(species["G1P", "cell"][t]/(parameter["Keq", "PGM"]*
           parameter["Kg6p", "PGM"])) + species["G6P", "cell"][t]/
         parameter["Kg6p", "PGM"]))/(1 + species["G1P", "cell"][t]/
        parameter["Kg1p", "PGM"] + species["G6P", "cell"][t]/
        parameter["Kg6p", "PGM"]), v["PYK_CDC19"] -> 
     (parameter["kcat", "PYK_CDC19"]*parameter["Volume", "cell"]*
       species["CDC19", "cell"]*(species["ADP", "cell"][t]*
         species["PEP", "cell"][t] - (species["ATP", "cell"][t]*
          species["PYR", "cell"][t])/parameter["Keq_PYK"]))/
      (parameter["Kadp", "PYK_CDC19"]*parameter["Kpep", "PYK_CDC19"]*
       (1 + species["ADP", "cell"][t]/parameter["Kadp", "PYK_CDC19"] + 
        species["ATP", "cell"][t]/parameter["Katp", "PYK_CDC19"])*
       (1 + (parameter["L0", "PYK_CDC19"]*(1 + species["ATP", "cell"][t]/
            parameter["Kiatp", "PYK_CDC19"]))/
         (1 + species["F16bP", "cell"][t]/parameter["Kf16p", "PYK_CDC19"]) + 
        species["PEP", "cell"][t]/parameter["Kpep", "PYK_CDC19"] + 
        species["PYR", "cell"][t]/parameter["Kpyr", "PYK_CDC19"])), 
    v["PYK_PYK2"] -> (parameter["kcat", "PYK_PYK2"]*parameter["Volume", 
        "cell"]*species["PYK2", "cell"]*(species["ADP", "cell"][t]*
         species["PEP", "cell"][t] - (species["ATP", "cell"][t]*
          species["PYR", "cell"][t])/parameter["Keq_PYK"]))/
      (parameter["Kadp", "PYK_PYK2"]*parameter["Kpep", "PYK_PYK2"]*
       (1 + species["ADP", "cell"][t]/parameter["Kadp", "PYK_PYK2"] + 
        species["ATP", "cell"][t]/parameter["Katp", "PYK_PYK2"])*
       (1 + (parameter["L0", "PYK_PYK2"]*(1 + species["ATP", "cell"][t]/
            parameter["Kiatp", "PYK_PYK2"]))/(1 + species["F16bP", "cell"][t]/
           parameter["Kf16p", "PYK_PYK2"]) + species["PEP", "cell"][t]/
         parameter["Kpep", "PYK_PYK2"] + species["PYR", "cell"][t]/
         parameter["Kpyr", "PYK_PYK2"])), v["TDH_TDH1"] -> 
     (parameter["kcat", "TDH_TDH1"]*parameter["Volume", "cell"]*
       species["TDH1", "cell"]*((species["GAP", "cell"][t]*
          species["NAD", "cell"][t])/(parameter["Kgap", "TDH_TDH1"]*
          parameter["Knad", "TDH_TDH1"]) - (species["BPG", "cell"][t]*
          species["NADH", "cell"][t])/(parameter["Keq_TDH"]*
          parameter["Kgap", "TDH_TDH1"]*parameter["Knad", "TDH_TDH1"])))/
      ((1 + species["BPG", "cell"][t]/parameter["Kbpg", "TDH_TDH1"] + 
        species["GAP", "cell"][t]/parameter["Kgap", "TDH_TDH1"])*
       (1 + species["NAD", "cell"][t]/parameter["Knad", "TDH_TDH1"] + 
        species["NADH", "cell"][t]/parameter["Knadh", "TDH_TDH1"])), 
    v["TDH_TDH2"] -> (parameter["kcat", "TDH_TDH2"]*parameter["Volume", 
        "cell"]*species["TDH2", "cell"]*
       ((species["GAP", "cell"][t]*species["NAD", "cell"][t])/
         (parameter["Kgap", "TDH_TDH2"]*parameter["Knad", "TDH_TDH2"]) - 
        (species["BPG", "cell"][t]*species["NADH", "cell"][t])/
         (parameter["Keq_TDH"]*parameter["Kgap", "TDH_TDH2"]*
          parameter["Knad", "TDH_TDH2"])))/
      ((1 + species["BPG", "cell"][t]/parameter["Kbpg", "TDH_TDH2"] + 
        species["GAP", "cell"][t]/parameter["Kgap", "TDH_TDH2"])*
       (1 + species["NAD", "cell"][t]/parameter["Knad", "TDH_TDH2"] + 
        species["NADH", "cell"][t]/parameter["Knadh", "TDH_TDH2"])), 
    v["TDH_TDH3"] -> (parameter["kcat", "TDH_TDH3"]*parameter["Volume", 
        "cell"]*species["TDH3", "cell"]*
       ((species["GAP", "cell"][t]*species["NAD", "cell"][t])/
         (parameter["Kgap", "TDH_TDH3"]*parameter["Knad", "TDH_TDH3"]) - 
        (species["BPG", "cell"][t]*species["NADH", "cell"][t])/
         (parameter["Keq_TDH"]*parameter["Kgap", "TDH_TDH3"]*
          parameter["Knad", "TDH_TDH3"])))/
      ((1 + species["BPG", "cell"][t]/parameter["Kbpg", "TDH_TDH3"] + 
        species["GAP", "cell"][t]/parameter["Kgap", "TDH_TDH3"])*
       (1 + species["NAD", "cell"][t]/parameter["Knad", "TDH_TDH3"] + 
        species["NADH", "cell"][t]/parameter["Knadh", "TDH_TDH3"])), 
    v["TPI"] -> (parameter["kcat", "TPI"]*parameter["Volume", "cell"]*
       species["TPI1", "cell"]*(species["DHAP", "cell"][t] - 
        species["GAP", "cell"][t]/parameter["Keq", "TPI"]))/
      (parameter["Kdhap", "TPI"]*(1 + species["DHAP", "cell"][t]/
         parameter["Kdhap", "TPI"] + (species["GAP", "cell"][t]*
          (1 + species["GAP", "cell"][t]^4/parameter["Kigap", "TPI"]^4))/
         parameter["Kgap", "TPI"])), v["TPP"] -> 
     (parameter["Vmax", "TPP"]*parameter["Volume", "cell"]*
       species["T6P", "cell"][t])/(parameter["Kt6p", "TPP"]*
       (1 + species["T6P", "cell"][t]/parameter["Kt6p", "TPP"])), 
    v["TPS"] -> (parameter["Vmax", "TPS"]*parameter["Volume", "cell"]*
       species["G6P", "cell"][t]*species["UDG", "cell"][t])/
      (parameter["Kg6p", "TPS"]*parameter["Kudg", "TPS"]*
       (1 + species["G6P", "cell"][t]/parameter["Kg6p", "TPS"])*
       (1 + species["UDG", "cell"][t]/parameter["Kudg", "TPS"])), 
    v["UGP"] -> (parameter["Vmax", "UGP"]*parameter["Volume", "cell"]*
       species["G1P", "cell"][t]*species["UTP", "cell"][t])/
      (parameter["Kg1p", "UGP"]*parameter["Kutp", "UGP"]*
       (parameter["Kiutp", "UGP"]/parameter["Kutp", "UGP"] + 
        species["G1P", "cell"][t]/parameter["Kg1p", "UGP"] + 
        (parameter["Kiutp", "UGP"]*species["UDG", "cell"][t])/
         (parameter["Kiudg", "UGP"]*parameter["Kutp", "UGP"]) + 
        (species["G1P", "cell"][t]*species["UDG", "cell"][t])/
         (parameter["Kg1p", "UGP"]*parameter["Kiudg", "UGP"]) + 
        species["UTP", "cell"][t]/parameter["Kutp", "UGP"] + 
        (species["G1P", "cell"][t]*species["UTP", "cell"][t])/
         (parameter["Kg1p", "UGP"]*parameter["Kutp", "UGP"]))), 
    v["acetate_branch"] -> parameter["k", "acetate_branch"]*
      parameter["Volume", "cell"]*species["AcAld", "cell"][t]*
      species["NAD", "cell"][t], v["succinate_branch"] -> 
     parameter["k", "succinate_branch"]*parameter["Volume", "cell"]*
      species["NAD", "cell"][t]*species["PYR", "cell"][t], 
    v["udp_to_utp"] -> parameter["k", "udp_to_utp"]*parameter["Volume", 
       "cell"]*species["ATP", "cell"][t]*species["UDP", "cell"][t], 
    v["HXT"] -> (parameter["Vmax", "HXT"]*parameter["Volume", "cell"]*
       (species["GLCx", "extracellular"] - species["GLC", "cell"][t]))/
      (parameter["Kglc", "HXT"]*(1 + species["GLCx", "extracellular"]/
         parameter["Kglc", "HXT"] + species["GLC", "cell"][t]/
         parameter["Kglc", "HXT"] + (parameter["Ki", "HXT"]*
          species["GLCx", "extracellular"]*species["GLC", "cell"][t])/
         parameter["Kglc", "HXT"]^2))}, "CustomODE" -> 
   {species["AMP", "cell"][t] == 
     (Abs[parameter["sum_AXP"] - species["ADP", "cell"][t] - 
         species["ATP", "cell"][t]] + parameter["sum_AXP"] - 
       species["ADP", "cell"][t] - species["ATP", "cell"][t])/2, 
    species["NADH", "cell"][t] == 
     (Abs[parameter["sum_NAD"] - species["NAD", "cell"][t]] + 
       parameter["sum_NAD"] - species["NAD", "cell"][t])/2, 
    species["UDG", "cell"][t] == 
     (Abs[parameter["sum_UXP"] - species["UDP", "cell"][t] - 
         species["UTP", "cell"][t]] + parameter["sum_UXP"] - 
       species["UDP", "cell"][t] - species["UTP", "cell"][t])/2, 
    parameter["energy_charge"][t] == (species["ADP", "cell"][t]/2 + 
       species["ATP", "cell"][t])/parameter["sum_AXP"], 
    parameter["fit_conc"][t] == 
     Sqrt[(1 - (parameter["NA"]*parameter["volume"]*parameter["sum_PXG"][t])/
           1618640)^2 + (1 - (parameter["NA"]*parameter["volume"]*
            species["DHAP", "cell"][t])/3496987)^2 + 
        (1 - (parameter["NA"]*parameter["volume"]*species["F16bP", "cell"][
             t])/13800392)^2 + (1 - (parameter["NA"]*parameter["volume"]*
            species["F6P", "cell"][t])/708930)^2 + 
        (1 - (parameter["NA"]*parameter["volume"]*species["G6P", "cell"][t])/
           2326001)^2 + (1 - (parameter["NA"]*parameter["volume"]*
            species["GAP", "cell"][t])/951170)^2 + 
        (1 - (parameter["NA"]*parameter["volume"]*species["GLC", "cell"][t])/
           18909525)^2 + (1 - (parameter["NA"]*parameter["volume"]*
            species["PEP", "cell"][t])/1836769)^2 + 
        (1 - (parameter["NA"]*parameter["volume"]*species["PYR", "cell"][t])/
           6348755)^2]/3, parameter["sum_PXG"][t] == 
     species["P2G", "cell"][t] + species["P3G", "cell"][t]}, 
  "Name" -> "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 18", 
  "ElementalComposition" -> {species["AcAld", "cell"] -> "&AcAld&", 
    species["ACE", "cell"] -> "&ACE&", species["ADP", "cell"] -> "&ADP&", 
    species["AMP", "cell"] -> "&AMP&", species["ATP", "cell"] -> "&ATP&", 
    species["BPG", "cell"] -> "&BPG&", species["DHAP", "cell"] -> "&DHAP&", 
    species["EtOH", "cell"] -> "&EtOH&", species["F16bP", "cell"] -> 
     "&F16bP&", species["F6P", "cell"] -> "&F6P&", 
    species["G1P", "cell"] -> "&G1P&", species["G3P", "cell"] -> "&G3P&", 
    species["G6P", "cell"] -> "&G6P&", species["GAP", "cell"] -> "&GAP&", 
    species["GLC", "cell"] -> "&GLC&", species["GLCx", "extracellular"] -> 
     "&GLCx&", species["GLY", "cell"] -> "&GLY&", species["NAD", "cell"] -> 
     "&NAD&", species["NADH", "cell"] -> "&NADH&", 
    species["P2G", "cell"] -> "&P2G&", species["P3G", "cell"] -> "&P3G&", 
    species["PEP", "cell"] -> "&PEP&", species["PYR", "cell"] -> "&PYR&", 
    species["SUC", "cell"] -> "&SUC&", species["T6P", "cell"] -> "&T6P&", 
    species["TRH", "cell"] -> "&TRH&", species["UDG", "cell"] -> "&UDG&", 
    species["UDP", "cell"] -> "&UDP&", species["UTP", "cell"] -> "&UTP&"}, 
  "Notes" -> "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 18  \n \
\nThis model is described in the article:  \n  A model of yeast glycolysis \
based on a consistent kinetic characterization of all its enzymes    \nKieran \
Smallbone, Hanan L. Messiha, Kathleen M. Carroll, Catherine L. Winder, Naglis \
Malys, Warwick B. Dunn, Ettore Murabito, Neil Swainston, Joseph O. Dada, \
Farid Khan, P\[DotlessI]nar Pir, Evangelos Simeonidis, Irena Spasi\[CAcute], \
Jill Wishart, Dieter Weichart, Neil W. Hayes, Daniel Jameson, David S. \
Broomhead, Stephen G. Oliver, Simon J. Gaskell, John E.G. McCarthy, Norman W. \
Paton, Hans V. Westerhoff, Douglas B. Kell, Pedro Mendes  \nFEBS Letters (in \
press)  \nAbstract:  \n \nWe present an experimental and computational \
pipeline for the generation of kinetic models of metabolism, and demonstrate \
its application to glycolysis in Saccharomyces cerevisiae. Starting from an \
approximate mathematical model, we employ a \[OpenCurlyDoubleQuote]cycle of \
knowledge\[CloseCurlyDoubleQuote] strategy, identifying the steps with most \
control over flux. Kinetic parameters of the individual isoenzymes within \
these steps are measured experimentally under a standardised set of \
conditions. Experimental strategies are applied to establish a set of in vivo \
concentrations for isoenzymes and metabolites. The data are integrated into a \
mathematical model that is used to predict a new set of metabolite \
concentrations and reevaluate the control properties of the system. This \
bottom-up modelling study reveals that control over the metabolic network \
most directly involved in yeast glycolysis is more widely distributed than \
previously thought.      \n \nThis model is hosted on BioModels Database and \
identified by: MODEL1303260018 .  \nTo cite BioModels Database, please use: \
BioModels Database: An enhanced, curated and annotated resource for published \
quantitative kinetic models .    \n \nTo the extent possible under law, all \
copyright and related or neighbouring rights to this encoded model have been \
dedicated to the public domain worldwide. Please refer to CC0 Public Domain \
Dedication for more information.", "Ignore" -> {}, "UnitChecking" -> False, 
  "Synonyms" -> {species["ADP", "cell"] -> "ADP", species["ATP", "cell"] -> 
     "ATP", species["AcAld", "cell"] -> "acetaldehyde", 
    species["BPG", "cell"] -> "1,3-bisphosphoglycerate", 
    species["DHAP", "cell"] -> "dihydroxyacetone phosphate", 
    species["F16bP", "cell"] -> "fructose 1,6-bisphosphate", 
    species["F6P", "cell"] -> "fructose 6-phosphate", 
    species["G1P", "cell"] -> "glucose 1-phosphate", 
    species["G3P", "cell"] -> "glycerol 3-phosphate", 
    species["G6P", "cell"] -> "glucose 6-phosphate", 
    species["GAP", "cell"] -> "glyceraldehyde 3-phosphate", 
    species["GLC", "cell"] -> "glucose", species["NAD", "cell"] -> "NAD", 
    species["P2G", "cell"] -> "2-phosphoglycerate", 
    species["P3G", "cell"] -> "3-phosphoglycerate", 
    species["PEP", "cell"] -> "phosphoenolpyruvate", 
    species["PYR", "cell"] -> "pyruvate", species["T6P", "cell"] -> 
     "trehalose 6-phosphate", species["UDP", "cell"] -> "UDP", 
    species["UTP", "cell"] -> "UTP", species["AMP", "cell"] -> "AMP", 
    species["NADH", "cell"] -> "NADH", species["UDG", "cell"] -> 
     "UDP glucose", species["ACE", "cell"] -> "acetate", 
    species["EtOH", "cell"] -> "ethanol", species["F26bP", "cell"] -> 
     "fructose 2,6-bisphosphate", species["GLCx", "extracellular"] -> 
     "glucose", species["GLY", "cell"] -> "glycerol", 
    species["SUC", "cell"] -> "succinate", species["TRH", "cell"] -> 
     "trehalose", species["ADH1", "cell"] -> "ADH1", 
    species["ADH5", "cell"] -> "ADH5", species["CDC19", "cell"] -> "CDC19", 
    species["ENO1", "cell"] -> "ENO1", species["ENO2", "cell"] -> "ENO2", 
    species["FBA1", "cell"] -> "FBA1", species["GLK1", "cell"] -> "GLK1", 
    species["GPD1", "cell"] -> "GPD1", species["GPD2", "cell"] -> "GPD2", 
    species["GPM1", "cell"] -> "GPM1", species["HOR2", "cell"] -> "HOR2", 
    species["HXK1", "cell"] -> "HXK1", species["HXK2", "cell"] -> "HXK2", 
    species["PDC1", "cell"] -> "PDC1", species["PDC5", "cell"] -> "PDC5", 
    species["PDC6", "cell"] -> "PDC6", species["PFK1", "cell"] -> "PFK1", 
    species["PFK2", "cell"] -> "PFK2", species["PGI1", "cell"] -> "PGI1", 
    species["PGK1", "cell"] -> "PGK1", species["PGM1", "cell"] -> "PGM1", 
    species["PGM2", "cell"] -> "PGM2", species["PYK2", "cell"] -> "PYK2", 
    species["RHR2", "cell"] -> "RHR2", species["TDH1", "cell"] -> "TDH1", 
    species["TDH2", "cell"] -> "TDH2", species["TDH3", "cell"] -> "TDH3", 
    species["TPI1", "cell"] -> "TPI1", species["TPS1", "cell"] -> "TPS1", 
    species["TPS2", "cell"] -> "TPS2", species["UGP1", "cell"] -> "UGP1"}, 
  "Events" -> {}}]
