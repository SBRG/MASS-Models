(* Created by Wolfram Mathematica 8.0 : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$105", "Stoichiometry" -> 
   SparseArray[Automatic, {17, 17}, 0, {1, {{0, 2, 4, 7, 9, 13, 15, 17, 19, 
      24, 26, 29, 32, 35, 37, 40, 42, 45}, {{3}, {11}, {7}, {8}, {7}, {8}, 
      {13}, {1}, {12}, {6}, {7}, {8}, {17}, {1}, {2}, {2}, {3}, {9}, {10}, 
      {1}, {2}, {9}, {10}, {15}, {2}, {16}, {1}, {3}, {9}, {5}, {6}, {14}, 
      {3}, {4}, {5}, {6}, {8}, {4}, {6}, {7}, {9}, {10}, {1}, {3}, {9}}}, {1, 
     -1, -1, 1, 1, 1, -1, -1, -1, 1, 1, -1, -1, 1, -1, 1, -1, 2, -2, 1, 1, 
     -1, 2, -1, -1, -1, -1, -1, 1, 1, -1, -1, 1, -1, -1, 1, -1, 1, -1, -1, 
     -1, 1, 1, 1, -1}}], "Species" -> {metabolite["co2", "c"], 
    metabolite["e4p", "c"], metabolite["f6p", "c"], metabolite["g6p", "c"], 
    metabolite["gap", "c"], metabolite["gl6p", "c"], metabolite["go6p", "c"], 
    metabolite["gsh", "c"], metabolite["h", "c"], metabolite["h2o", "c"], 
    metabolite["nadp", "c"], metabolite["r5p", "c"], metabolite["ru5p", "c"], 
    metabolite["s7p", "c"], metabolite["x5p", "c"], metabolite["gssg", "c"], 
    metabolite["nadph", "c"]}, "Fluxes" -> {v["vg6pdh"], v["vpglase"], 
    v["vgl6pdh"], v["vr5pe"], v["vr5pi"], v["vtki"], v["vtkii"], v["vtala"], 
    v["vgssgr"], v["vgshr"], v["vco2"], v["EX_g6p_c"], v["EX_f6p_c"], 
    v["EX_r5p_c"], v["EX_h_c"], v["EX_h2o_c"], v["EX_gap_c"]}, "GPR" -> {}, 
  "BoundaryConditions" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "Constant" -> {}, "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8, 9, 
    10, 11, 12, 13, 14, 15, 16, 17}, "CustomRateLaws" -> {}, 
  "CustomODE" -> {}, "Name" -> "MASSmodel$105", 
  "ElementalComposition" -> {metabolite["co2", "c"] -> "C" + 2*"O", 
    metabolite["e4p", "c"] -> 4*"C" + 7*"H" + 7*"O" + "P", 
    metabolite["f6p", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P", 
    metabolite["g6p", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P", 
    metabolite["gap", "c"] -> 3*"C" + 5*"H" + 6*"O" + "P", 
    metabolite["gl6p", "c"] -> 6*"C" + 9*"H" + 9*"O" + "P", 
    metabolite["go6p", "c"] -> 6*"C" + 10*"H" + 10*"O" + "P", 
    metabolite["gsh", "c"] -> 10*"C" + 17*"H" + 3*"N" + 6*"O" + "S", 
    metabolite["gssg", "c"] -> 20*"C" + 32*"H" + 6*"N" + 12*"O" + 2*"S", 
    metabolite["h", "c"] -> "H", metabolite["h2o", "c"] -> 2*"H" + "O", 
    metabolite["nadp", "c"] -> "NADP", metabolite["nadph", "c"] -> 
     "H" + "NADP", metabolite["r5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["ru5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["s7p", "c"] -> 7*"C" + 13*"H" + 10*"O" + "P", 
    metabolite["x5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P"}, 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "UnitChecking" -> True, "Constraints" -> 
   {v["EX_f6p_c"] -> {-Infinity, Infinity}, v["EX_g6p_c"] -> 
     {-0.21, Infinity}, v["EX_gap_c"] -> {0, Infinity}, 
    v["EX_h2o_c"] -> {-Infinity, Infinity}, v["EX_h_c"] -> {0, Infinity}, 
    v["EX_r5p_c"] -> {0.01, 0.01}}, "InitialConditions" -> 
   {metabolite["g6p", "c"] -> (0.000048599999999999995*Mole)/Liter, 
    metabolite["f6p", "c"] -> (0.000019800000000000004*Mole)/Liter, 
    metabolite["gap", "c"] -> (7.28*^-6*Mole)/Liter, 
    metabolite["gl6p", "c"] -> (1.754242723*^-6*Mole)/Liter, 
    metabolite["go6p", "c"] -> (0.000037475257999999995*Mole)/Liter, 
    metabolite["ru5p", "c"] -> (4.9367903*^-6*Mole)/Liter, 
    metabolite["x5p", "c"] -> (0.000014784196*Mole)/Liter, 
    metabolite["r5p", "c"] -> (4.94*^-6*Mole)/Liter, 
    metabolite["s7p", "c"] -> (0.000023987984*Mole)/Liter, 
    metabolite["e4p", "c"] -> (5.0750696*^-6*Mole)/Liter, 
    metabolite["nadp", "c"] -> (2.0000000000000002*^-7*Mole)/Liter, 
    metabolite["nadph", "c"] -> (0.0000658*Mole)/Liter, 
    metabolite["gsh", "c"] -> (0.0032*Mole)/Liter, 
    metabolite["gssg", "c"] -> (0.00011999999999999966*Mole)/Liter, 
    metabolite["h", "c"] -> (9.929240111468597*^-8*Mole)/Liter, 
    metabolite["h2o", "c"] -> (0.00099999683*Mole)/Liter, 
    metabolite["co2", "c"] -> (0.0010000020999999999*Mole)/Liter, 
    v["vg6pdh"] -> (0.00021*Mole)/(Hour*Liter), 
    v["vpglase"] -> (0.00021*Mole)/(Hour*Liter), 
    v["vgl6pdh"] -> (0.00021*Mole)/(Hour*Liter), 
    v["vr5pe"] -> (0.0001333333333333333*Mole)/(Hour*Liter), 
    v["vr5pi"] -> (0.00007666666666666664*Mole)/(Hour*Liter), 
    v["vtki"] -> (0.00006666666666666666*Mole)/(Hour*Liter), 
    v["vtkii"] -> (0.00006666666666666666*Mole)/(Hour*Liter), 
    v["vtala"] -> (0.00006666666666666666*Mole)/(Hour*Liter), 
    v["vgssgr"] -> (0.00042*Mole)/(Hour*Liter), 
    v["vgshr"] -> (0.00042*Mole)/(Hour*Liter), 
    v["vco2"] -> (0.00021*Mole)/(Hour*Liter), v["EX_g6p_c"] -> 
     (-0.00021*Mole)/(Hour*Liter), v["EX_f6p_c"] -> 
     (0.0001333333333333333*Mole)/(Hour*Liter), 
    v["EX_r5p_c"] -> (0.00001*Mole)/(Hour*Liter), 
    v["EX_h_c"] -> (0.00084*Mole)/(Hour*Liter), 
    v["EX_h2o_c"] -> (-0.00021*Mole)/(Hour*Liter), 
    v["EX_gap_c"] -> (0.00006666666666666666*Mole)/(Hour*Liter)}, 
  "Notes" -> "Model constructed on Tue 28 Aug 2012 12:34:03 by niko on \
staphylococcus.ucsd.edu using Mathematica 8.0 for Mac OS X x86 (64-bit) \
(November 6, 2010) at the following geodetic location: latitude 32.88; \
longitude -117.24\nModel constructed on Tue 28 Aug 2012 12:34:03 by niko on \
staphylococcus.ucsd.edu using Mathematica 8.0 for Mac OS X x86 (64-bit) \
(November 6, 2010) at the following geodetic location: latitude 32.88; \
longitude -117.24", "Parameters" -> {parameter["Volume", "c"] -> Liter, 
    Keq["EX_r5p_c"] -> Infinity, Keq["EX_h_c"] -> 1/1000000, 
    Keq["EX_h2o_c"] -> 1, Keq["EX_g6p_c"] -> 1, Keq["EX_gap_c"] -> Infinity, 
    Keq["EX_f6p_c"] -> Infinity, Keq["vg6pdh"] -> 1000, 
    Keq["vpglase"] -> 1000, Keq["vgl6pdh"] -> Mole/Liter, Keq["vr5pe"] -> 3, 
    Keq["vr5pi"] -> 2.57, Keq["vtki"] -> 3, Keq["vtkii"] -> 10.3, 
    Keq["vtala"] -> 1.05, Keq["vgssgr"] -> Mole/(10*Liter), 
    Keq["vgshr"] -> (2000*Liter)/Mole, Keq["vco2"] -> 1, 
    metabolite["h", "Xt"] -> (6.30957344480193*^-8*Mole)/Liter, 
    metabolite[_, "Xt"] -> Mole/(1000*Liter), rateconst["vg6pdh", True] -> 
     (2.1864589656595405*^7*Liter)/(Hour*Mole), rateconst["vpglase", True] -> 
     122.32291459460994/Hour, rateconst["vgl6pdh", True] -> 
     (2.9287844651669573*^7*Liter)/(Hour*Mole), rateconst["vr5pe", True] -> 
     15281.815785352192/Hour, rateconst["vr5pi", True] -> 
     25.431692095693613/Hour, rateconst["vtki", True] -> 
     (4.497488705748948*^6*Liter)/(Hour*Mole), rateconst["vtkii", True] -> 
     (1.092246904389965*^6*Liter)/(Hour*Mole), rateconst["vtala", True] -> 
     (844617.3037124242*Liter)/(Hour*Mole), rateconst["vgssgr", True] -> 
     (53329.81187273998*Liter)/(Hour*Mole), rateconst["vgshr", True] -> 
     (41.50197628458498*Liter)/(Hour*Mole), rateconst["vco2", True] -> 
     100000.00000720235/Hour, rateconst["EX_g6p_c", True] -> 
     0.22072734916964473/Hour, rateconst["EX_f6p_c", True] -> 
     6.734006734006732/Hour, rateconst["EX_r5p_c", True] -> 
     2.0242914979757085/Hour, rateconst["EX_h_c", True] -> 
     -0.01331310281667336/Hour, rateconst["EX_h2o_c", True] -> 
     0.21000000000000002/Hour, rateconst["EX_gap_c", True] -> 
     9.157509157509155/Hour}}]
