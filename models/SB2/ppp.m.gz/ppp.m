(* Created by Wolfram Mathematica 8.0 : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$91", "Parameters" -> 
   {parameter["Volume", "c"] -> 1, Keq["EX_h_c"] -> 1.*^-6, 
    Keq["EX_h2o_c"] -> 1, Keq["EX_g6p_c"] -> 1, Keq["EX_gap_c"] -> 1, 
    Keq["EX_f6p_c"] -> 1, Keq["vg6pdh"] -> 1000, Keq["vpglase"] -> 1000, 
    Keq["vgl6pdh"] -> 1000, Keq["vr5pe"] -> 3, Keq["vr5pi"] -> 2.57, 
    Keq["vtki"] -> 3, Keq["vtkii"] -> 10.3, Keq["vtala"] -> 1.05, 
    Keq["vgssgr"] -> 100, Keq["vgshr"] -> 2, Keq["vco2"] -> 1, 
    metabolite["amp", "Xt"] -> 0.0001, metabolite[_, "Xt"] -> 1}, 
  "GPR" -> {}, "BoundaryConditions" -> {}, "Constant" -> {}, 
  "CustomRateLaws" -> {}, "CustomODE" -> {}, "Name" -> "MASSmodel$91", 
  "ElementalComposition" -> {metabolite["co2", "c"] -> "C" + 2*"O", 
    metabolite["e4p", "c"] -> 4*"C" + 7*"H" + 7*"O" + "P", 
    metabolite["f6p", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P", 
    metabolite["g6p", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P", 
    metabolite["gap", "c"] -> 3*"C" + 5*"H" + 6*"O" + "P", 
    metabolite["gl6p", "c"] -> 6*"C" + 9*"H" + 9*"O" + "P", 
    metabolite["go6p", "c"] -> 6*"C" + 10*"H" + 10*"O" + "P", 
    metabolite["gsh", "c"] -> 10*"C" + 17*"H" + 3*"N" + 6*"O" + "S", 
    metabolite["gssg", "c"] -> 20*"C" + 32*"H" + 6*"N" + 12*"O" + 2*"S", 
    metabolite["h", "c"] -> "H", metabolite["h2o", "c"] -> 2*"H" + "O", 
    metabolite["nadp", "c"] -> "NADP", metabolite["nadph", "c"] -> 
     "H" + "NADP", metabolite["r5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["ru5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["s7p", "c"] -> 7*"C" + 13*"H" + 10*"O" + "P", 
    metabolite["x5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P"}, 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "Stoichiometry" -> SparseArray[Automatic, {17, 16}, 0, 
    {1, {{0, 2, 4, 7, 9, 13, 15, 17, 19, 24, 27, 30, 32, 35, 37, 40, 42, 44}, 
      {{3}, {11}, {7}, {8}, {7}, {8}, {13}, {1}, {12}, {6}, {7}, {8}, {16}, 
      {1}, {2}, {2}, {3}, {9}, {10}, {1}, {2}, {9}, {10}, {14}, {1}, {3}, 
      {9}, {1}, {3}, {9}, {5}, {6}, {3}, {4}, {5}, {6}, {8}, {4}, {6}, {7}, 
      {9}, {10}, {2}, {15}}}, {1, -1, -1, 1, 1, 1, -1, -1, -1, 1, 1, -1, -1, 
     1, -1, 1, -1, 2, -2, 1, 1, -1, 2, -1, -1, -1, 1, 1, 1, -1, 1, -1, 1, -1, 
     -1, 1, -1, 1, -1, -1, -1, 1, -1, -1}}], 
  "Species" -> {metabolite["co2", "c"], metabolite["e4p", "c"], 
    metabolite["f6p", "c"], metabolite["g6p", "c"], metabolite["gap", "c"], 
    metabolite["gl6p", "c"], metabolite["go6p", "c"], metabolite["gsh", "c"], 
    metabolite["h", "c"], metabolite["nadp", "c"], metabolite["nadph", "c"], 
    metabolite["r5p", "c"], metabolite["ru5p", "c"], metabolite["s7p", "c"], 
    metabolite["x5p", "c"], metabolite["gssg", "c"], metabolite["h2o", "c"]}, 
  "Fluxes" -> {"vg6pdh", "vpglase", "vgl6pdh", "vr5pe", "vr5pi", "vtki", 
    "vtkii", "vtala", "vgssgr", "vgshr", "vco2", "EX_g6p_c", "EX_f6p_c", 
    "EX_h_c", "EX_h2o_c", "EX_gap_c"}, "ReversibleColumnIndices" -> 
   {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16}, 
  "Constraints" -> {"EX_g6p_c" -> {0, Infinity}, "EX_f6p_c" -> {0, Infinity}, 
    "EX_h_c" -> {0, Infinity}, "EX_h2o_c" -> {0, Infinity}, 
    "EX_gap_c" -> {0, Infinity}}, "InitialConditions" -> 
   {metabolite["g6p", "c"] -> 0.0486, metabolite["f6p", "c"] -> 0.0198, 
    metabolite["gap", "c"] -> 0.00728, metabolite["gl6p", "c"] -> 
     0.001754242723, metabolite["go6p", "c"] -> 0.037475258, 
    metabolite["ru5p", "c"] -> 0.0049367903, metabolite["x5p", "c"] -> 
     0.014784196, metabolite["r5p", "c"] -> 0.00494, 
    metabolite["s7p", "c"] -> 0.023987984, metabolite["e4p", "c"] -> 
     0.0050750696, metabolite["nadp", "c"] -> 0.0002, 
    metabolite["nadph", "c"] -> 0.0658, metabolite["gsh", "c"] -> 3.2, 
    metabolite["gssg", "c"] -> 0.11999999999999966, 
    metabolite["h", "c"] -> 0.00009929240111468596, 
    metabolite["h2o", "c"] -> 0.99999683, metabolite["co2", "c"] -> 
     1.0000021, "vg6pdh" -> 0.21, "vpglase" -> 0.21, "vgl6pdh" -> 0.21, 
    "vr5pe" -> 0.14, "vr5pi" -> 0.06999999999999999, 
    "vtki" -> 0.06999999999999999, "vtkii" -> 0.07, 
    "vtala" -> 0.06999999999999999, "vgssgr" -> 0.42, "vgshr" -> 0.42, 
    "vco2" -> 0.21, "EX_g6p_c" -> -0.21, "EX_f6p_c" -> 0.14, 
    "EX_h_c" -> 0.84, "EX_h2o_c" -> -0.21, "EX_gap_c" -> 0.07}, 
  "Notes" -> "Model constructed on Thu 9 Aug 2012 14:08:38 by niko on \
staphylococcus.ucsd.edu using Mathematica 8.0 for Mac OS X x86 (64-bit) \
(November 6, 2010) at the following geodetic location: latitude 32.88; \
longitude -117.24\nModel constructed on Thu 9 Aug 2012 14:08:38 by niko on \
staphylococcus.ucsd.edu using Mathematica 8.0 for Mac OS X x86 (64-bit) \
(November 6, 2010) at the following geodetic location: latitude 32.88; \
longitude -117.24"}]
