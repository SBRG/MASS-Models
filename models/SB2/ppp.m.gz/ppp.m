(* Created by Wolfram Mathematica 8.0 : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$11", "Stoichiometry" -> 
   SparseArray[Automatic, {17, 17}, 0, {1, {{0, 2, 4, 7, 9, 13, 15, 17, 19, 
      24, 26, 29, 32, 35, 37, 40, 42, 45}, {{3}, {11}, {7}, {8}, {7}, {8}, 
      {13}, {1}, {12}, {6}, {7}, {8}, {17}, {1}, {2}, {2}, {3}, {9}, {10}, 
      {1}, {2}, {9}, {10}, {15}, {2}, {16}, {1}, {3}, {9}, {5}, {6}, {14}, 
      {3}, {4}, {5}, {6}, {8}, {4}, {6}, {7}, {9}, {10}, {1}, {3}, {9}}}, {1, 
     -1, -1, 1, 1, 1, -1, -1, -1, 1, 1, -1, -1, 1, -1, 1, -1, 2, -2, 1, 1, 
     -1, 2, -1, -1, -1, -1, -1, 1, 1, -1, -1, 1, -1, -1, 1, -1, 1, -1, -1, 
     -1, 1, 1, 1, -1}}], "Species" -> {metabolite["co2", "c"], 
    metabolite["e4p", "c"], metabolite["f6p", "c"], metabolite["g6p", "c"], 
    metabolite["gap", "c"], metabolite["gl6p", "c"], metabolite["go6p", "c"], 
    metabolite["gsh", "c"], metabolite["h", "c"], metabolite["h2o", "c"], 
    metabolite["nadp", "c"], metabolite["r5p", "c"], metabolite["ru5p", "c"], 
    metabolite["s7p", "c"], metabolite["x5p", "c"], metabolite["gssg", "c"], 
    metabolite["nadph", "c"]}, "Fluxes" -> {v["vg6pdh"], v["vpglase"], 
    v["vgl6pdh"], v["vr5pe"], v["vr5pi"], v["vtki"], v["vtkii"], v["vtala"], 
    v["vgssgr"], v["vgshr"], v["vco2"], v["EX_g6p_c"], v["EX_f6p_c"], 
    v["EX_r5p_c"], v["EX_h_c"], v["EX_h2o_c"], v["EX_gap_c"]}, "GPR" -> {}, 
  "BoundaryConditions" -> {}, "Constant" -> {}, 
  "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 
    14, 15, 16, 17}, "CustomRateLaws" -> {}, "CustomODE" -> {}, 
  "Name" -> "MASSmodel$11", "ElementalComposition" -> 
   {metabolite["co2", "c"] -> "C" + 2*"O", metabolite["e4p", "c"] -> 
     4*"C" + 7*"H" + 7*"O" + "P", metabolite["f6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P", metabolite["g6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P", metabolite["gap", "c"] -> 
     3*"C" + 5*"H" + 6*"O" + "P", metabolite["gl6p", "c"] -> 
     6*"C" + 9*"H" + 9*"O" + "P", metabolite["go6p", "c"] -> 
     6*"C" + 10*"H" + 10*"O" + "P", metabolite["gsh", "c"] -> 
     10*"C" + 17*"H" + 3*"N" + 6*"O" + "S", metabolite["gssg", "c"] -> 
     20*"C" + 32*"H" + 6*"N" + 12*"O" + 2*"S", metabolite["h", "c"] -> "H", 
    metabolite["h2o", "c"] -> 2*"H" + "O", metabolite["nadp", "c"] -> 
     "&NADP&", metabolite["nadph", "c"] -> "H" + "&NADP&", 
    metabolite["r5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["ru5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["s7p", "c"] -> 7*"C" + 13*"H" + 10*"O" + "P", 
    metabolite["x5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P"}, 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "UnitChecking" -> True, "Constraints" -> 
   {v["EX_f6p_c"] -> {-Infinity, Infinity}, v["EX_g6p_c"] -> 
     {-0.21, Infinity}, v["EX_gap_c"] -> {0, Infinity}, 
    v["EX_h2o_c"] -> {-Infinity, Infinity}, v["EX_h_c"] -> {0, Infinity}, 
    v["EX_r5p_c"] -> {0.01, 0.01}}, "InitialConditions" -> 
   {metabolite["g6p", "c"] -> Unit[0.0486, "Millimole"/"Liter"], 
    metabolite["f6p", "c"] -> Unit[0.0198, "Millimole"/"Liter"], 
    metabolite["gap", "c"] -> Unit[0.00728, "Millimole"/"Liter"], 
    metabolite["gl6p", "c"] -> Unit[0.001754242723, "Millimole"/"Liter"], 
    metabolite["go6p", "c"] -> Unit[0.037475258, "Millimole"/"Liter"], 
    metabolite["ru5p", "c"] -> Unit[0.0049367903, "Millimole"/"Liter"], 
    metabolite["x5p", "c"] -> Unit[0.014784196, "Millimole"/"Liter"], 
    metabolite["r5p", "c"] -> Unit[0.012668936, "Millimole"/"Liter"], 
    metabolite["s7p", "c"] -> Unit[0.023987984, "Millimole"/"Liter"], 
    metabolite["e4p", "c"] -> Unit[0.0050750696, "Millimole"/"Liter"], 
    metabolite["nadp", "c"] -> Unit[0.0002, "Millimole"/"Liter"], 
    metabolite["nadph", "c"] -> Unit[0.0658, "Millimole"/"Liter"], 
    metabolite["gsh", "c"] -> Unit[3.2, "Millimole"/"Liter"], 
    metabolite["gssg", "c"] -> Unit[0.11999999999999966, 
      "Millimole"/"Liter"], metabolite["co2", "c"] -> 
     Unit[1.0000021, "Millimole"/"Liter"], metabolite["h", "c"] -> 
     Unit[0.0000714957344480193, "Millimole"/"Liter"], 
    metabolite["h2o", "c"] -> Unit[0.9999979, "Millimole"/"Liter"], 
    v["vg6pdh"] -> Unit[0.21, "Millimole"/("Hour"*"Liter")], 
    v["vpglase"] -> Unit[0.21, "Millimole"/("Hour"*"Liter")], 
    v["vgl6pdh"] -> Unit[0.21, "Millimole"/("Hour"*"Liter")], 
    v["vr5pe"] -> Unit[0.1333333333333333, "Millimole"/("Hour"*"Liter")], 
    v["vr5pi"] -> Unit[0.07666666666666665, "Millimole"/("Hour"*"Liter")], 
    v["vtki"] -> Unit[0.06666666666666665, "Millimole"/("Hour"*"Liter")], 
    v["vtkii"] -> Unit[0.06666666666666665, "Millimole"/("Hour"*"Liter")], 
    v["vtala"] -> Unit[0.06666666666666665, "Millimole"/("Hour"*"Liter")], 
    v["vgssgr"] -> Unit[0.42, "Millimole"/("Hour"*"Liter")], 
    v["vgshr"] -> Unit[0.42, "Millimole"/("Hour"*"Liter")], 
    v["vco2"] -> Unit[0.21, "Millimole"/("Hour"*"Liter")], 
    v["EX_g6p_c"] -> Unit[-0.21, "Millimole"/("Hour"*"Liter")], 
    v["EX_f6p_c"] -> Unit[0.1333333333333333, "Millimole"/("Hour"*"Liter")], 
    v["EX_r5p_c"] -> Unit[0.01, "Millimole"/("Hour"*"Liter")], 
    v["EX_h_c"] -> Unit[0.84, "Millimole"/("Hour"*"Liter")], 
    v["EX_h2o_c"] -> Unit[-0.21, "Millimole"/("Hour"*"Liter")], 
    v["EX_gap_c"] -> Unit[0.06666666666666665, 
      "Millimole"/("Hour"*"Liter")]}, "Notes" -> "Model constructed on Tue 4 \
Dec 2012 09:19:41 by niko on staphylococcus.ucsd.edu using Mathematica 8.0 \
for Mac OS X x86 (64-bit) (October 5, 2011) at the following geodetic \
location: latitude 32.88; longitude -117.24\nModel constructed on Tue 4 Dec \
2012 09:19:44 by niko on staphylococcus.ucsd.edu using Mathematica 8.0 for \
Mac OS X x86 (64-bit) (October 5, 2011) at the following geodetic location: \
latitude 32.88; longitude -117.24", "Parameters" -> 
   {parameter["Volume", "c"] -> Unit[1, "Liter"], 
    Keq["EX_r5p_c"] -> Infinity, Keq["EX_h_c"] -> 1, Keq["EX_h2o_c"] -> 1, 
    Keq["EX_g6p_c"] -> 1, Keq["EX_gap_c"] -> Infinity, 
    Keq["EX_f6p_c"] -> Infinity, Keq["vg6pdh"] -> 1000, 
    Keq["vpglase"] -> 1000, Keq["vgl6pdh"] -> 
     Unit[1000, "Millimole"/"Liter"], Keq["vr5pe"] -> 3, 
    Keq["vr5pi"] -> 2.57, Keq["vtki"] -> 1.2, Keq["vtkii"] -> 10.3, 
    Keq["vtala"] -> 1.05, Keq["vgssgr"] -> Unit[100, "Millimole"/"Liter"], 
    Keq["vgshr"] -> Unit[2, "Liter"/"Millimole"], Keq["vco2"] -> 1, 
    metabolite["h", "Xt"] -> Unit[0.00006309573444801929, 
      "Millimole"/"Liter"], rateconst["vg6pdh", True] -> 
     Unit[21864.5896565954, "Liter"/("Hour"*"Millimole")], 
    rateconst["vpglase", True] -> Unit[122.32291459460994, "Hour"^(-1)], 
    rateconst["vgl6pdh", True] -> Unit[29287.844651669573, 
      "Liter"/("Hour"*"Millimole")], rateconst["vr5pe", True] -> 
     Unit[15281.81578535149, "Hour"^(-1)], rateconst["vr5pi", True] -> 
     Unit[10584.613581831474, "Hour"^(-1)], rateconst["vtki", True] -> 
     Unit[1595.9298680575926, "Liter"/("Hour"*"Millimole")], 
    rateconst["vtkii", True] -> Unit[1092.246904389965, 
      "Liter"/("Hour"*"Millimole")], rateconst["vtala", True] -> 
     Unit[844.6173037124239, "Liter"/("Hour"*"Millimole")], 
    rateconst["vgssgr", True] -> Unit[53.32981187273998, 
      "Liter"/("Hour"*"Millimole")], rateconst["vgshr", True] -> 
     Unit[0.04125736738703339, "Liter"/("Hour"*"Millimole")], 
    rateconst["vco2", True] -> Unit[100000.0000050546, "Hour"^(-1)], 
    rateconst["EX_g6p_c", True] -> Unit[0.22072734916964473, "Hour"^(-1)], 
    rateconst["EX_f6p_c", True] -> Unit[6.734006734006732, "Hour"^(-1)], 
    rateconst["EX_r5p_c", True] -> Unit[0.789332269102946, "Hour"^(-1)], 
    rateconst["EX_h_c", True] -> Unit[99999.99999999999, "Hour"^(-1)], 
    rateconst["EX_h2o_c", True] -> Unit[99999.99999976781, "Hour"^(-1)], 
    rateconst["EX_gap_c", True] -> Unit[9.157509157509157, "Hour"^(-1)], 
    metabolite[_, "Xt"] -> Unit[1, "Millimole"/"Liter"]}}]
