(* Created by Wolfram Mathematica 9.0 : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$1529", "Stoichiometry" -> 
   SparseArray[Automatic, {13, 8}, 0, {1, {{0, 2, 4, 6, 7, 10, 11, 12, 17, 
      18, 19, 20, 21, 23}, {{4}, {5}, {5}, {6}, {6}, {7}, {7}, {1}, {2}, {3}, 
      {2}, {1}, {4}, {5}, {6}, {7}, {8}, {2}, {1}, {1}, {3}, {3}, {4}}}, {1, 
     -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 
     -1, -1}}], "Species" -> {complex[species["Hb", "c"], 
     metabolite["o2", "c"]], complex[species["Hb", "c"], 
     metabolite["o2", "c"], metabolite["o2", "c"]], 
    complex[species["Hb", "c"], metabolite["o2", "c"], metabolite["o2", "c"], 
     metabolite["o2", "c"]], complex[species["Hb", "c"], 
     metabolite["o2", "c"], metabolite["o2", "c"], metabolite["o2", "c"], 
     metabolite["o2", "c"]], metabolite["dpg23", "c"], metabolite["h", "c"], 
    metabolite["h2o", "c"], metabolite["o2", "c"], metabolite["pg13", "c"], 
    metabolite["pg3", "c"], metabolite["phos", "c"], species["deoxyHb", "c"], 
    species["Hb", "c"]}, "Fluxes" -> {v["vdpgase"], v["vdpgm"], v["vhbdpg"], 
    v["vhbo1"], v["vhbo2"], v["vhbo3"], v["vhbo4"], v["vo2"]}, 
  "Constraints" -> {}, "InitialConditions" -> 
   {species["deoxyHb", "c"] -> Unit[0.04620957029335471, 
      "Millimole"/"Liter"], species["Hb", "c"] -> Unit[0.059625251991425425, 
      "Millimole"/"Liter"], complex[species["Hb", "c"], 
      metabolite["o2", "c"]] -> Unit[0.05008521167279736, 
      "Millimole"/"Liter"], complex[species["Hb", "c"], 
      metabolite["o2", "c"], metabolite["o2", "c"]] -> 
     Unit[0.07362526115901212, "Millimole"/"Liter"], 
    complex[species["Hb", "c"], metabolite["o2", "c"], metabolite["o2", "c"], 
      metabolite["o2", "c"]] -> Unit[0.26284218233767326, 
      "Millimole"/"Liter"], complex[species["Hb", "c"], 
      metabolite["o2", "c"], metabolite["o2", "c"], metabolite["o2", "c"], 
      metabolite["o2", "c"]] -> Unit[6.807612522545737, "Millimole"/"Liter"], 
    metabolite["o2", "c"] -> Unit[0.0200788, "Millimole"/"Liter"], 
    metabolite["dpg23", "c"] -> Unit[3.1, "Millimole"/"Liter"], 
    metabolite["pg13", "c"] -> Unit[0.000243, "Millimole"/"Liter"], 
    metabolite["pg3", "c"] -> Unit[0.0773, "Millimole"/"Liter"], 
    metabolite["phos", "c"] -> Unit[2.5, "Millimole"/"Liter"], 
    metabolite["h", "c"] -> Unit[0.00008997573444801929, 
      "Millimole"/"Liter"], metabolite["h2o", "c"] -> 
     Unit[1., "Millimole"/"Liter"]}, "Parameters" -> 
   {parameter["Volume", "c"] -> Unit[1, "Liter"], 
    Keq["vdpgase"] -> Unit[Infinity, "Millimole"/"Liter"], 
    Keq["vdpgm"] -> Infinity, Keq["vhbdpg"] -> 
     Unit[1/4, "Liter"/"Millimole"], Keq["vhbo1"] -> 
     Unit[41.835169432436196, "Liter"/"Millimole"], 
    Keq["vhbo2"] -> Unit[73.21154650676336, "Liter"/"Millimole"], 
    Keq["vhbo3"] -> Unit[177.79947008785382, "Liter"/"Millimole"], 
    Keq["vhbo4"] -> Unit[1289.9177241667828, "Liter"/"Millimole"], 
    Keq["vo2"] -> 1, rateconst["vdpgase", True] -> Unit[0.14225806451612902, 
      "Hour"^(-1)], rateconst["vdpgm", True] -> Unit[1814.8148148148148, 
      "Hour"^(-1)], rateconst["vhbo1", True] -> Unit[506935.270702259, 
      "Liter"/("Hour"*"Millimole")], rateconst["vhbo2", True] -> 
     Unit[511077.050923776, "Liter"/("Hour"*"Millimole")], 
    rateconst["vhbo3", True] -> Unit[509243.459567699, 
      "Liter"/("Hour"*"Millimole")], rateconst["vhbo4", True] -> 
     Unit[501595.340624411, "Liter"/("Hour"*"Millimole")], 
    rateconst["vhbdpg", True] -> Unit[519612.560391792, 
      "Liter"/("Hour"*"Millimole")], rateconst["vo2", True] -> 
     Unit[509725.707725914, "Hour"^(-1)], metabolite["o2", "Xt"] -> 
     Unit[0.0200788, "Millimole"/"Liter"]}, "GPR" -> {}, 
  "BoundaryConditions" -> {}, "Constant" -> {}, 
  "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8}, 
  "CustomRateLaws" -> {}, "CustomODE" -> {}, "Name" -> "MASSmodel$1529", 
  "ElementalComposition" -> 
   {complex[species["Hb", "c"], metabolite["o2", "c"]] -> 
     "&" + "[" + "]" + " " + "c" + "&Hb[c] &" + 2*"o", 
    complex[species["Hb", "c"], metabolite["o2", "c"], 
      metabolite["o2", "c"]] -> "&" + "[" + "]" + 3*" " + "c" + "&Hb[c] &" + 
      2*"o", complex[species["Hb", "c"], metabolite["o2", "c"], 
      metabolite["o2", "c"], metabolite["o2", "c"]] -> 
     "&" + "[" + "]" + 4*" " + "c" + "&Hb[c] &" + 2*"o", 
    complex[species["Hb", "c"], metabolite["o2", "c"], metabolite["o2", "c"], 
      metabolite["o2", "c"], metabolite["o2", "c"]] -> 
     "&" + "[" + "]" + 5*" " + "c" + "&Hb[c] &" + 2*"o", 
    metabolite["dpg23", "c"] -> "&dpg23&", metabolite["h", "c"] -> "&h&", 
    metabolite["h2o", "c"] -> "&h2o&", metabolite["o2", "c"] -> "&o2&", 
    metabolite["pg13", "c"] -> "&pg13&", metabolite["pg3", "c"] -> "&pg3&", 
    metabolite["phos", "c"] -> "&phos&", species["deoxyHb", "c"] -> 
     "&deoxyHb&", species["Hb", "c"] -> "&Hb&"}, "Notes" -> "", 
  "Ignore" -> {metabolite["h2o", "c"], metabolite["h", "c"]}, 
  "UnitChecking" -> True, "Synonyms" -> {}, "Events" -> {}}]
