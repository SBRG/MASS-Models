(* Created by Wolfram Mathematica 8.0 : www.wolfram.com *)
MASSmodel[{"ID" -> "ID", "Stoichiometry" -> SparseArray[Automatic, {20, 21}, 
    0, {1, {{0, 6, 9, 15, 17, 19, 21, 23, 26, 28, 36, 39, 41, 44, 46, 48, 50, 
      52, 55, 58, 60}, {{1}, {3}, {7}, {10}, {13}, {16}, {12}, {13}, {19}, 
      {1}, {3}, {7}, {10}, {13}, {16}, {4}, {5}, {2}, {3}, {3}, {5}, {1}, 
      {2}, {4}, {5}, {6}, {1}, {18}, {1}, {3}, {6}, {10}, {11}, {16}, {17}, 
      {20}, {9}, {16}, {21}, {11}, {15}, {6}, {11}, {17}, {9}, {10}, {6}, 
      {7}, {8}, {9}, {7}, {8}, {10}, {11}, {14}, {6}, {11}, {17}, {6}, 
      {16}}}, {1, 1, -1, -1, -2, 1, -1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 
     -1, 1, -1, 1, -1, 1, 1, -1, -1, 1, 1, 1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 
     1, -1, -1, 1, 1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, -1, 1, -1, -1, -1, 
     1}}], "Compounds" -> {metabolite["adp", "c"], metabolite["amp", "c"], 
    metabolite["atp", "c"], metabolite["dhap", "c"], metabolite["f6p", "c"], 
    metabolite["fdp", "c"], metabolite["g6p", "c"], metabolite["gap", "c"], 
    metabolite["glu", "c"], metabolite["h", "c"], metabolite["h2o", "c"], 
    metabolite["lac", "c"], metabolite["nad", "c"], metabolite["pep", "c"], 
    metabolite["pg13", "c"], metabolite["pg2", "c"], metabolite["pg3", "c"], 
    metabolite["pyr", "c"], metabolite["nadh", "c"], 
    metabolite["phos", "c"]}, "Fluxes" -> {"vhk", "vpgi", "vpfk", "vtpi", 
    "vald", "vgapdh", "vpgk", "vpglm", "veno", "vpk", "vldh", "vamp", "vapk", 
    "vpyr", "vlac", "vatp", "vnadh", "vgluin", "vampin", "vh", "vh2o"}, 
  "Constraints" -> {"vgluin" -> {-Infinity, 0}, "vampin" -> {-Infinity, 0}}, 
  "GPR" -> {}, "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 
    11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21}, 
  "CustomRateLaws" -> 
   {"vh" -> (metabolite["h", "c"] - metabolite["h", "Xt"]/Keq["vh"])*
      rateconst["vh", True], "vh2o" -> (metabolite["h2o", "c"] - 
       metabolite["h2o", "Xt"]/Keq["vh2o"])*rateconst["vh2o", True]}, 
  "Name" -> "ID", "ElementalComposition" -> 
   {metabolite["adp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 10*"O" + 2*"P", 
    metabolite["amp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 7*"O" + "P", 
    metabolite["atp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 13*"O" + 3*"P", 
    metabolite["dhap", "c"] -> 3*"C" + 5*"H" + 6*"O" + "P", 
    metabolite["f6p", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P", 
    metabolite["fdp", "c"] -> 6*"C" + 10*"H" + 12*"O" + 2*"P", 
    metabolite["g6p", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P", 
    metabolite["gap", "c"] -> 3*"C" + 5*"H" + 6*"O" + "P", 
    metabolite["glu", "c"] -> 6*"C" + 12*"H" + 6*"O", 
    metabolite["h", "c"] -> "H", metabolite["h2o", "c"] -> 2*"H" + "O", 
    metabolite["lac", "c"] -> 3*"C" + 5*"H" + 3*"O", 
    metabolite["nad", "c"] -> "NAD", metabolite["nadh", "c"] -> "H" + "NAD", 
    metabolite["pep", "c"] -> 3*"C" + 2*"H" + 6*"O" + "P", 
    metabolite["pg13", "c"] -> 3*"C" + 4*"H" + 10*"O" + 2*"P", 
    metabolite["pg2", "c"] -> 3*"C" + 4*"H" + 7*"O" + "P", 
    metabolite["pg3", "c"] -> 3*"C" + 4*"H" + 7*"O" + "P", 
    metabolite["phos", "c"] -> "H" + 4*"O" + "P", metabolite["pyr", "c"] -> 
     3*"C" + 3*"H" + 3*"O"}, "Notes" -> "Model constructed on Tue 10 Apr 2012 \
11:31:38 by niko on staphylococcus.ucsd.edu using 8.0 for Mac OS X x86 \
(64-bit) (November 6, 2010) at the following geodetic location: latitude \
32.88; longitude -117.24", "Ignore" -> {metabolite["h", "c"], 
    metabolite["h2o", "c"]}, "InitialConditions" -> 
   {metabolite["glu", "c"] -> 1., metabolite["g6p", "c"] -> 0.0486, 
    metabolite["f6p", "c"] -> 0.0198, metabolite["fdp", "c"] -> 0.0146, 
    metabolite["dhap", "c"] -> 0.16, metabolite["gap", "c"] -> 0.00728, 
    metabolite["pg13", "c"] -> 0.000243, metabolite["pg3", "c"] -> 0.0773, 
    metabolite["pg2", "c"] -> 0.0113, metabolite["pep", "c"] -> 0.017, 
    metabolite["pyr", "c"] -> 0.060301, metabolite["lac", "c"] -> 1.36, 
    metabolite["nad", "c"] -> 0.0589, metabolite["nadh", "c"] -> 0.0301, 
    metabolite["amp", "c"] -> 0.08672812499999999, 
    metabolite["adp", "c"] -> 0.29, metabolite["atp", "c"] -> 1.6, 
    metabolite["phos", "c"] -> 2.5, metabolite["h", "c"] -> 
     0.00008997573444801929, metabolite["h2o", "c"] -> 1., "vhk" -> 1.12, 
    "vpgi" -> 1.12, "vpfk" -> 1.12, "vtpi" -> 1.12, "vald" -> 1.12, 
    "vgapdh" -> 2.24, "vpgk" -> 2.24, "vpglm" -> 2.24, "veno" -> 2.24, 
    "vpk" -> 2.24, "vldh" -> 2.016, "vamp" -> 0.014, "vapk" -> 0., 
    "vpyr" -> 0.22400000000000003, "vlac" -> 2.016, "vatp" -> 2.24, 
    "vnadh" -> 0.22400000000000003, "vgluin" -> 1.12, "vampin" -> 0.014, 
    "vh" -> 2.688, "vh2o" -> 0.}, "Parameters" -> 
   {Keq["vhk"] -> 850, Keq["vpgi"] -> 0.41, Keq["vpfk"] -> 310, 
    Keq["vtpi"] -> 0.05714285714285714, Keq["vald"] -> 0.082, 
    Keq["vgapdh"] -> 0.0179, Keq["vpgk"] -> 1800, 
    Keq["vpglm"] -> 0.14705882352941177, Keq["veno"] -> 1.6949152542372883, 
    Keq["vpk"] -> 363000, Keq["vldh"] -> 26300, Keq["vamp"] -> Infinity, 
    Keq["vapk"] -> 1.65, Keq["vpyr"] -> 1., Keq["vlac"] -> 1., 
    Keq["vatp"] -> Infinity, Keq["vnadh"] -> Infinity, 
    Keq["vgluin"] -> Infinity, Keq["vampin"] -> Infinity, Keq["vh"] -> 1., 
    Keq["vh2o"] -> 1., metabolite["pyr", "Xt"] -> 0.06, 
    metabolite["amp", "Xt"] -> 1, metabolite["h", "Xt"] -> 
     0.00006309573444801929, metabolite[_, "Xt"] -> 1, 
    rateconst["vhk", True] -> 0.7000072543398843, rateconst["vpgi", True] -> 
     3644.444444444491, rateconst["vpfk", True] -> 35.36878374779938, 
    rateconst["vtpi", True] -> 34.35582822085891, rateconst["vald", True] -> 
     2834.567901234576, rateconst["vgapdh", True] -> 3376.7492421768247, 
    rateconst["vpgk", True] -> 1.2735312697410057*^6, 
    rateconst["vpglm", True] -> 4869.565217391283, 
    rateconst["veno", True] -> 1763.7795275590574, 
    rateconst["vpk", True] -> 454.38555191136817, rateconst["vldh", True] -> 
     1112.573988602781, rateconst["vamp", True] -> 0.16142399019925777, 
    rateconst["vapk", True] -> 100000, rateconst["vpyr", True] -> 
     744.1860465116215, rateconst["vlac", True] -> 5.599999999999999, 
    rateconst["vatp", True] -> 1.4000000000000001, 
    rateconst["vnadh", True] -> 7.44186046511628, 
    rateconst["vgluin", True] -> 1.12, rateconst["vampin", True] -> 0.014, 
    rateconst["vh", True] -> 100000.00000000001, rateconst["vh2o", True] -> 
     100000}}]
