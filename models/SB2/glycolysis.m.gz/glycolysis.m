(* Created by Wolfram Mathematica 8.0 : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$3", "Stoichiometry" -> 
   SparseArray[Automatic, {20, 21}, 0, {1, {{0, 6, 9, 15, 17, 19, 21, 23, 26, 
      28, 36, 39, 41, 44, 46, 48, 50, 52, 55, 58, 60}, {{1}, {3}, {7}, {10}, 
      {13}, {16}, {12}, {13}, {19}, {1}, {3}, {7}, {10}, {13}, {16}, {4}, 
      {5}, {2}, {3}, {3}, {5}, {1}, {2}, {4}, {5}, {6}, {1}, {18}, {1}, {3}, 
      {6}, {10}, {11}, {16}, {17}, {20}, {9}, {16}, {21}, {11}, {15}, {6}, 
      {11}, {17}, {9}, {10}, {6}, {7}, {8}, {9}, {7}, {8}, {10}, {11}, {14}, 
      {6}, {11}, {17}, {6}, {16}}}, {1, 1, -1, -1, -2, 1, -1, 1, 1, -1, -1, 
     1, 1, 1, -1, -1, 1, 1, -1, 1, -1, 1, -1, 1, 1, -1, -1, 1, 1, 1, 1, -1, 
     -1, 1, 1, -1, 1, -1, -1, 1, -1, -1, 1, 1, 1, -1, 1, -1, 1, -1, 1, -1, 1, 
     -1, -1, 1, -1, -1, -1, 1}}], "Species" -> {metabolite["adp", "c"], 
    metabolite["amp", "c"], metabolite["atp", "c"], metabolite["dhap", "c"], 
    metabolite["f6p", "c"], metabolite["fdp", "c"], metabolite["g6p", "c"], 
    metabolite["gap", "c"], metabolite["glu", "c"], metabolite["h", "c"], 
    metabolite["h2o", "c"], metabolite["lac", "c"], metabolite["nad", "c"], 
    metabolite["pep", "c"], metabolite["pg13", "c"], metabolite["pg2", "c"], 
    metabolite["pg3", "c"], metabolite["pyr", "c"], metabolite["nadh", "c"], 
    metabolite["phos", "c"]}, "Fluxes" -> {v["vhk"], v["vpgi"], v["vpfk"], 
    v["vtpi"], v["vald"], v["vgapdh"], v["vpgk"], v["vpglm"], v["veno"], 
    v["vpk"], v["vldh"], v["vamp"], v["vapk"], v["vpyr"], v["vlac"], 
    v["vatp"], v["vnadh"], v["vgluin"], v["vampin"], v["vh"], v["vh2o"]}, 
  "Constraints" -> {"vgluin" -> {-Infinity, 0}, "vampin" -> {-Infinity, 0}}, 
  "GPR" -> {}, "BoundaryConditions" -> {}, "Constant" -> {}, 
  "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 
    14, 15, 16, 17, 18, 19, 20, 21}, "CustomRateLaws" -> 
   {v["vh"] -> rateconst["vh", True]*(-(metabolite["h", "Xt"]/Keq["vh"]) + 
       metabolite["h", "c"][t]), v["vh2o"] -> rateconst["vh2o", True]*
      (-(metabolite["h2o", "Xt"]/Keq["vh2o"]) + metabolite["h2o", "c"][t])}, 
  "CustomODE" -> {}, "Name" -> "MASSmodel$3", "ElementalComposition" -> 
   {metabolite["adp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 10*"O" + 2*"P", 
    metabolite["amp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 7*"O" + "P", 
    metabolite["atp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 13*"O" + 3*"P", 
    metabolite["dhap", "c"] -> 3*"C" + 5*"H" + 6*"O" + "P", 
    metabolite["f6p", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P", 
    metabolite["fdp", "c"] -> 6*"C" + 10*"H" + 12*"O" + 2*"P", 
    metabolite["g6p", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P", 
    metabolite["gap", "c"] -> 3*"C" + 5*"H" + 6*"O" + "P", 
    metabolite["glu", "c"] -> 6*"C" + 12*"H" + 6*"O", 
    metabolite["h", "c"] -> "H", metabolite["h2o", "c"] -> 2*"H" + "O", 
    metabolite["lac", "c"] -> 3*"C" + 5*"H" + 3*"O", 
    metabolite["nad", "c"] -> "NAD", metabolite["nadh", "c"] -> "H" + "NAD", 
    metabolite["pep", "c"] -> 3*"C" + 2*"H" + 6*"O" + "P", 
    metabolite["pg13", "c"] -> 3*"C" + 4*"H" + 10*"O" + 2*"P", 
    metabolite["pg2", "c"] -> 3*"C" + 4*"H" + 7*"O" + "P", 
    metabolite["pg3", "c"] -> 3*"C" + 4*"H" + 7*"O" + "P", 
    metabolite["phos", "c"] -> "H" + 4*"O" + "P", metabolite["pyr", "c"] -> 
     3*"C" + 3*"H" + 3*"O"}, "Notes" -> "Model constructed on Tue 28 Aug 2012 \
11:16:50 by niko on staphylococcus.ucsd.edu using Mathematica 8.0 for Mac OS \
X x86 (64-bit) (November 6, 2010) at the following geodetic location: \
latitude 32.88; longitude -117.24", 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "UnitChecking" -> True, "InitialConditions" -> 
   {metabolite["glu", "c"] -> (0.001*Mole)/Liter, metabolite["g6p", "c"] -> 
     (0.000048599999999999995*Mole)/Liter, metabolite["f6p", "c"] -> 
     (0.000019800000000000004*Mole)/Liter, metabolite["fdp", "c"] -> 
     (0.0000146*Mole)/Liter, metabolite["dhap", "c"] -> (0.00016*Mole)/Liter, 
    metabolite["gap", "c"] -> (7.28*^-6*Mole)/Liter, 
    metabolite["pg13", "c"] -> (2.43*^-7*Mole)/Liter, 
    metabolite["pg3", "c"] -> (0.0000773*Mole)/Liter, 
    metabolite["pg2", "c"] -> (0.0000113*Mole)/Liter, 
    metabolite["pep", "c"] -> (0.000017000000000000003*Mole)/Liter, 
    metabolite["pyr", "c"] -> (0.000060301000000000004*Mole)/Liter, 
    metabolite["lac", "c"] -> (0.00136*Mole)/Liter, 
    metabolite["nad", "c"] -> (0.0000589*Mole)/Liter, 
    metabolite["nadh", "c"] -> (0.0000301*Mole)/Liter, 
    metabolite["amp", "c"] -> (0.00008672812499999999*Mole)/Liter, 
    metabolite["adp", "c"] -> (0.00029*Mole)/Liter, 
    metabolite["atp", "c"] -> (0.0016*Mole)/Liter, 
    metabolite["phos", "c"] -> (0.0025*Mole)/Liter, 
    metabolite["h", "c"] -> (8.99757344480193*^-8*Mole)/Liter, 
    metabolite["h2o", "c"] -> (0.001*Mole)/Liter, 
    v["vhk"] -> (0.0011200000000000001*Mole)/(Hour*Liter), 
    v["vpgi"] -> (0.0011200000000000001*Mole)/(Hour*Liter), 
    v["vpfk"] -> (0.0011200000000000001*Mole)/(Hour*Liter), 
    v["vtpi"] -> (0.0011200000000000001*Mole)/(Hour*Liter), 
    v["vald"] -> (0.0011200000000000001*Mole)/(Hour*Liter), 
    v["vgapdh"] -> (0.0022400000000000002*Mole)/(Hour*Liter), 
    v["vpgk"] -> (0.0022400000000000002*Mole)/(Hour*Liter), 
    v["vpglm"] -> (0.0022400000000000002*Mole)/(Hour*Liter), 
    v["veno"] -> (0.0022400000000000002*Mole)/(Hour*Liter), 
    v["vpk"] -> (0.0022400000000000002*Mole)/(Hour*Liter), 
    v["vldh"] -> (0.002016*Mole)/(Hour*Liter), 
    v["vamp"] -> (0.000014*Mole)/(Hour*Liter), v["vapk"] -> 0., 
    v["vpyr"] -> (0.00022400000000000002*Mole)/(Hour*Liter), 
    v["vlac"] -> (0.002016*Mole)/(Hour*Liter), 
    v["vatp"] -> (0.0022400000000000002*Mole)/(Hour*Liter), 
    v["vnadh"] -> (0.00022400000000000002*Mole)/(Hour*Liter), 
    v["vgluin"] -> (0.0011200000000000001*Mole)/(Hour*Liter), 
    v["vampin"] -> (0.000014*Mole)/(Hour*Liter), 
    v["vh"] -> (0.0026880000000000003*Mole)/(Hour*Liter), v["vh2o"] -> 0.}, 
  "Parameters" -> {parameter["Volume", "c"] -> Liter, Keq["vhk"] -> 850, 
    Keq["vpgi"] -> 0.41, Keq["vpfk"] -> 310, Keq["vtpi"] -> 
     0.05714285714285714, Keq["vald"] -> (0.000082*Mole)/Liter, 
    Keq["vgapdh"] -> (17.9*Liter)/Mole, Keq["vpgk"] -> 1800, 
    Keq["vpglm"] -> 0.14705882352941177, Keq["veno"] -> 1.6949152542372883, 
    Keq["vpk"] -> 363000, Keq["vldh"] -> 26300, Keq["vamp"] -> Infinity, 
    Keq["vapk"] -> 1.65, Keq["vpyr"] -> 1., Keq["vlac"] -> 1., 
    Keq["vatp"] -> (Mole*Infinity)/Liter, Keq["vnadh"] -> Infinity, 
    Keq["vgluin"] -> Infinity, Keq["vampin"] -> Infinity, Keq["vh"] -> 1., 
    Keq["vh2o"] -> 1., metabolite["pyr", "Xt"] -> (0.00006*Mole)/Liter, 
    metabolite["amp", "Xt"] -> Mole/(1000*Liter), metabolite["h", "Xt"] -> 
     (6.30957344480193*^-8*Mole)/Liter, metabolite[_, "Xt"] -> 
     Mole/(1000*Liter), rateconst["vhk", True] -> (700.0072543398843*Liter)/
      (Hour*Mole), rateconst["vpgi", True] -> 3644.44444444458/Hour, 
    rateconst["vpfk", True] -> (35368.783747799374*Liter)/(Hour*Mole), 
    rateconst["vtpi", True] -> 34.355828220858896/Hour, 
    rateconst["vald", True] -> 2834.567901234567/Hour, 
    rateconst["vgapdh", True] -> (3.3767492421768246*^9*Liter^2)/
      (Hour*Mole^2), rateconst["vpgk", True] -> (1.2735312697409995*^9*Liter)/
      (Hour*Mole), rateconst["vpglm", True] -> 4869.565217391387/Hour, 
    rateconst["veno", True] -> 1763.7795275590581/Hour, 
    rateconst["vpk", True] -> (454385.55191136815*Liter)/(Hour*Mole), 
    rateconst["vldh", True] -> (1.1125739886027805*^6*Liter)/(Hour*Mole), 
    rateconst["vamp", True] -> 0.16142399019925777/Hour, 
    rateconst["vapk", True] -> 0, rateconst["vpyr", True] -> 
     744.1860465116213/Hour, rateconst["vlac", True] -> 
     5.599999999999999/Hour, rateconst["vatp", True] -> 
     1.4000000000000001/Hour, rateconst["vnadh", True] -> 
     7.44186046511628/Hour, rateconst["vgluin", True] -> 1.12/Hour, 
    rateconst["vampin", True] -> 0.014/Hour, rateconst["vh", True] -> 
     100000.00000000001/Hour, rateconst["vh2o", True] -> 0}}]
