(* Created by Wolfram Mathematica 8.0 : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$133", "Stoichiometry" -> 
   SparseArray[Automatic, {15, 19}, 0, {1, {{0, 2, 6, 9, 14, 19, 26, 28, 30, 
      34, 37, 43, 45, 47, 49, 52}, {{2}, {4}, {1}, {3}, {5}, {6}, {5}, {15}, 
      {19}, {4}, {5}, {6}, {7}, {16}, {6}, {9}, {15}, {17}, {19}, {1}, {4}, 
      {6}, {7}, {9}, {18}, {19}, {8}, {13}, {7}, {9}, {1}, {9}, {10}, {13}, 
      {1}, {7}, {11}, {4}, {6}, {9}, {12}, {13}, {19}, {4}, {15}, {13}, {14}, 
      {14}, {15}, {5}, {15}, {19}}}, {-1, -1, -1, -1, -1, 1, 1, 2, -1, 1, 1, 
     -1, -1, -1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, 1, -1, 1, 1, -1, 1, 
     1, -1, -1, 1, 1, -1, 2, 1, 1, -1, -1, -1, -1, 1, 1, -1, 1, -1, -1, -2, 
     1}}], "Species" -> {metabolite["ade", "c"], metabolite["ado", "c"], 
    metabolite["adp", "c"], metabolite["amp", "c"], metabolite["h", "c"], 
    metabolite["h2o", "c"], metabolite["hyp", "c"], metabolite["imp", "c"], 
    metabolite["ino", "c"], metabolite["nh3", "c"], metabolite["phos", "c"], 
    metabolite["prpp", "c"], metabolite["r1p", "c"], metabolite["r5p", "c"], 
    metabolite["atp", "c"]}, "Fluxes" -> {v["vada"], v["vade"], v["vado"], 
    v["vadprt"], v["vak"], v["vampase"], v["vampda"], v["vhyp"], 
    v["vimpase"], v["vino"], v["vnh3"], v["vphos"], v["vpnpase"], v["vprm"], 
    v["vprppsyn"], v["vamp"], v["vh"], v["vh2o"], v["vatpgen"]}, 
  "Constraints" -> {}, "InitialConditions" -> 
   {metabolite["r5p", "c"] -> (4.94*^-6*Mole)/Liter, 
    metabolite["ade", "c"] -> (1.*^-6*Mole)/Liter, 
    metabolite["ado", "c"] -> (1.2*^-6*Mole)/Liter, 
    metabolite["imp", "c"] -> (0.00001*Mole)/Liter, 
    metabolite["ino", "c"] -> (1.*^-6*Mole)/Liter, 
    metabolite["hyp", "c"] -> (2.*^-6*Mole)/Liter, 
    metabolite["r1p", "c"] -> (0.00006*Mole)/Liter, 
    metabolite["prpp", "c"] -> (5.*^-6*Mole)/Liter, 
    metabolite["amp", "c"] -> (0.00008672812499999999*Mole)/Liter, 
    metabolite["adp", "c"] -> (0.00029*Mole)/Liter, 
    metabolite["atp", "c"] -> (0.0016*Mole)/Liter, 
    metabolite["phos", "c"] -> (0.0025*Mole)/Liter, 
    metabolite["h", "c"] -> (6.30957344480193*^-8*Mole)/Liter, 
    metabolite["h2o", "c"] -> (0.0009999997600000001*Mole)/Liter, 
    metabolite["nh3", "c"] -> (0.000091*Mole)/Liter, 
    v["vak"] -> (0.00012*Mole)/(Hour*Liter), v["vampase"] -> 
     (0.00012*Mole)/(Hour*Liter), v["vampda"] -> 
     (0.000014*Mole)/(Hour*Liter), v["vimpase"] -> 
     (0.000014*Mole)/(Hour*Liter), v["vada"] -> (0.00001*Mole)/(Hour*Liter), 
    v["vpnpase"] -> (0.000014*Mole)/(Hour*Liter), 
    v["vprm"] -> (0.000014*Mole)/(Hour*Liter), 
    v["vatpgen"] -> (0.000148*Mole)/(Hour*Liter), 
    v["vprppsyn"] -> (0.000014*Mole)/(Hour*Liter), 
    v["vadprt"] -> (0.000014*Mole)/(Hour*Liter), 
    v["vado"] -> (-9.999999999999996*^-6*Mole)/(Hour*Liter), 
    v["vade"] -> (-0.000014*Mole)/(Hour*Liter), 
    v["vino"] -> (0.00001*Mole)/(Hour*Liter), 
    v["vhyp"] -> (0.000014*Mole)/(Hour*Liter), v["vamp"] -> 0., 
    v["vh"] -> 0., v["vh2o"] -> (-0.000024000000000000007*Mole)/(Hour*Liter), 
    v["vphos"] -> 0., v["vnh3"] -> (0.000024*Mole)/(Hour*Liter)}, 
  "GPR" -> {}, "BoundaryConditions" -> {metabolite["h", "c"], 
    metabolite["h2o", "c"]}, "Constant" -> {}, "ReversibleColumnIndices" -> 
   {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19}, 
  "CustomRateLaws" -> {}, "CustomODE" -> {}, "Name" -> "MASSmodel$133", 
  "ElementalComposition" -> {metabolite["ade", "c"] -> 5*"C" + 5*"H" + 5*"N", 
    metabolite["ado", "c"] -> 10*"C" + 13*"H" + 5*"N" + 4*"O", 
    metabolite["adp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 10*"O" + 2*"P", 
    metabolite["amp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 7*"O" + "P", 
    metabolite["atp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 13*"O" + 3*"P", 
    metabolite["h", "c"] -> "H", metabolite["h2o", "c"] -> 2*"H" + "O", 
    metabolite["hyp", "c"] -> 5*"C" + 4*"H" + 4*"N" + "O", 
    metabolite["imp", "c"] -> 10*"C" + 12*"H" + 4*"N" + 8*"O" + "P", 
    metabolite["ino", "c"] -> 10*"C" + 12*"H" + 4*"N" + 5*"O", 
    metabolite["nh3", "c"] -> 3*"H" + "N", metabolite["phos", "c"] -> 
     "H" + 4*"O" + "P", metabolite["prpp", "c"] -> 5*"C" + 8*"H" + 14*"O" + 
      3*"P", metabolite["r1p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["r5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P"}, 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "UnitChecking" -> True, "Parameters" -> {parameter["Volume", "c"] -> Liter, 
    Keq["vak"] -> 1000000, Keq["vampase"] -> (1000*Mole)/Liter, 
    Keq["vada"] -> (1000*Mole)/Liter, Keq["vampda"] -> (1000*Mole)/Liter, 
    Keq["vimpase"] -> (1000*Mole)/Liter, Keq["vpnpase"] -> 0.09, 
    Keq["vprm"] -> 13.3, Keq["vprppsyn"] -> 1000000, 
    Keq["vadprt"] -> (1000*Mole)/Liter, Keq["vade"] -> 1, Keq["vado"] -> 1, 
    Keq["vino"] -> 1, Keq["vhyp"] -> 1, Keq["vphos"] -> 1, Keq["vnh3"] -> 1, 
    Keq["vatpgen"] -> (1000000000*Liter)/Mole, Keq["vh"] -> 1, 
    Keq["vh2o"] -> 1, Keq["vamp"] -> 1, metabolite["ado", "Xt"] -> 
     (1.2001*^-6*Mole)/Liter, metabolite["ade", "Xt"] -> 
     (1.00014*^-6*Mole)/Liter, metabolite["ino", "Xt"] -> 
     (9.999*^-7*Mole)/Liter, metabolite["hyp", "Xt"] -> 
     (1.99986*^-6*Mole)/Liter, metabolite["phos", "Xt"] -> 
     (0.0025*Mole)/Liter, metabolite["nh3", "Xt"] -> 
     (0.0000909999*Mole)/Liter, metabolite["amp", "Xt"] -> 
     (0.0000954009375*Mole)/Liter, metabolite["h", "Xt"] -> 
     (6.30957344480193*^-8*Mole)/Liter, metabolite[_, "Xt"] -> 
     Mole/(1000*Liter), rateconst["vada", True] -> 8.333333965277827/Hour, 
    rateconst["vado", True] -> 99999.99999999245/Hour, 
    rateconst["vadprt", True] -> (3.140457486845391*^6*Liter)/(Hour*Mole), 
    rateconst["vak", True] -> (62500.818733259235*Liter)/(Hour*Mole), 
    rateconst["vampase", True] -> 1.3836342495690155/Hour, 
    rateconst["vampda", True] -> 0.16142399189300857/Hour, 
    rateconst["vimpase", True] -> 1.4000003500000873/Hour, 
    rateconst["vpnpase", True] -> (11999.999999999998*Liter)/(Hour*Mole), 
    rateconst["vprm", True] -> 0.23478677527551506/Hour, 
    rateconst["vprppsyn", True] -> (1.1070344497649912*^6*Liter^2)/
      (Hour*Mole^2), rateconst["vh2o", True] -> 0.024000000000000007/Hour, 
    rateconst["vatpgen", True] -> (204.13838154677305*Liter)/(Hour*Mole), 
    rateconst["vh", True] -> 100000/Hour, rateconst["vade", True] -> 
     100000/Hour, rateconst["vino", True] -> 100000/Hour, 
    rateconst["vhyp", True] -> 100000/Hour, rateconst["vnh3", True] -> 
     100000/Hour, rateconst["vphos", True] -> 100000/Hour, 
    rateconst["vamp", True] -> 100000/Hour}, "Notes" -> "\nModel constructed \
on Tue 28 Aug 2012 14:01:35 by niko on staphylococcus.ucsd.edu using \
Mathematica 8.0 for Mac OS X x86 (64-bit) (November 6, 2010) at the following \
geodetic location: latitude 32.88; longitude -117.24"}]
