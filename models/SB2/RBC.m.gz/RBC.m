(* Created by Wolfram Mathematica 9.0 : www.wolfram.com *)
MASSmodel[{"Stoichiometry" -> SparseArray[Automatic, {48, 53}, 0, 
    {1, {{0, 2, 6, 14, 19, 27, 29, 31, 32, 35, 37, 41, 43, 46, 52, 54, 56, 
      58, 60, 76, 86, 88, 90, 92, 94, 96, 98, 102, 104, 107, 110, 113, 118, 
      120, 123, 125, 128, 136, 138, 141, 143, 147, 150, 152, 155, 157, 158, 
      161, 164}, {{2}, {4}, {1}, {3}, {5}, {7}, {5}, {9}, {10}, {28}, {37}, 
      {39}, {43}, {46}, {4}, {5}, {7}, {8}, {9}, {5}, {9}, {10}, {28}, {37}, 
      {39}, {43}, {46}, {11}, {17}, {6}, {53}, {23}, {12}, {13}, {23}, {50}, 
      {52}, {37}, {38}, {50}, {52}, {6}, {37}, {15}, {28}, {38}, {6}, {16}, 
      {50}, {51}, {52}, {53}, {15}, {40}, {18}, {28}, {17}, {40}, {19}, {20}, 
      {7}, {10}, {13}, {15}, {16}, {19}, {20}, {21}, {28}, {30}, {33}, {34}, 
      {37}, {40}, {43}, {46}, {1}, {4}, {7}, {8}, {10}, {12}, {14}, {22}, 
      {30}, {40}, {23}, {24}, {24}, {25}, {25}, {26}, {26}, {27}, {29}, {44}, 
      {8}, {30}, {1}, {30}, {31}, {44}, {32}, {33}, {16}, {33}, {34}, {15}, 
      {17}, {20}, {1}, {8}, {35}, {24}, {25}, {26}, {27}, {36}, {14}, {43}, 
      {13}, {16}, {39}, {14}, {41}, {12}, {39}, {41}, {4}, {7}, {10}, {12}, 
      {16}, {30}, {42}, {44}, {4}, {46}, {33}, {43}, {47}, {44}, {45}, {45}, 
      {46}, {49}, {51}, {17}, {48}, {49}, {50}, {51}, {48}, {51}, {52}, {19}, 
      {20}, {27}, {16}, {33}, {34}, {15}, {17}, {20}}}, {-1, -1, -1, -1, -1, 
     1, 1, -2, 1, 1, 1, -1, -1, 2, 1, 1, -1, -1, 1, -1, 1, -1, -1, -1, 1, 1, 
     -2, -1, 1, 1, -1, 1, -1, 1, -1, 1, -1, -1, 1, 1, 1, -1, 1, -1, 1, -1, 1, 
     -1, -1, 1, 1, 1, 1, -1, 1, -1, -1, 1, -2, 2, 1, 1, 1, 1, 1, 2, -1, -1, 
     1, 1, -1, 1, 1, 1, -1, 1, -1, -1, -1, -1, -1, -1, 1, -1, -1, -1, -1, -1, 
     1, -1, 1, -1, 1, -1, -1, 1, 1, -1, 1, 1, -1, -1, -1, 1, -1, 1, 1, -1, 
     -1, 1, 1, 1, -1, -1, -1, -1, -1, -1, 1, -1, -1, 1, -1, -1, 1, 1, 1, -1, 
     2, 1, 1, 1, -1, 1, -1, -1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 
     -1, -1, 1, 1, -1, -1, 1, -1, 1, 1, -1, -1, 1, 1, -1}}], 
  "Species" -> {metabolite["ade", "c"], metabolite["ado", "c"], 
    metabolite["adp", "c"], metabolite["amp", "c"], metabolite["atp", "c"], 
    metabolite["co2", "c"], metabolite["dhap", "c"], metabolite["dhb", "c"], 
    metabolite["dpg23", "c"], metabolite["e4p", "c"], metabolite["f6p", "c"], 
    metabolite["fdp", "c"], metabolite["g6p", "c"], metabolite["gap", "c"], 
    metabolite["gl6p", "c"], metabolite["glu", "c"], metabolite["go6p", "c"], 
    metabolite["gsh", "c"], metabolite["h", "c"], metabolite["h2o", "c"], 
    metabolite["hb", "c"], metabolite["hbo2", "c"], metabolite["hbo22", "c"], 
    metabolite["hbo23", "c"], metabolite["hyp", "c"], metabolite["imp", "c"], 
    metabolite["ino", "c"], metabolite["lac", "c"], metabolite["nad", "c"], 
    metabolite["nadp", "c"], metabolite["nh3", "c"], metabolite["o2", "c"], 
    metabolite["pep", "c"], metabolite["pg13", "c"], metabolite["pg2", "c"], 
    metabolite["pg3", "c"], metabolite["phos", "c"], metabolite["prpp", "c"], 
    metabolite["pyr", "c"], metabolite["r1p", "c"], metabolite["r5p", "c"], 
    metabolite["ru5p", "c"], metabolite["s7p", "c"], metabolite["x5p", "c"], 
    metabolite["gssg", "c"], metabolite["hbo24", "c"], 
    metabolite["nadh", "c"], metabolite["nadph", "c"]}, 
  "Fluxes" -> {v["vada"], v["vade"], v["vado"], v["vadprt"], v["vak"], 
    v["vald"], v["vampase"], v["vampda"], v["vapk"], v["vatp"], v["vco2"], 
    v["vdpgase"], v["vdpgm"], v["veno"], v["vg6pdh"], v["vgapdh"], 
    v["vgl6pdh"], v["vgluin"], v["vgshr"], v["vgssgr"], v["vh"], v["vh2o"], 
    v["vhbdpg"], v["vhbo1"], v["vhbo2"], v["vhbo3"], v["vhbo4"], v["vhk"], 
    v["vhyp"], v["vimpase"], v["vino"], v["vlac"], v["vldh"], v["vnadh"], 
    v["vnh3"], v["vo2"], v["vpfk"], v["vpgi"], v["vpgk"], v["vpglase"], 
    v["vpglm"], v["vphos"], v["vpk"], v["vpnpase"], v["vprm"], v["vprppsyn"], 
    v["vpyr"], v["vr5pe"], v["vr5pi"], v["vtala"], v["vtki"], v["vtkii"], 
    v["vtpi"]}, "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 
    11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 
    29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 
    47, 48, 49, 50, 51, 52, 53}, "CustomODE" -> {}, "Notes" -> "", 
  "Synonyms" -> {}, "Events" -> {}, 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "ID" -> "MASSmodel$774 \[Union] MASSmodel$977 \[Union] MASSmodel$568 \
\[Union] MASSmodel$1093", "Name" -> "MASSmodel$774 \[Union] MASSmodel$977 \
\[Union] MASSmodel$568 \[Union] MASSmodel$1093", 
  "Constraints" -> {v["vgluin"] -> {-Infinity, 0}}, "CustomRateLaws" -> {}, 
  "GPR" -> {}, "ElementalComposition" -> 
   {metabolite["dhap", "c"] -> 3*"C" + 5*"H" + 6*"O" + "P", 
    metabolite["fdp", "c"] -> 6*"C" + 10*"H" + 12*"O" + 2*"P", 
    metabolite["glu", "c"] -> 6*"C" + 12*"H" + 6*"O", 
    metabolite["lac", "c"] -> 3*"C" + 5*"H" + 3*"O", 
    metabolite["nad", "c"] -> "&NAD&", metabolite["nadh", "c"] -> 
     "H" + "&NAD&", metabolite["pep", "c"] -> 3*"C" + 2*"H" + 6*"O" + "P", 
    metabolite["pg2", "c"] -> 3*"C" + 4*"H" + 7*"O" + "P", 
    metabolite["pyr", "c"] -> 3*"C" + 3*"H" + 3*"O", 
    metabolite["co2", "c"] -> "C" + 2*"O", metabolite["e4p", "c"] -> 
     4*"C" + 7*"H" + 7*"O" + "P", metabolite["f6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P", metabolite["g6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P", metabolite["gap", "c"] -> 
     3*"C" + 5*"H" + 6*"O" + "P", metabolite["gl6p", "c"] -> 
     6*"C" + 9*"H" + 9*"O" + "P", metabolite["go6p", "c"] -> 
     6*"C" + 10*"H" + 10*"O" + "P", metabolite["gsh", "c"] -> 
     10*"C" + 17*"H" + 3*"N" + 6*"O" + "S", metabolite["gssg", "c"] -> 
     20*"C" + 32*"H" + 6*"N" + 12*"O" + 2*"S", metabolite["nadp", "c"] -> 
     "&NADP&", metabolite["nadph", "c"] -> "H" + "&NADP&", 
    metabolite["ru5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["s7p", "c"] -> 7*"C" + 13*"H" + 10*"O" + "P", 
    metabolite["x5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["ade", "c"] -> 5*"C" + 5*"H" + 5*"N", 
    metabolite["ado", "c"] -> 10*"C" + 13*"H" + 5*"N" + 4*"O", 
    metabolite["adp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 10*"O" + 2*"P", 
    metabolite["amp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 7*"O" + "P", 
    metabolite["atp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 13*"O" + 3*"P", 
    metabolite["hyp", "c"] -> 5*"C" + 4*"H" + 4*"N" + "O", 
    metabolite["imp", "c"] -> 10*"C" + 12*"H" + 4*"N" + 8*"O" + "P", 
    metabolite["ino", "c"] -> 10*"C" + 12*"H" + 4*"N" + 5*"O", 
    metabolite["nh3", "c"] -> 3*"H" + "N", metabolite["prpp", "c"] -> 
     5*"C" + 8*"H" + 14*"O" + 3*"P", metabolite["r1p", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P", metabolite["r5p", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P", metabolite["dhb", "c"] -> 
     3*"C" + 3*"H" + "&Hb&" + 10*"O" + 2*"P", metabolite["dpg23", "c"] -> 
     3*"C" + 3*"H" + 10*"O" + 2*"P", metabolite["h", "c"] -> "H", 
    metabolite["h2o", "c"] -> 2*"H" + "O", metabolite["hb", "c"] -> "&Hb&", 
    metabolite["hbo2", "c"] -> "&Hb&" + 2*"O", metabolite["hbo22", "c"] -> 
     "&Hb&" + 4*"O", metabolite["hbo23", "c"] -> "&Hb&" + 6*"O", 
    metabolite["hbo24", "c"] -> "&Hb&" + 8*"O", metabolite["o2", "c"] -> 
     2*"O", metabolite["pg13", "c"] -> 3*"C" + 4*"H" + 10*"O" + 2*"P", 
    metabolite["pg3", "c"] -> 3*"C" + 4*"H" + 7*"O" + "P", 
    metabolite["phos", "c"] -> "H" + 4*"O" + "P"}, 
  "BoundaryConditions" -> {}, "Constant" -> {}, "UnitChecking" -> True, 
  "InitialConditions" -> {metabolite["glu", "c"] -> 
     Unit[1., "Millimole"/"Liter"], metabolite["fdp", "c"] -> 
     Unit[0.0146, "Millimole"/"Liter"], metabolite["dhap", "c"] -> 
     Unit[0.16, "Millimole"/"Liter"], metabolite["pg2", "c"] -> 
     Unit[0.0113, "Millimole"/"Liter"], metabolite["pep", "c"] -> 
     Unit[0.017, "Millimole"/"Liter"], metabolite["pyr", "c"] -> 
     Unit[0.060301, "Millimole"/"Liter"], metabolite["lac", "c"] -> 
     Unit[1.36, "Millimole"/"Liter"], metabolite["nad", "c"] -> 
     Unit[0.0589, "Millimole"/"Liter"], metabolite["nadh", "c"] -> 
     Unit[0.0301, "Millimole"/"Liter"], metabolite["g6p", "c"] -> 
     Unit[0.0486, "Millimole"/"Liter"], metabolite["f6p", "c"] -> 
     Unit[0.0198, "Millimole"/"Liter"], metabolite["gap", "c"] -> 
     Unit[0.00728, "Millimole"/"Liter"], metabolite["gl6p", "c"] -> 
     Unit[0.001754242723, "Millimole"/"Liter"], metabolite["go6p", "c"] -> 
     Unit[0.037475258, "Millimole"/"Liter"], metabolite["ru5p", "c"] -> 
     Unit[0.0049367903, "Millimole"/"Liter"], metabolite["x5p", "c"] -> 
     Unit[0.014784196, "Millimole"/"Liter"], metabolite["s7p", "c"] -> 
     Unit[0.023987984, "Millimole"/"Liter"], metabolite["e4p", "c"] -> 
     Unit[0.0050750696, "Millimole"/"Liter"], metabolite["nadp", "c"] -> 
     Unit[0.0002, "Millimole"/"Liter"], metabolite["nadph", "c"] -> 
     Unit[0.0658, "Millimole"/"Liter"], metabolite["gsh", "c"] -> 
     Unit[3.2, "Millimole"/"Liter"], metabolite["gssg", "c"] -> 
     Unit[0.11999999999999966, "Millimole"/"Liter"], 
    metabolite["co2", "c"] -> Unit[1.0000021, "Millimole"/"Liter"], 
    metabolite["r5p", "c"] -> Unit[0.00494, "Millimole"/"Liter"], 
    metabolite["ade", "c"] -> Unit[0.001, "Millimole"/"Liter"], 
    metabolite["ado", "c"] -> Unit[0.0012, "Millimole"/"Liter"], 
    metabolite["imp", "c"] -> Unit[0.01, "Millimole"/"Liter"], 
    metabolite["ino", "c"] -> Unit[0.001, "Millimole"/"Liter"], 
    metabolite["hyp", "c"] -> Unit[0.002, "Millimole"/"Liter"], 
    metabolite["r1p", "c"] -> Unit[0.06, "Millimole"/"Liter"], 
    metabolite["prpp", "c"] -> Unit[0.005, "Millimole"/"Liter"], 
    metabolite["amp", "c"] -> Unit[0.08672812499999999, "Millimole"/"Liter"], 
    metabolite["adp", "c"] -> Unit[0.29, "Millimole"/"Liter"], 
    metabolite["atp", "c"] -> Unit[1.6, "Millimole"/"Liter"], 
    metabolite["nh3", "c"] -> Unit[0.091, "Millimole"/"Liter"], 
    metabolite["dhb", "c"] -> Unit[0.04620957029335471, "Millimole"/"Liter"], 
    metabolite["hb", "c"] -> Unit[0.059625251991425425, "Millimole"/"Liter"], 
    metabolite["hbo2", "c"] -> Unit[0.05008521167279736, 
      "Millimole"/"Liter"], metabolite["hbo22", "c"] -> 
     Unit[0.07362526115901212, "Millimole"/"Liter"], 
    metabolite["hbo23", "c"] -> Unit[0.26284218233767326, 
      "Millimole"/"Liter"], metabolite["hbo24", "c"] -> 
     Unit[6.807612522545737, "Millimole"/"Liter"], 
    metabolite["o2", "c"] -> Unit[0.0200788, "Millimole"/"Liter"], 
    metabolite["dpg23", "c"] -> Unit[3.1, "Millimole"/"Liter"], 
    metabolite["pg13", "c"] -> Unit[0.000243, "Millimole"/"Liter"], 
    metabolite["pg3", "c"] -> Unit[0.0773, "Millimole"/"Liter"], 
    metabolite["phos", "c"] -> Unit[2.5, "Millimole"/"Liter"], 
    metabolite["h", "c"] -> Unit[0.00008997573444801929, 
      "Millimole"/"Liter"], metabolite["h2o", "c"] -> 
     Unit[1., "Millimole"/"Liter"], v["vade"] -> 
     Unit[-0.014, "Millimole"/("Hour"*"Liter")], 
    v["vadprt"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["vada"] -> Unit[0.006999999999999895, "Millimole"/("Hour"*"Liter")], 
    v["vado"] -> Unit[-0.0070000000000012275, "Millimole"/("Hour"*"Liter")], 
    v["vak"] -> Unit[-0.5450000000000021, "Millimole"/("Hour"*"Liter")], 
    v["vampase"] -> Unit[-0.5450000000000035, "Millimole"/("Hour"*"Liter")], 
    v["vampda"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["vapk"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["vatp"] -> Unit[2.24, "Millimole"/("Hour"*"Liter")], 
    v["vdpgase"] -> Unit[0.441, "Millimole"/("Hour"*"Liter")], 
    v["vco2"] -> Unit[0.20399999999999996, "Millimole"/("Hour"*"Liter")], 
    v["vgl6pdh"] -> Unit[0.20399999999999996, "Millimole"/("Hour"*"Liter")], 
    v["vgluin"] -> Unit[1.12, "Millimole"/("Hour"*"Liter")], 
    v["vg6pdh"] -> Unit[0.20399999999999996, "Millimole"/("Hour"*"Liter")], 
    v["vgssgr"] -> Unit[0.4079999999999999, "Millimole"/("Hour"*"Liter")], 
    v["vgshr"] -> Unit[0.4079999999999999, "Millimole"/("Hour"*"Liter")], 
    v["vhbdpg"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["vdpgm"] -> Unit[0.441, "Millimole"/("Hour"*"Liter")], 
    v["vhbo1"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["vhbo2"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["vhbo3"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["vhbo4"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["vhk"] -> Unit[1.12, "Millimole"/("Hour"*"Liter")], 
    v["vimpase"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["vino"] -> Unit[0.01, "Millimole"/("Hour"*"Liter")], 
    v["vlac"] -> Unit[1.943, "Millimole"/("Hour"*"Liter")], 
    v["vldh"] -> Unit[1.943, "Millimole"/("Hour"*"Liter")], 
    v["vgapdh"] -> Unit[2.1670000000000003, "Millimole"/("Hour"*"Liter")], 
    v["vnadh"] -> Unit[0.224, "Millimole"/("Hour"*"Liter")], 
    v["vnh3"] -> Unit[0.020999999999999908, "Millimole"/("Hour"*"Liter")], 
    v["vo2"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["vald"] -> Unit[1.05, "Millimole"/("Hour"*"Liter")], 
    v["vpfk"] -> Unit[1.05, "Millimole"/("Hour"*"Liter")], 
    v["vpgi"] -> Unit[0.916, "Millimole"/("Hour"*"Liter")], 
    v["vpgk"] -> Unit[1.726, "Millimole"/("Hour"*"Liter")], 
    v["vpglase"] -> Unit[0.20399999999999996, "Millimole"/("Hour"*"Liter")], 
    v["veno"] -> Unit[2.1670000000000003, "Millimole"/("Hour"*"Liter")], 
    v["vh2o"] -> Unit[-0.22199999999999642, "Millimole"/("Hour"*"Liter")], 
    v["vpglm"] -> Unit[2.1670000000000003, "Millimole"/("Hour"*"Liter")], 
    v["vpk"] -> Unit[2.1670000000000007, "Millimole"/("Hour"*"Liter")], 
    v["vhyp"] -> Unit[0.010999999999999899, "Millimole"/("Hour"*"Liter")], 
    v["vpnpase"] -> Unit[0.010999999999999899, "Millimole"/("Hour"*"Liter")], 
    v["vphos"] -> Unit[-3.726519093305569*^-15, 
      "Millimole"/("Hour"*"Liter")], v["vprm"] -> Unit[0.010999999999999899, 
      "Millimole"/("Hour"*"Liter")], v["vprppsyn"] -> 
     Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["vh"] -> Unit[3.430999999999997, "Millimole"/("Hour"*"Liter")], 
    v["vpyr"] -> Unit[0.224, "Millimole"/("Hour"*"Liter")], 
    v["vr5pe"] -> Unit[0.134, "Millimole"/("Hour"*"Liter")], 
    v["vr5pi"] -> Unit[0.07000000000000006, "Millimole"/("Hour"*"Liter")], 
    v["vtala"] -> Unit[0.067, "Millimole"/("Hour"*"Liter")], 
    v["vtki"] -> Unit[0.067, "Millimole"/("Hour"*"Liter")], 
    v["vtkii"] -> Unit[0.067, "Millimole"/("Hour"*"Liter")], 
    v["vtpi"] -> Unit[1.05, "Millimole"/("Hour"*"Liter")]}, 
  "Parameters" -> {Keq["vhk"] -> 850, Keq["vpgi"] -> 0.41, 
    Keq["vpfk"] -> 310, Keq["vtpi"] -> 0.05714285714285714, 
    Keq["vald"] -> Unit[0.082, "Millimole"/"Liter"], 
    Keq["vgapdh"] -> Unit[0.0179, "Liter"/"Millimole"], Keq["vpgk"] -> 1800, 
    Keq["vpglm"] -> 0.14705882352941177, Keq["veno"] -> 1.6949152542372883, 
    Keq["vpk"] -> 363000, Keq["vldh"] -> 26300, Keq["vapk"] -> 1.65, 
    Keq["vpyr"] -> 1., Keq["vlac"] -> 1., Keq["vatp"] -> 
     Unit[Infinity, "Millimole"/"Liter"], Keq["vnadh"] -> Infinity, 
    Keq["vgluin"] -> Infinity, metabolite["pyr", "Xt"] -> 
     Unit[0.06, "Millimole"/"Liter"], metabolite["glu", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["lac", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], rateconst["vapk", True] -> 
     Unit[100000, "Liter"/("Hour"*"Millimole")], Keq["vg6pdh"] -> 1000, 
    Keq["vpglase"] -> 1000, Keq["vgl6pdh"] -> 
     Unit[1000, "Millimole"/"Liter"], Keq["vr5pe"] -> 3, 
    Keq["vr5pi"] -> 2.57, Keq["vtkii"] -> 10.3, Keq["vtala"] -> 1.05, 
    Keq["vgssgr"] -> Unit[100, "Millimole"/"Liter"], 
    Keq["vgshr"] -> Unit[2, "Liter"/"Millimole"], Keq["vco2"] -> 1, 
    metabolite["co2", "Xt"] -> Unit[1, "Millimole"/"Liter"], 
    metabolite["g6p", "Xt"] -> Unit[1, "Millimole"/"Liter"], 
    metabolite["f6p", "Xt"] -> Unit[1, "Millimole"/"Liter"], 
    metabolite["r5p", "Xt"] -> Unit[1, "Millimole"/"Liter"], 
    metabolite["gap", "Xt"] -> Unit[1, "Millimole"/"Liter"], 
    Keq["vada"] -> Unit[1000000, "Millimole"/"Liter"], 
    Keq["vampda"] -> Unit[1000000, "Millimole"/"Liter"], 
    Keq["vimpase"] -> Unit[1000000, "Millimole"/"Liter"], 
    Keq["vpnpase"] -> 0.09, Keq["vprm"] -> 13.3, Keq["vprppsyn"] -> 1000000, 
    Keq["vadprt"] -> Unit[1000000, "Millimole"/"Liter"], Keq["vade"] -> 1, 
    Keq["vado"] -> 1, Keq["vino"] -> 1, Keq["vhyp"] -> 1, Keq["vphos"] -> 1, 
    Keq["vnh3"] -> 1, Keq["vh"] -> 1, Keq["vh2o"] -> 1, 
    metabolite["ado", "Xt"] -> Unit[0.0012001, "Millimole"/"Liter"], 
    metabolite["ade", "Xt"] -> Unit[0.00100014, "Millimole"/"Liter"], 
    metabolite["ino", "Xt"] -> Unit[0.0009999, "Millimole"/"Liter"], 
    metabolite["hyp", "Xt"] -> Unit[0.00199986, "Millimole"/"Liter"], 
    metabolite["phos", "Xt"] -> Unit[2.5, "Millimole"/"Liter"], 
    metabolite["nh3", "Xt"] -> Unit[0.0909999, "Millimole"/"Liter"], 
    metabolite["amp", "Xt"] -> Unit[0.09540093749999999, 
      "Millimole"/"Liter"], metabolite["h", "Xt"] -> 
     Unit[0.00006309573444801929, "Millimole"/"Liter"], 
    metabolite["h2o", "Xt"] -> Unit[1, "Millimole"/"Liter"], 
    rateconst["vh2o", True] -> Unit[100000.00000637631, "Hour"^(-1)], 
    rateconst["vphos", True] -> Unit[100000, "Hour"^(-1)], 
    parameter["Volume", "c"] -> Unit[1, "Liter"], 
    Keq["vdpgase"] -> Unit[Infinity, "Millimole"/"Liter"], 
    Keq["vdpgm"] -> Infinity, Keq["vhbdpg"] -> 
     Unit[1/4, "Liter"/"Millimole"], Keq["vhbo1"] -> 
     Unit[41.835169432436196, "Liter"/"Millimole"], 
    Keq["vhbo2"] -> Unit[73.21154650676336, "Liter"/"Millimole"], 
    Keq["vhbo3"] -> Unit[177.79947008785382, "Liter"/"Millimole"], 
    Keq["vhbo4"] -> Unit[1289.9177241667828, "Liter"/"Millimole"], 
    Keq["vo2"] -> 1, rateconst["vhbo1", True] -> Unit[506935.270702259, 
      "Liter"/("Hour"*"Millimole")], rateconst["vhbo2", True] -> 
     Unit[511077.050923776, "Liter"/("Hour"*"Millimole")], 
    rateconst["vhbo3", True] -> Unit[509243.459567699, 
      "Liter"/("Hour"*"Millimole")], rateconst["vhbo4", True] -> 
     Unit[501595.340624411, "Liter"/("Hour"*"Millimole")], 
    rateconst["vhbdpg", True] -> Unit[519612.560391792, 
      "Liter"/("Hour"*"Millimole")], rateconst["vo2", True] -> 
     Unit[509725.707725914, "Hour"^(-1)], metabolite["o2", "Xt"] -> 
     Unit[0.0200788, "Millimole"/"Liter"], Keq["vtki"] -> 3, 
    Keq["vampase"] -> Unit[0.0001, "Millimole"/"Liter"], 
    Keq["vak"] -> 1/1000000, rateconst["vak", True] -> 
     Unit[0.000021668985560234613, "Liter"/("Hour"*"Millimole")], 
    rateconst["vampase", True] -> Unit[0.018219337633055346, "Hour"^(-1)], 
    rateconst["vgshr", True] -> Unit[0.04007858546168957, 
      "Liter"/("Hour"*"Millimole")], rateconst["vdpgase", True] -> 
     Unit[0.14225806451612902, "Hour"^(-1)], rateconst["vampda", True] -> 
     Unit[0.1614239918930086, "Hour"^(-1)], rateconst["vprm", True] -> 
     Unit[0.18447532343076017, "Hour"^(-1)], rateconst["vhk", True] -> 
     Unit[0.7000072543398843, "Liter"/("Hour"*"Millimole")], 
    rateconst["vprppsyn", True] -> Unit[1.107034449764991, 
      "Liter"^2/("Hour"*"Millimole"^2)], rateconst["vgluin", True] -> 
     Unit[1.12, "Hour"^(-1)], rateconst["vatp", True] -> 
     Unit[1.4000000000000001, "Hour"^(-1)], rateconst["vimpase", True] -> 
     Unit[1.4000003500000875, "Hour"^(-1)], rateconst["vlac", True] -> 
     Unit[5.397222222222221, "Hour"^(-1)], rateconst["vada", True] -> 
     Unit[5.833333775694392, "Hour"^(-1)], rateconst["vnadh", True] -> 
     Unit[7.441860465116279, "Hour"^(-1)], rateconst["vpnpase", True] -> 
     Unit[9.428571428571342, "Liter"/("Hour"*"Millimole")], 
    rateconst["vr5pi", True] -> Unit[23.220240609111592, "Hour"^(-1)], 
    rateconst["vtpi", True] -> Unit[32.20858895705523, "Hour"^(-1)], 
    rateconst["vpfk", True] -> Unit[33.158234763561914, 
      "Liter"/("Hour"*"Millimole")], rateconst["vgssgr", True] -> 
     Unit[51.80610296209026, "Liter"/("Hour"*"Millimole")], 
    rateconst["vpglase", True] -> Unit[118.82797417762106, "Hour"^(-1)], 
    rateconst["vpk", True] -> Unit[439.5774513356853, 
      "Liter"/("Hour"*"Millimole")], rateconst["vpyr", True] -> 
     Unit[744.1860465116214, "Hour"^(-1)], rateconst["vtala", True] -> 
     Unit[848.8403902309863, "Liter"/("Hour"*"Millimole")], 
    rateconst["vldh", True] -> Unit[1072.2873312773825, 
      "Liter"/("Hour"*"Millimole")], rateconst["vtkii", True] -> 
     Unit[1097.7081389119153, "Liter"/("Hour"*"Millimole")], 
    rateconst["veno", True] -> Unit[1706.2992125984274, "Hour"^(-1)], 
    rateconst["vdpgm", True] -> Unit[1814.814814814815, "Hour"^(-1)], 
    rateconst["vald", True] -> Unit[2657.4074074074147, "Hour"^(-1)], 
    rateconst["vpgi", True] -> Unit[2980.6349206349587, "Hour"^(-1)], 
    rateconst["vadprt", True] -> Unit[3140.4574868453906, 
      "Liter"/("Hour"*"Millimole")], rateconst["vgapdh", True] -> 
     Unit[3266.7033963380263, "Liter"^2/("Hour"*"Millimole"^2)], 
    rateconst["vtki", True] -> Unit[4519.976149277698, 
      "Liter"/("Hour"*"Millimole")], rateconst["vpglm", True] -> 
     Unit[4710.86956521737, "Hour"^(-1)], rateconst["vr5pe", True] -> 
     Unit[15358.22486427825, "Hour"^(-1)], rateconst["vg6pdh", True] -> 
     Unit[21239.887094978385, "Liter"/("Hour"*"Millimole")], 
    rateconst["vgl6pdh", True] -> Unit[28451.049090193294, 
      "Liter"/("Hour"*"Millimole")], rateconst["vado", True] -> 
     Unit[69999.99999997263, "Hour"^(-1)], rateconst["vhyp", True] -> 
     Unit[78571.42857140768, "Hour"^(-1)], rateconst["vco2", True] -> 
     Unit[97142.85714776731, "Hour"^(-1)], rateconst["vino", True] -> 
     Unit[99999.99999994336, "Hour"^(-1)], rateconst["vade", True] -> 
     Unit[99999.99999997434, "Hour"^(-1)], rateconst["vh", True] -> 
     Unit[127641.36904761894, "Hour"^(-1)], rateconst["vnh3", True] -> 
     Unit[209999.99999396037, "Hour"^(-1)], rateconst["vpgk", True] -> 
     Unit[981301.3265950785, "Liter"/("Hour"*"Millimole")]}}]
