(* Created by Wolfram Mathematica 8.0 : www.wolfram.com *)
MASSmodel[{"Constant" -> {}, "CustomODE" -> {}, "Name" -> "MASSmodel$25", 
  "CustomRateLaws" -> {}, "GPR" -> {"G6PDH2r" -> protein["G6pd.1"], 
    "GND" -> protein["Pgd.1"], "GTHO" -> protein["Gsr.2"], 
    "GTHP" -> protein["Gpx1.1"], "GTHP" -> protein["Gpx1.2"], 
    "GTHP" -> protein["Gpx4.1"], "GTHP" -> protein["Prdx1.1"], 
    "GTHP" -> protein["Prdx1.2"], "GTHP" -> protein["Prdx1.3"], 
    "GTHP" -> protein["Prdx2.1"], "GTHP" -> protein["Prdx2.2"], 
    "GTHP" -> protein["Prdx2.3"], "PGL" -> protein["Pgls.1"], 
    "RPE" -> protein["Rpe.1"], "RPE" -> protein["Rpe.2"], 
    "RPI" -> protein["Rpia.1"], "TALA" -> protein["Taldo1.1"], 
    "TKT1" -> protein["Tkt.1"], "TKT2" -> protein["Tkt.1"]}, 
  "ElementalComposition" -> {metabolite["6pgc", "c"] -> 
     6*"C" + 10*"H" + 10*"O" + "P", metabolite["6pgl", "c"] -> 
     6*"C" + 9*"H" + 9*"O" + "P", metabolite["co2", "c"] -> "C" + 2*"O", 
    metabolite["e4p", "c"] -> 4*"C" + 7*"H" + 7*"O" + "P", 
    metabolite["f6p", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P", 
    metabolite["g3p", "c"] -> 3*"C" + 5*"H" + 6*"O" + "P", 
    metabolite["g6p", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P", 
    metabolite["gthox", "c"] -> 20*"C" + 30*"H" + 6*"N" + 12*"O" + 2*"S", 
    metabolite["gthrd", "c"] -> 10*"C" + 16*"H" + 3*"N" + 6*"O" + "S", 
    metabolite["h", "c"] -> "H", metabolite["h2o", "c"] -> 2*"H" + "O", 
    metabolite["h2o2", "c"] -> 2*"H" + 2*"O", metabolite["nadp", "c"] -> 
     21*"C" + 25*"H" + 7*"N" + 17*"O" + 3*"P", metabolite["nadph", "c"] -> 
     21*"C" + 26*"H" + 7*"N" + 17*"O" + 3*"P", metabolite["r5p", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P", metabolite["ru5p-D", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P", metabolite["s7p", "c"] -> 
     7*"C" + 13*"H" + 10*"O" + "P", metabolite["xu5p-D", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P"}, 
  "ID" -> "iAB-RBC-238-PentosePhosphatePathway", 
  "Stoichiometry" -> SparseArray[Automatic, {18, 17}, 0, 
    {1, {{0, 2, 4, 6, 8, 11, 15, 17, 21, 24, 26, 29, 32, 34, 37, 39, 42, 44, 
      46}, {{2}, {5}, {1}, {5}, {2}, {16}, {8}, {10}, {8}, {10}, {11}, {8}, 
      {9}, {10}, {13}, {3}, {4}, {1}, {3}, {5}, {15}, {4}, {5}, {14}, {4}, 
      {17}, {1}, {2}, {3}, {1}, {2}, {3}, {7}, {9}, {2}, {6}, {7}, {8}, {9}, 
      {6}, {9}, {10}, {1}, {12}, {3}, {4}}}, {-1, 1, 1, -1, 1, -1, 1, -1, 1, 
     1, -1, -1, 1, 1, -1, -1, 1, 1, -1, 1, -1, 2, -1, -1, -1, -1, -1, -1, 1, 
     1, 1, -1, -1, -1, 1, -1, 1, -1, 1, 1, -1, -1, -1, -1, 2, -2}}], 
  "Species" -> {metabolite["6pgc", "c"], metabolite["6pgl", "c"], 
    metabolite["co2", "c"], metabolite["e4p", "c"], metabolite["f6p", "c"], 
    metabolite["g3p", "c"], metabolite["gthox", "c"], metabolite["h", "c"], 
    metabolite["h2o", "c"], metabolite["h2o2", "c"], metabolite["nadp", "c"], 
    metabolite["nadph", "c"], metabolite["r5p", "c"], 
    metabolite["ru5p-D", "c"], metabolite["s7p", "c"], 
    metabolite["xu5p-D", "c"], metabolite["g6p", "c"], 
    metabolite["gthrd", "c"]}, "Fluxes" -> {"G6PDH2r", "GND", "GTHO", "GTHP", 
    "PGL", "RPE", "RPI", "TALA", "TKT1", "TKT2", "Sink_f6p_c", "Sink_g6p_c", 
    "Sink_g3p_c", "Sink_h2o_c", "Sink_h_c", "Sink_co2_c", "Sink_h2o2_c"}, 
  "ReversibleColumnIndices" -> {1, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 
    17}, "Constraints" -> {"G6PDH2r" -> {-1000., 1000.}, 
    "GND" -> {0., 1000.}, "GTHO" -> {0., 1000.}, "GTHP" -> {0., 1000.}, 
    "PGL" -> {0., 1000.}, "RPE" -> {-1000., 1000.}, "RPI" -> {-1000., 1000.}, 
    "TALA" -> {-1000., 1000.}, "TKT1" -> {-1000., 1000.}, 
    "TKT2" -> {-1000., 1000.}, "Sink_f6p_c" -> {0, Infinity}, 
    "Sink_g6p_c" -> {0, Infinity}, "Sink_g3p_c" -> {0, Infinity}, 
    "Sink_h2o_c" -> {0, Infinity}, "Sink_h_c" -> {0, Infinity}, 
    "Sink_co2_c" -> {0, Infinity}, "Sink_h2o2_c" -> {0, Infinity}}, 
  "InitialConditions" -> {metabolite["g6p", "c"] -> 0.0486, 
    metabolite["f6p", "c"] -> 0.0198, metabolite["g3p", "c"] -> 0.00728, 
    metabolite["6pgl", "c"] -> 0.001754242723, metabolite["6pgc", "c"] -> 
     0.037475258, metabolite["ru5p-D", "c"] -> 0.0049367903, 
    metabolite["xu5p-D", "c"] -> 0.014784196, metabolite["r5p", "c"] -> 
     0.00494, metabolite["s7p", "c"] -> 0.023987984, 
    metabolite["e4p", "c"] -> 0.0050750696, metabolite["nadp", "c"] -> 
     0.0002, metabolite["nadph", "c"] -> 0.0658, metabolite["gthrd", "c"] -> 
     3.2, metabolite["gthox", "c"] -> 0.11999999999999966, 
    metabolite["h", "c"] -> 0.00009929240111468596, 
    metabolite["h2o2", "c"] -> 0.00001, metabolite["h2o", "c"] -> 0.99999683, 
    metabolite["co2", "c"] -> 1.0000021, "G6PDH2r" -> 0.21, "PGL" -> 0.21, 
    "GND" -> 0.21, "RPE" -> 0.14, "RPI" -> -0.06999999999999999, 
    "TKT1" -> 0.06999999999999999, "TKT2" -> 0.07, 
    "TALA" -> 0.06999999999999999, "GTHO" -> 0.42, "GTHP" -> 0.42, 
    "GSHR" -> 0.42, "vgshr" -> 0.42, "Sink_g6p_c" -> -0.21, 
    "Sink_f6p_c" -> 0.14, "Sink_h_c" -> 0, "Sink_h2o_c" -> 0.63, 
    "Sink_h2o2_c" -> -0.42, "Sink_co2_c" -> 0.21, "Sink_g3p_c" -> 0.07}, 
  "Parameters" -> {parameter["Volume", "c"] -> 1, Keq["Sink_h_c"] -> 1, 
    Keq["Sink_h2o_c"] -> 1, Keq["Sink_g6p_c"] -> 1, Keq["Sink_g3p_c"] -> 1, 
    Keq["Sink_h2o2_c"] -> 1, Keq["Sink_co2_c"] -> 1, Keq["Sink_f6p_c"] -> 1, 
    Keq["G6PDH2r"] -> 1000, Keq["PGL"] -> 1000, Keq["GND"] -> 1000, 
    Keq["RPE"] -> 3, Keq["RPI"] -> 0.38910505836575876, Keq["TKT1"] -> 3, 
    Keq["TKT2"] -> 10.3, Keq["TALA"] -> 1.05, Keq["GTHO"] -> 100, 
    Keq["GTHP"] -> Infinity, metabolite[_, "Xt"] -> 1}, 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "BoundaryConditions" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "Notes" -> "\nModel constructed on Mon 13 Aug 2012 15:37:13 by niko on \
staphylococcus.ucsd.edu using Mathematica 8.0 for Mac OS X x86 (64-bit) \
(November 6, 2010) at the following geodetic location: latitude 32.88; \
longitude -117.24\n This model is a translation of the pentose phosphate \
pathway model in 'Simulation of dynamic network state' in terms of the \
iAB-RBC-238 reconstruction by Aarash Bordbard."}]
