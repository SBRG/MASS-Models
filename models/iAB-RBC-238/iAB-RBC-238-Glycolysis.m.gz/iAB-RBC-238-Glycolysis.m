(* Created by Wolfram Mathematica 8.0 : www.wolfram.com *)
MASSmodel[{"Constant" -> {}, "CustomODE" -> {}, "UnitChecking" -> True, 
  "Name" -> "MASSmodel$148", "CustomRateLaws" -> {}, 
  "GPR" -> {"ADK1" -> protein["Ak1.1"], "ENO" -> protein["Eno1.1"], 
    "FBA" -> protein["Aldoa.1"], "FBA" -> protein["Aldoa.2"], 
    "FBA" -> protein["Aldoa.3"], "FBA" -> protein["Aldoc.1"], 
    "GAPD" -> protein["Gapdh.1"], "HEX1" -> protein["Flj22761.1"], 
    "HEX1" -> protein["Hk1.1"], "HEX1" -> protein["Hk1.2"], 
    "HEX1" -> protein["Hk1.3"], "HEX1" -> protein["Hk1.4"], 
    "HEX1" -> protein["Hk1.5"], "HEX1" -> protein["Hk2.1"], 
    "HEX1" -> protein["Hk3.1"], "LDH_L" -> protein["Ldha.1"], 
    "LDH_L" -> protein["Ldhb.1"], "PFK" -> protein["Pfkl.1"], 
    "PFK" -> protein["Pfkl.2"], "PFK" -> protein["Pfkm.1"], 
    "PGI" -> protein["Gpi.1"], "PGK" -> protein["Pgk1.1"], 
    "PGM" -> protein["Bpgm.1"], "PGM" -> protein["Bpgm.2"], 
    "PYK" -> protein["Pklr.1"], "PYK" -> protein["Pklr.2"], 
    "PYK" -> protein["Pkm2.1"], "PYK" -> protein["Pkm2.2"], 
    "PYK" -> protein["Pkm2.3"], "TPI" -> protein["Tpi1.1"]}, 
  "ElementalComposition" -> {metabolite["13dpg", "c"] -> 
     3*"C" + 4*"H" + 10*"O" + 2*"P", metabolite["2pg", "c"] -> 
     3*"C" + 4*"H" + 7*"O" + "P", metabolite["3pg", "c"] -> 
     3*"C" + 4*"H" + 7*"O" + "P", metabolite["adp", "c"] -> 
     10*"C" + 12*"H" + 5*"N" + 10*"O" + 2*"P", metabolite["amp", "c"] -> 
     10*"C" + 12*"H" + 5*"N" + 7*"O" + "P", metabolite["atp", "c"] -> 
     10*"C" + 12*"H" + 5*"N" + 13*"O" + 3*"P", metabolite["dhap", "c"] -> 
     3*"C" + 5*"H" + 6*"O" + "P", metabolite["f6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P", metabolite["fdp", "c"] -> 
     6*"C" + 10*"H" + 12*"O" + 2*"P", metabolite["g3p", "c"] -> 
     3*"C" + 5*"H" + 6*"O" + "P", metabolite["g6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P", metabolite["glc-D", "c"] -> 
     6*"C" + 12*"H" + 6*"O", metabolite["h", "c"] -> "H", 
    metabolite["h2o", "c"] -> 2*"H" + "O", metabolite["lac-L", "c"] -> 
     3*"C" + 5*"H" + 3*"O", metabolite["nad", "c"] -> 
     21*"C" + 26*"H" + 7*"N" + 14*"O" + 2*"P", metabolite["nadh", "c"] -> 
     21*"C" + 27*"H" + 7*"N" + 14*"O" + 2*"P", metabolite["pep", "c"] -> 
     3*"C" + 2*"H" + 6*"O" + "P", metabolite["pi", "c"] -> "H" + 4*"O" + "P", 
    metabolite["pyr", "c"] -> 3*"C" + 3*"H" + 3*"O"}, 
  "ID" -> "iAB-RBC-238-Glycolysis", 
  "Ignore" -> {metabolite["h", _], metabolite["h2o", _]}, 
  "Constraints" -> {v["ADK1"] -> {-1000., 1000.}, 
    v["ENO"] -> {-1000., 1000.}, v["FBA"] -> {-1000., 1000.}, 
    v["GAPD"] -> {-1000., 1000.}, v["HEX1"] -> {0., 1000.}, 
    v["LDH_L"] -> {-1000., 1000.}, v["PFK"] -> {0., 1000.}, 
    v["PGI"] -> {-1000., 1000.}, v["PGK"] -> {-1000., 1000.}, 
    v["PGM"] -> {-1000., 1000.}, v["PYK"] -> {0., 1000.}, 
    v["TPI"] -> {-1000., 1000.}, v["Sink_pyr_c"] -> {0, Infinity}, 
    v["Sink_lac-L_c"] -> {0, Infinity}, v["Sink_glc-D_c"] -> {0, Infinity}, 
    v["Sink_h_c"] -> {0, Infinity}, v["Sink_h2o_c"] -> {0, Infinity}}, 
  "Stoichiometry" -> SparseArray[Automatic, {20, 19}, 0, 
    {1, {{0, 2, 4, 6, 12, 13, 15, 17, 19, 22, 24, 32, 35, 37, 40, 43, 45, 47, 
      50, 56, 58}, {{4}, {9}, {2}, {10}, {9}, {10}, {1}, {5}, {7}, {9}, {11}, 
      {18}, {1}, {3}, {12}, {7}, {8}, {3}, {7}, {3}, {4}, {12}, {5}, {8}, 
      {4}, {5}, {6}, {7}, {11}, {16}, {18}, {19}, {2}, {17}, {18}, {6}, {14}, 
      {4}, {6}, {19}, {4}, {6}, {19}, {2}, {11}, {4}, {18}, {6}, {11}, {13}, 
      {1}, {5}, {7}, {9}, {11}, {18}, {5}, {15}}}, {1, 1, -1, -1, -1, 1, 2, 
     1, 1, 1, -1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1, -1, 1, 1, 1, 1, 
     -1, -1, 1, 1, 1, -1, -1, -1, -1, -1, -1, 1, 1, 1, -1, 1, -1, -1, 1, 1, 
     1, -1, -1, -1, -1, -1, 1, -1, -1, -1}}], 
  "Species" -> {metabolite["13dpg", "c"], metabolite["2pg", "c"], 
    metabolite["3pg", "c"], metabolite["adp", "c"], metabolite["amp", "c"], 
    metabolite["dhap", "c"], metabolite["f6p", "c"], metabolite["fdp", "c"], 
    metabolite["g3p", "c"], metabolite["g6p", "c"], metabolite["h", "c"], 
    metabolite["h2o", "c"], metabolite["lac-L", "c"], metabolite["nad", "c"], 
    metabolite["nadh", "c"], metabolite["pep", "c"], metabolite["pi", "c"], 
    metabolite["pyr", "c"], metabolite["atp", "c"], 
    metabolite["glc-D", "c"]}, "Fluxes" -> {v["ADK1"], v["ENO"], v["FBA"], 
    v["GAPD"], v["HEX1"], v["LDH_L"], v["PFK"], v["PGI"], v["PGK"], v["PGM"], 
    v["PYK"], v["TPI"], v["Sink_pyr_c"], v["Sink_lac-L_c"], 
    v["Sink_glc-D_c"], v["Sink_h_c"], v["Sink_h2o_c"], v["ATP_hydrolysis"], 
    v["NADH_oxidation"]}, "ReversibleColumnIndices" -> 
   {1, 2, 3, 4, 6, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18, 19}, 
  "InitialConditions" -> {metabolite["glc-D", "c"] -> (0.001*Mole)/Liter, 
    metabolite["g6p", "c"] -> (0.000048599999999999995*Mole)/Liter, 
    metabolite["f6p", "c"] -> (0.000019800000000000004*Mole)/Liter, 
    metabolite["fdp", "c"] -> (0.0000146*Mole)/Liter, 
    metabolite["dhap", "c"] -> (0.00016*Mole)/Liter, 
    metabolite["g3p", "c"] -> (7.28*^-6*Mole)/Liter, 
    metabolite["13dpg", "c"] -> (2.43*^-7*Mole)/Liter, 
    metabolite["3pg", "c"] -> (0.0000773*Mole)/Liter, 
    metabolite["2pg", "c"] -> (0.0000113*Mole)/Liter, 
    metabolite["pep", "c"] -> (0.000017000000000000003*Mole)/Liter, 
    metabolite["pyr", "c"] -> (0.000060301000000000004*Mole)/Liter, 
    metabolite["lac-L", "c"] -> (0.00136*Mole)/Liter, 
    metabolite["nad", "c"] -> (0.0000589*Mole)/Liter, 
    metabolite["nadh", "c"] -> (0.0000301*Mole)/Liter, 
    metabolite["amp", "c"] -> (0.00008672812499999999*Mole)/Liter, 
    metabolite["adp", "c"] -> (0.00029*Mole)/Liter, 
    metabolite["atp", "c"] -> (0.0016*Mole)/Liter, 
    metabolite["pi", "c"] -> (0.0025*Mole)/Liter, metabolite["h", "c"] -> 
     (8.99757344480193*^-8*Mole)/Liter, metabolite["h2o", "c"] -> 
     (0.001*Mole)/Liter, v["HEX1"] -> (0.0011200000000000001*Mole)/
      (Hour*Liter), v["PGI"] -> (0.0011200000000000001*Mole)/(Hour*Liter), 
    v["PFK"] -> (0.0011200000000000001*Mole)/(Hour*Liter), 
    v["TPI"] -> (0.0011200000000000001*Mole)/(Hour*Liter), 
    v["FBA"] -> (0.0011200000000000001*Mole)/(Hour*Liter), 
    v["GAPD"] -> (0.0022400000000000002*Mole)/(Hour*Liter), 
    v["PGK"] -> (-0.0022400000000000002*Mole)/(Hour*Liter), 
    v["PGM"] -> (-0.0022400000000000002*Mole)/(Hour*Liter), 
    v["ENO"] -> (0.0022400000000000002*Mole)/(Hour*Liter), 
    v["PYK"] -> (0.0022400000000000002*Mole)/(Hour*Liter), 
    v["LDH_L"] -> (-0.002016*Mole)/(Hour*Liter), v["ADK1"] -> 0., 
    v["Sink_pyr_c"] -> (0.00022400000000000002*Mole)/(Hour*Liter), 
    v["Sink_lac-L_c"] -> (0.002016*Mole)/(Hour*Liter), 
    v["ATP_hydrolysis"] -> (0.0022400000000000002*Mole)/(Hour*Liter), 
    v["NADH_oxidation"] -> (0.00022400000000000002*Mole)/(Hour*Liter), 
    v["Sink_glc-D_c"] -> (-0.0011200000000000001*Mole)/(Hour*Liter), 
    v["Sink_h_c"] -> (0.0026880000000000003*Mole)/(Hour*Liter), 
    v["Sink_h2o_c"] -> 0.}, "BoundaryConditions" -> 
   {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "Parameters" -> {parameter["Volume", "c"] -> Liter, Keq["HEX1"] -> 850, 
    Keq["PGI"] -> 0.41, Keq["PFK"] -> 310, Keq["TPI"] -> 0.05714285714285714, 
    Keq["FBA"] -> (0.000082*Mole)/Liter, Keq["GAPD"] -> (17.9*Liter)/Mole, 
    Keq["PGK"] -> 1/1800, Keq["PGM"] -> 6.8, 
    Keq["ENO"] -> 1.6949152542372883, Keq["PYK"] -> 363000, 
    Keq["LDH_L"] -> 1/26300, Keq["ADK1"] -> 0.6060606060606061, 
    Keq["Sink_pyr_c"] -> 1., Keq["Sink_lac-L_c"] -> 1., 
    Keq["ATP_hydrolysis"] -> (Mole*Infinity)/Liter, 
    Keq["NADH_oxidation"] -> Infinity, Keq["Sink_glc-D_c"] -> 0, 
    Keq["Sink_h_c"] -> 1., Keq["Sink_h2o_c"] -> 1., 
    metabolite["pyr", "Xt"] -> (0.00006*Mole)/Liter, 
    metabolite["amp", "Xt"] -> Mole/(1000*Liter), metabolite["h", "Xt"] -> 
     (6.30957344480193*^-8*Mole)/Liter, metabolite[_, "Xt"] -> 
     Mole/(1000*Liter), rateconst["ADK1", True] -> (1000*Liter)/(Hour*Mole), 
    rateconst["ENO", True] -> 1763.7795275590581/Hour, 
    rateconst["FBA", True] -> 2834.567901234567/Hour, 
    rateconst["GAPD", True] -> (3.3767492421768246*^9*Liter^2)/(Hour*Mole^2), 
    rateconst["HEX1", True] -> (700.0000000000001*Liter)/(Hour*Mole), 
    rateconst["LDH_L", True] -> (42.30319348299546*Liter)/(Hour*Mole), 
    rateconst["PFK", True] -> (35353.53535353535*Liter)/(Hour*Mole), 
    rateconst["PGI", True] -> 3644.44444444458/Hour, 
    rateconst["PGK", True] -> (707517.3720783346*Liter)/(Hour*Mole), 
    rateconst["PGM", True] -> 33113.04347826114/Hour, 
    rateconst["PYK", True] -> (454361.05476673425*Liter)/(Hour*Mole), 
    rateconst["TPI", True] -> 34.355828220858896/Hour, 
    rateconst["Sink_pyr_c", True] -> 744.1860465116213/Hour, 
    rateconst["Sink_lac-L_c", True] -> 5.599999999999999/Hour, 
    rateconst["Sink_glc-D_c", False] -> 1.12/Hour, 
    rateconst["Sink_h_c", True] -> -42601.929013354755/Hour, 
    rateconst["Sink_h2o_c", True] -> Hour^(-1), 
    rateconst["ATP_hydrolysis", True] -> 1.4000000000000001/Hour, 
    rateconst["NADH_oxidation", True] -> 7.44186046511628/Hour}, 
  "Notes" -> "\nModel constructed on Tue 28 Aug 2012 15:15:33 by niko on \
staphylococcus.ucsd.edu using Mathematica 8.0 for Mac OS X x86 (64-bit) \
(November 6, 2010) at the following geodetic location: latitude 32.88; \
longitude -117.24\n This model is a translation of the glycolysis model in \
'Simulation of dynamic network state' in terms of the iAB-RBC-238 \
reconstruction by Aarash Bordbard."}]
