(* Created by Wolfram Mathematica 9.0 : www.wolfram.com *)
MASSmodel[{"CustomODE" -> {}, "Synonyms" -> {}, "Events" -> {}, 
  "Name" -> "MASSmodel$8", "CustomRateLaws" -> {}, 
  "GPR" -> {"ADK1" -> protein["Ak1.1", None], 
    "ENO" -> protein["Eno1.1", None], "FBA" -> protein["Aldoa.1", None], 
    "FBA" -> protein["Aldoa.2", None], "FBA" -> protein["Aldoa.3", None], 
    "FBA" -> protein["Aldoc.1", None], "GAPD" -> protein["Gapdh.1", None], 
    "HEX1" -> protein["Flj22761.1", None], "HEX1" -> protein["Hk1.1", None], 
    "HEX1" -> protein["Hk1.2", None], "HEX1" -> protein["Hk1.3", None], 
    "HEX1" -> protein["Hk1.4", None], "HEX1" -> protein["Hk1.5", None], 
    "HEX1" -> protein["Hk2.1", None], "HEX1" -> protein["Hk3.1", None], 
    "LDH_L" -> protein["Ldha.1", None], "LDH_L" -> protein["Ldhb.1", None], 
    "PFK" -> protein["Pfkl.1", None], "PFK" -> protein["Pfkl.2", None], 
    "PFK" -> protein["Pfkm.1", None], "PGI" -> protein["Gpi.1", None], 
    "PGK" -> protein["Pgk1.1", None], "PGM" -> protein["Bpgm.1", None], 
    "PGM" -> protein["Bpgm.2", None], "PYK" -> protein["Pklr.1", None], 
    "PYK" -> protein["Pklr.2", None], "PYK" -> protein["Pkm2.1", None], 
    "PYK" -> protein["Pkm2.2", None], "PYK" -> protein["Pkm2.3", None], 
    "TPI" -> protein["Tpi1.1", None]}, "ElementalComposition" -> 
   {metabolite["13dpg", "c"] -> 3*"C" + 4*"H" + 10*"O" + 2*"P", 
    metabolite["2pg", "c"] -> 3*"C" + 4*"H" + 7*"O" + "P", 
    metabolite["3pg", "c"] -> 3*"C" + 4*"H" + 7*"O" + "P", 
    metabolite["adp", "c"] -> 10*"C" + 12*"H" + 5*"N" + 10*"O" + 2*"P", 
    metabolite["amp", "c"] -> 10*"C" + 12*"H" + 5*"N" + 7*"O" + "P", 
    metabolite["atp", "c"] -> 10*"C" + 12*"H" + 5*"N" + 13*"O" + 3*"P", 
    metabolite["dhap", "c"] -> 3*"C" + 5*"H" + 6*"O" + "P", 
    metabolite["f6p", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P", 
    metabolite["fdp", "c"] -> 6*"C" + 10*"H" + 12*"O" + 2*"P", 
    metabolite["g3p", "c"] -> 3*"C" + 5*"H" + 6*"O" + "P", 
    metabolite["g6p", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P", 
    metabolite["glc-D", "c"] -> 6*"C" + 12*"H" + 6*"O", 
    metabolite["h", "c"] -> "H", metabolite["h2o", "c"] -> 2*"H" + "O", 
    metabolite["lac-L", "c"] -> 3*"C" + 5*"H" + 3*"O", 
    metabolite["nad", "c"] -> 21*"C" + 26*"H" + 7*"N" + 14*"O" + 2*"P", 
    metabolite["nadh", "c"] -> 21*"C" + 27*"H" + 7*"N" + 14*"O" + 2*"P", 
    metabolite["pep", "c"] -> 3*"C" + 2*"H" + 6*"O" + "P", 
    metabolite["pi", "c"] -> "H" + 4*"O" + "P", metabolite["pyr", "c"] -> 
     3*"C" + 3*"H" + 3*"O"}, "BoundaryConditions" -> {}, "Constant" -> {}, 
  "UnitChecking" -> True, "ID" -> "iAB-RBC-238-Glycolysis", 
  "Ignore" -> {metabolite["h", _], metabolite["h2o", _]}, 
  "Constraints" -> {v["ADK1"] -> {-1000., 1000.}, 
    v["ENO"] -> {-1000., 1000.}, v["FBA"] -> {-1000., 1000.}, 
    v["GAPD"] -> {-1000., 1000.}, v["HEX1"] -> {0., 1000.}, 
    v["LDH_L"] -> {-1000., 1000.}, v["PFK"] -> {0., 1000.}, 
    v["PGI"] -> {-1000., 1000.}, v["PGK"] -> {-1000., 1000.}, 
    v["PGM"] -> {-1000., 1000.}, v["PYK"] -> {0., 1000.}, 
    v["TPI"] -> {-1000., 1000.}, v["Sink_pyr[c]"] -> {0, Infinity}, 
    v["Sink_lac-L[c]"] -> {0, Infinity}, v["Sink_glc-D[c]"] -> {0, Infinity}, 
    v["Sink_h[c]"] -> {0, Infinity}, v["Sink_h2o[c]"] -> {0, Infinity}}, 
  "Stoichiometry" -> SparseArray[Automatic, {20, 19}, 0, 
    {1, {{0, 2, 4, 6, 12, 13, 15, 17, 19, 22, 24, 32, 35, 37, 40, 43, 45, 47, 
      50, 56, 58}, {{4}, {9}, {2}, {10}, {9}, {10}, {1}, {5}, {7}, {9}, {11}, 
      {18}, {1}, {3}, {12}, {7}, {8}, {3}, {7}, {3}, {4}, {12}, {5}, {8}, 
      {4}, {5}, {6}, {7}, {11}, {16}, {18}, {19}, {2}, {17}, {18}, {6}, {14}, 
      {4}, {6}, {19}, {4}, {6}, {19}, {2}, {11}, {4}, {18}, {6}, {11}, {13}, 
      {1}, {5}, {7}, {9}, {11}, {18}, {5}, {15}}}, {1, 1, -1, -1, -1, 1, 2, 
     1, 1, 1, -1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1, -1, 1, 1, 1, 1, 
     -1, -1, 1, 1, 1, -1, -1, -1, -1, -1, -1, 1, 1, 1, -1, 1, -1, -1, 1, 1, 
     1, -1, -1, -1, -1, -1, 1, -1, -1, -1}}], 
  "Species" -> {metabolite["13dpg", "c"], metabolite["2pg", "c"], 
    metabolite["3pg", "c"], metabolite["adp", "c"], metabolite["amp", "c"], 
    metabolite["dhap", "c"], metabolite["f6p", "c"], metabolite["fdp", "c"], 
    metabolite["g3p", "c"], metabolite["g6p", "c"], metabolite["h", "c"], 
    metabolite["h2o", "c"], metabolite["lac-L", "c"], metabolite["nad", "c"], 
    metabolite["nadh", "c"], metabolite["pep", "c"], metabolite["pi", "c"], 
    metabolite["pyr", "c"], metabolite["atp", "c"], 
    metabolite["glc-D", "c"]}, "Fluxes" -> {v["ADK1"], v["ENO"], v["FBA"], 
    v["GAPD"], v["HEX1"], v["LDH_L"], v["PFK"], v["PGI"], v["PGK"], v["PGM"], 
    v["PYK"], v["TPI"], v["Sink_pyr[c]"], v["Sink_lac-L[c]"], 
    v["Sink_glc-D[c]"], v["Sink_h[c]"], v["Sink_h2o[c]"], 
    v["ATP_hydrolysis"], v["NADH_oxidation"]}, "ReversibleColumnIndices" -> 
   {1, 2, 3, 4, 6, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18, 19}, 
  "InitialConditions" -> {metabolite["glc-D", "c"] -> 
     Unit[1., "Millimole"/"Liter"], metabolite["g6p", "c"] -> 
     Unit[0.0486, "Millimole"/"Liter"], metabolite["f6p", "c"] -> 
     Unit[0.0198, "Millimole"/"Liter"], metabolite["fdp", "c"] -> 
     Unit[0.0146, "Millimole"/"Liter"], metabolite["dhap", "c"] -> 
     Unit[0.16, "Millimole"/"Liter"], metabolite["g3p", "c"] -> 
     Unit[0.00728, "Millimole"/"Liter"], metabolite["13dpg", "c"] -> 
     Unit[0.000243, "Millimole"/"Liter"], metabolite["3pg", "c"] -> 
     Unit[0.0773, "Millimole"/"Liter"], metabolite["2pg", "c"] -> 
     Unit[0.0113, "Millimole"/"Liter"], metabolite["pep", "c"] -> 
     Unit[0.017, "Millimole"/"Liter"], metabolite["pyr", "c"] -> 
     Unit[0.060301, "Millimole"/"Liter"], metabolite["lac-L", "c"] -> 
     Unit[1.36, "Millimole"/"Liter"], metabolite["nad", "c"] -> 
     Unit[0.0589, "Millimole"/"Liter"], metabolite["nadh", "c"] -> 
     Unit[0.0301, "Millimole"/"Liter"], metabolite["amp", "c"] -> 
     Unit[0.08672812499999999, "Millimole"/"Liter"], 
    metabolite["adp", "c"] -> Unit[0.29, "Millimole"/"Liter"], 
    metabolite["atp", "c"] -> Unit[1.6, "Millimole"/"Liter"], 
    metabolite["pi", "c"] -> Unit[2.5, "Millimole"/"Liter"], 
    metabolite["h", "c"] -> Unit[0.00008997573444801929, 
      "Millimole"/"Liter"], metabolite["h2o", "c"] -> 
     Unit[1., "Millimole"/"Liter"], v["HEX1"] -> 
     Unit[1.12, "Millimole"/("Hour"*"Liter")], 
    v["PGI"] -> Unit[1.12, "Millimole"/("Hour"*"Liter")], 
    v["PFK"] -> Unit[1.12, "Millimole"/("Hour"*"Liter")], 
    v["TPI"] -> Unit[1.12, "Millimole"/("Hour"*"Liter")], 
    v["FBA"] -> Unit[1.12, "Millimole"/("Hour"*"Liter")], 
    v["GAPD"] -> Unit[2.24, "Millimole"/("Hour"*"Liter")], 
    v["PGK"] -> Unit[-2.24, "Millimole"/("Hour"*"Liter")], 
    v["PGM"] -> Unit[-2.24, "Millimole"/("Hour"*"Liter")], 
    v["ENO"] -> Unit[2.24, "Millimole"/("Hour"*"Liter")], 
    v["PYK"] -> Unit[2.24, "Millimole"/("Hour"*"Liter")], 
    v["LDH_L"] -> Unit[-2.016, "Millimole"/("Hour"*"Liter")], 
    v["ADK1"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["Sink_pyr[c]"] -> Unit[0.22400000000000003, 
      "Millimole"/("Hour"*"Liter")], v["Sink_lac-L[c]"] -> 
     Unit[2.016, "Millimole"/("Hour"*"Liter")], v["ATP_hydrolysis"] -> 
     Unit[2.24, "Millimole"/("Hour"*"Liter")], v["NADH_oxidation"] -> 
     Unit[0.22400000000000003, "Millimole"/("Hour"*"Liter")], 
    v["Sink_glc-D[c]"] -> Unit[-1.12, "Millimole"/("Hour"*"Liter")], 
    v["Sink_h[c]"] -> Unit[2.688, "Millimole"/("Hour"*"Liter")], 
    v["Sink_h2o[c]"] -> Unit[0., "Millimole"/("Hour"*"Liter")]}, 
  "Parameters" -> {parameter["Volume", "c"] -> Unit[1, "Liter"], 
    Keq["HEX1"] -> 850, Keq["PGI"] -> 0.41, Keq["PFK"] -> 310, 
    Keq["TPI"] -> 0.05714285714285714, Keq["FBA"] -> 
     Unit[0.082, "Millimole"/"Liter"], Keq["GAPD"] -> 
     Unit[0.0179, "Liter"/"Millimole"], Keq["PGK"] -> 1/1800, 
    Keq["PGM"] -> 6.8, Keq["ENO"] -> 1.6949152542372883, 
    Keq["PYK"] -> 363000, Keq["LDH_L"] -> 1/26300, 
    Keq["ADK1"] -> 0.6060606060606061, Keq["Sink_pyr[c]"] -> 1., 
    Keq["Sink_lac-L[c]"] -> 1., Keq["ATP_hydrolysis"] -> 
     Unit[Infinity, "Millimole"/"Liter"], Keq["NADH_oxidation"] -> Infinity, 
    Keq["Sink_glc-D[c]"] -> 0, Keq["Sink_h[c]"] -> 1., 
    Keq["Sink_h2o[c]"] -> 1., metabolite["pyr", "Xt"] -> 
     Unit[0.06, "Millimole"/"Liter"], metabolite["amp", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["h", "Xt"] -> 
     Unit[0.00006309573444801929, "Millimole"/"Liter"], 
    rateconst["ADK1", True] -> Unit[1, "Liter"/("Hour"*"Millimole")], 
    rateconst["ENO", True] -> Unit[1763.7795275590574, "Hour"^(-1)], 
    rateconst["FBA", True] -> Unit[2834.567901234576, "Hour"^(-1)], 
    rateconst["GAPD", True] -> Unit[3376.7492421768247, 
      "Liter"^2/("Hour"*"Millimole"^2)], rateconst["HEX1", True] -> 
     Unit[0.7000000000000001, "Liter"/("Hour"*"Millimole")], 
    rateconst["LDH_L", True] -> Unit[0.042303193482995466, 
      "Liter"/("Hour"*"Millimole")], rateconst["PFK", True] -> 
     Unit[35.35353535353535, "Liter"/("Hour"*"Millimole")], 
    rateconst["PGI", True] -> Unit[3644.444444444491, "Hour"^(-1)], 
    rateconst["PGK", True] -> Unit[707.5173720783349, 
      "Liter"/("Hour"*"Millimole")], rateconst["PGM", True] -> 
     Unit[33113.043478260624, "Hour"^(-1)], rateconst["PYK", True] -> 
     Unit[454.3610547667343, "Liter"/("Hour"*"Millimole")], 
    rateconst["TPI", True] -> Unit[34.35582822085891, "Hour"^(-1)], 
    rateconst["Sink_pyr[c]", True] -> Unit[744.1860465116215, "Hour"^(-1)], 
    rateconst["Sink_lac-L[c]", True] -> Unit[5.599999999999999, "Hour"^(-1)], 
    rateconst["Sink_glc-D[c]", False] -> Unit[1.12, "Hour"^(-1)], 
    rateconst["Sink_h[c]", True] -> Unit[100000.00000000001, "Hour"^(-1)], 
    rateconst["Sink_h2o[c]", True] -> Unit[1, "Hour"^(-1)], 
    rateconst["ATP_hydrolysis", True] -> Unit[1.4000000000000001, 
      "Hour"^(-1)], rateconst["NADH_oxidation", True] -> 
     Unit[7.44186046511628, "Hour"^(-1)], metabolite[_, "Xt"] -> 
     Unit[1, "Millimole"/"Liter"]}, "Notes" -> "\nModel constructed on Tue 22 \
Jan 2013 17:13:29 by niko on staphylococcus.ucsd.edu using Mathematica 9.0 \
for Mac OS X x86 (64-bit) (November 20, 2012) at the following geodetic \
location: latitude 32.88; longitude -117.24\n This model is a translation of \
the glycolysis model in 'Simulation of dynamic network state' in terms of the \
iAB-RBC-238 reconstruction by Aarash Bordbard."}]
