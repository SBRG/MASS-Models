(* Created by Wolfram Mathematica 8.0 : www.wolfram.com *)
MASSmodel[{"Constant" -> {}, "CustomODE" -> {}, "UnitChecking" -> True, 
  "Name" -> "MASSmodel$148", "CustomRateLaws" -> {}, 
  "GPR" -> {"G6PDH2r" -> protein["G6pd.1"], "GND" -> protein["Pgd.1"], 
    "GTHO" -> protein["Gsr.2"], "GTHP" -> protein["Gpx1.1"], 
    "GTHP" -> protein["Gpx1.2"], "GTHP" -> protein["Gpx4.1"], 
    "GTHP" -> protein["Prdx1.1"], "GTHP" -> protein["Prdx1.2"], 
    "GTHP" -> protein["Prdx1.3"], "GTHP" -> protein["Prdx2.1"], 
    "GTHP" -> protein["Prdx2.2"], "GTHP" -> protein["Prdx2.3"], 
    "PGL" -> protein["Pgls.1"], "RPE" -> protein["Rpe.1"], 
    "RPE" -> protein["Rpe.2"], "RPI" -> protein["Rpia.1"], 
    "TALA" -> protein["Taldo1.1"], "TKT1" -> protein["Tkt.1"], 
    "TKT2" -> protein["Tkt.1"]}, "ElementalComposition" -> 
   {metabolite["6pgc", "c"] -> 6*"C" + 10*"H" + 10*"O" + "P", 
    metabolite["6pgl", "c"] -> 6*"C" + 9*"H" + 9*"O" + "P", 
    metabolite["co2", "c"] -> "C" + 2*"O", metabolite["e4p", "c"] -> 
     4*"C" + 7*"H" + 7*"O" + "P", metabolite["f6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P", metabolite["g3p", "c"] -> 
     3*"C" + 5*"H" + 6*"O" + "P", metabolite["g6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P", metabolite["gthox", "c"] -> 
     20*"C" + 30*"H" + 6*"N" + 12*"O" + 2*"S", metabolite["gthrd", "c"] -> 
     10*"C" + 16*"H" + 3*"N" + 6*"O" + "S", metabolite["h", "c"] -> "H", 
    metabolite["h2o", "c"] -> 2*"H" + "O", metabolite["h2o2", "c"] -> 
     2*"H" + 2*"O", metabolite["nadp", "c"] -> 21*"C" + 25*"H" + 7*"N" + 
      17*"O" + 3*"P", metabolite["nadph", "c"] -> 21*"C" + 26*"H" + 7*"N" + 
      17*"O" + 3*"P", metabolite["r5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["ru5p-D", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["s7p", "c"] -> 7*"C" + 13*"H" + 10*"O" + "P", 
    metabolite["xu5p-D", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P"}, 
  "Ignore" -> {metabolite["h", _], metabolite["h2o", _]}, 
  "ID" -> "iAB-RBC-238-PentosePhosphatePathway", 
  "Stoichiometry" -> SparseArray[Automatic, {18, 17}, 0, 
    {1, {{0, 2, 4, 6, 8, 11, 15, 17, 21, 24, 26, 29, 32, 34, 37, 39, 42, 44, 
      46}, {{2}, {5}, {1}, {5}, {2}, {16}, {8}, {10}, {8}, {10}, {11}, {8}, 
      {9}, {10}, {13}, {3}, {4}, {1}, {3}, {5}, {15}, {4}, {5}, {14}, {4}, 
      {17}, {1}, {2}, {3}, {1}, {2}, {3}, {7}, {9}, {2}, {6}, {7}, {8}, {9}, 
      {6}, {9}, {10}, {1}, {12}, {3}, {4}}}, {-1, 1, 1, -1, 1, -1, 1, -1, 1, 
     1, -1, -1, 1, 1, -1, -1, 1, 1, -1, 1, -1, 2, -1, -1, -1, -1, -1, -1, 1, 
     1, 1, -1, -1, -1, 1, -1, 1, -1, 1, 1, -1, -1, -1, -1, 2, -2}}], 
  "Species" -> {metabolite["6pgc", "c"], metabolite["6pgl", "c"], 
    metabolite["co2", "c"], metabolite["e4p", "c"], metabolite["f6p", "c"], 
    metabolite["g3p", "c"], metabolite["gthox", "c"], metabolite["h", "c"], 
    metabolite["h2o", "c"], metabolite["h2o2", "c"], metabolite["nadp", "c"], 
    metabolite["nadph", "c"], metabolite["r5p", "c"], 
    metabolite["ru5p-D", "c"], metabolite["s7p", "c"], 
    metabolite["xu5p-D", "c"], metabolite["g6p", "c"], 
    metabolite["gthrd", "c"]}, "Fluxes" -> {v["G6PDH2r"], v["GND"], 
    v["GTHO"], v["GTHP"], v["PGL"], v["RPE"], v["RPI"], v["TALA"], v["TKT1"], 
    v["TKT2"], v["Sink_f6p_c"], v["Sink_g6p_c"], v["Sink_g3p_c"], 
    v["Sink_h2o_c"], v["Sink_h_c"], v["Sink_co2_c"], v["Sink_h2o2_c"]}, 
  "ReversibleColumnIndices" -> {1, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 
    17}, "Constraints" -> {v["G6PDH2r"] -> {-1000., 1000.}, 
    v["GND"] -> {0., 1000.}, v["GTHO"] -> {0., 1000.}, 
    v["GTHP"] -> {0., 1000.}, v["PGL"] -> {0., 1000.}, 
    v["RPE"] -> {-1000., 1000.}, v["RPI"] -> {-1000., 1000.}, 
    v["TALA"] -> {-1000., 1000.}, v["TKT1"] -> {-1000., 1000.}, 
    v["TKT2"] -> {-1000., 1000.}, v["Sink_f6p_c"] -> {0, Infinity}, 
    v["Sink_g6p_c"] -> {0, Infinity}, v["Sink_g3p_c"] -> {0, Infinity}, 
    v["Sink_h2o_c"] -> {0, Infinity}, v["Sink_h_c"] -> {0, Infinity}, 
    v["Sink_co2_c"] -> {0, Infinity}, v["Sink_h2o2_c"] -> {0, Infinity}}, 
  "BoundaryConditions" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "InitialConditions" -> {v["G6PDH2r"] -> (0.00021*Mole)/(Hour*Liter), 
    v["PGL"] -> (0.00021*Mole)/(Hour*Liter), 
    v["GND"] -> (0.00021*Mole)/(Hour*Liter), 
    v["RPE"] -> (0.00014000000000000001*Mole)/(Hour*Liter), 
    v["RPI"] -> (-0.00007*Mole)/(Hour*Liter), 
    v["TKT1"] -> (0.00007*Mole)/(Hour*Liter), 
    v["TKT2"] -> (0.00007000000000000001*Mole)/(Hour*Liter), 
    v["TALA"] -> (0.00007*Mole)/(Hour*Liter), 
    v["GTHO"] -> (0.00042*Mole)/(Hour*Liter), 
    v["GTHP"] -> (0.00042*Mole)/(Hour*Liter), 
    v["GSHR"] -> (0.00042*Mole)/(Hour*Liter), 
    v["vgshr"] -> (0.00042*Mole)/(Hour*Liter), v["Sink_g6p_c"] -> 
     (-0.00021*Mole)/(Hour*Liter), v["Sink_f6p_c"] -> 
     (0.00014000000000000001*Mole)/(Hour*Liter), v["Sink_h_c"] -> 0, 
    v["Sink_h2o_c"] -> (0.00063*Mole)/(Hour*Liter), 
    v["Sink_h2o2_c"] -> (-0.00042*Mole)/(Hour*Liter), 
    v["Sink_co2_c"] -> (0.00021*Mole)/(Hour*Liter), 
    v["Sink_g3p_c"] -> (0.00007000000000000001*Mole)/(Hour*Liter), 
    metabolite["g6p", "c"] -> (0.000048599999999999995*Mole)/Liter, 
    metabolite["f6p", "c"] -> (0.000019800000000000004*Mole)/Liter, 
    metabolite["g3p", "c"] -> (7.28*^-6*Mole)/Liter, 
    metabolite["6pgl", "c"] -> (1.754242723*^-6*Mole)/Liter, 
    metabolite["6pgc", "c"] -> (0.000037475257999999995*Mole)/Liter, 
    metabolite["ru5p-D", "c"] -> (4.9367903*^-6*Mole)/Liter, 
    metabolite["xu5p-D", "c"] -> (0.000014784196*Mole)/Liter, 
    metabolite["r5p", "c"] -> (4.94*^-6*Mole)/Liter, 
    metabolite["s7p", "c"] -> (0.000023987984*Mole)/Liter, 
    metabolite["e4p", "c"] -> (5.0750696*^-6*Mole)/Liter, 
    metabolite["nadp", "c"] -> (2.0000000000000002*^-7*Mole)/Liter, 
    metabolite["nadph", "c"] -> (0.0000658*Mole)/Liter, 
    metabolite["gthrd", "c"] -> (0.0032*Mole)/Liter, 
    metabolite["gthox", "c"] -> (0.00011999999999999966*Mole)/Liter, 
    metabolite["h", "c"] -> (9.929240111468597*^-8*Mole)/Liter, 
    metabolite["h2o2", "c"] -> (1.*^-8*Mole)/Liter, 
    metabolite["h2o", "c"] -> (0.00099999683*Mole)/Liter, 
    metabolite["co2", "c"] -> (0.0010000020999999999*Mole)/Liter}, 
  "Parameters" -> {parameter["Volume", "c"] -> Liter, Keq["Sink_h_c"] -> 1, 
    Keq["Sink_h2o_c"] -> 1, Keq["Sink_g6p_c"] -> 1, Keq["Sink_g3p_c"] -> 1, 
    Keq["Sink_h2o2_c"] -> 1, Keq["Sink_co2_c"] -> 1, Keq["Sink_f6p_c"] -> 1, 
    Keq["G6PDH2r"] -> 1000, Keq["PGL"] -> 1000, Keq["GND"] -> Mole/Liter, 
    Keq["RPE"] -> 3, Keq["RPI"] -> 0.38910505836575876, Keq["TKT1"] -> 3, 
    Keq["TKT2"] -> 10.3, Keq["TALA"] -> 1.05, Keq["GTHO"] -> Mole/(10*Liter), 
    Keq["GTHP"] -> (Liter^2*Infinity)/Mole^2, metabolite[_, "Xt"] -> 
     Mole/(1000*Liter), rateconst["G6PDH2r", True] -> 
     (2.1864589656595405*^7*Liter)/(Hour*Mole), rateconst["GND", True] -> 
     (2.8018486223630536*^7*Liter)/(Hour*Mole), rateconst["GTHO", True] -> 
     (53191.489361702275*Liter)/(Hour*Mole), rateconst["GTHP", True] -> 
     (4.1015625*^9*Liter^2)/(Hour*Mole^2), rateconst["PGL", True] -> 
     119.70977405046361/Hour, rateconst["RPE", True] -> 
     16045.906574619807/Hour, rateconst["RPI", True] -> 
     9.035113077475318/Hour, rateconst["TALA", True] -> 
     (886848.1688980454*Liter)/(Hour*Mole), rateconst["TKT1", True] -> 
     (4.722363141036396*^6*Liter)/(Hour*Mole), rateconst["TKT2", True] -> 
     (1.1468592496094636*^6*Liter)/(Hour*Mole), 
    rateconst["Sink_f6p_c", True] -> -0.14282799428688023/Hour, 
    rateconst["Sink_g6p_c", True] -> 0.22072734916964473/Hour, 
    rateconst["Sink_g3p_c", True] -> -0.07051333709404464/Hour, 
    rateconst["Sink_h2o_c", True] -> -0.63/Hour, 
    rateconst["Sink_h_c", True] -> Hour^(-1), 
    rateconst["Sink_co2_c", True] -> 100000.00000720235/Hour, 
    rateconst["Sink_h2o2_c", True] -> 0.4200042000420004/Hour}, 
  "Notes" -> "\nModel constructed on Wed 29 Aug 2012 11:42:06 by niko on \
staphylococcus.ucsd.edu using Mathematica 8.0 for Mac OS X x86 (64-bit) \
(November 6, 2010) at the following geodetic location: latitude 32.88; \
longitude -117.24\n This model is a translation of the pentose phosphate \
pathway model in 'Simulation of dynamic network state' in terms of the \
iAB-RBC-238 reconstruction by Aarash Bordbard."}]
